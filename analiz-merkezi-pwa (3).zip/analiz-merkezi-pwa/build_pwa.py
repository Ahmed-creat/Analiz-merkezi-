#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Analiz Merkezi — PWA paketi üreticisi.
Kaynak: analiz-merkezi-gelismui kaynaklarından merge.py ile üretilen tek dosya.
Çıktı: analiz-merkezi-pwa/index.html (manifest + PWA/Firebase modülü bağlı)."""
import json, re, os, subprocess

ROOT = os.path.dirname(os.path.abspath(__file__))
KAYNAK_MERGE = "/home/user/analiz-merkezi-gelismui/merge.py"
TEK_DOSYA = "/home/user/gelişmişuianalizmerkezi.html"

# 1) Kaynağı derle (tek dosya her zaman güncel olsun)
subprocess.run(["python3", KAYNAK_MERGE], check=True, capture_output=True)
html = open(TEK_DOSYA, encoding="utf-8").read()

# 2) firebase-config.js -> Python dict (süslü parantez bloğu geçerli JSON olacak şekilde)
cfg_src = open(os.path.join(ROOT, "firebase-config.js"), encoding="utf-8").read()
blok = re.search(r"FIREBASE_CONFIG\s*=\s*(\{.*?\n\})", cfg_src, re.S).group(1)
blok = re.sub(r"^\s*//.*$|\s+//.*$", "", blok, flags=re.M)  # satır sonu yorumları temizle
blok = re.sub(r"([{,]\s*)([A-Za-z_][\w]*)\s*:", r'\1"\2":', blok)  # anahtarları çift tırnakla (JS -> JSON)
blok = re.sub(r",\s*([}\]])", r"\1", blok)  # trailing virgül
CFG = json.loads(blok)

# 3) messaging SW'ye gerçek config bas
sw_path = os.path.join(ROOT, "firebase-messaging-sw.js")
sw = open(sw_path, encoding="utf-8").read()
cfg_js = json.dumps(CFG, ensure_ascii=False)
if "__FIREBASE_CONFIG__" in sw:
    sw = sw.replace("__FIREBASE_CONFIG__", cfg_js)
else:
    sw = re.sub(r"const CFG = \{.*?\};", "const CFG = " + cfg_js + ";", sw, flags=re.S)
open(sw_path, "w", encoding="utf-8").write(sw)

# 4) index.html: manifest + tema meta + modül script
manifest_tag = '<link rel="manifest" href="manifest.json">\n<meta name="apple-mobile-web-app-capable" content="yes">\n<meta name="apple-mobile-web-app-status-bar-style" content="default">\n<link rel="apple-touch-icon" href="icons/icon-192.png">\n</head>'
assert "</head>" in html
html = html.replace("</head>", manifest_tag, 1)
modul_tag = '<script type="module" src="app-pwa.js"></script>\n</body>'
assert "</body>" in html
html = html.replace("</body>", modul_tag, 1)

out = os.path.join(ROOT, "index.html")
open(out, "w", encoding="utf-8").write(html)
print("✅ PWA index.html üretildi:", out, f"({len(html):,} bayt) | Firebase:", "YAPILI" if CFG.get("apiKey") else "boş (kullanıcı dolduracak)")
