const { chromium } = require("playwright");
const fs = require("fs");
const APP = "file://" + encodeURI("/home/user/gelişmişuianalizmerkezi.html");
const MOCK = JSON.parse(fs.readFileSync("/home/user/analiz-merkezi/mock-data.json", "utf8")).state;
let pass = 0, fail = 0;
const ok = (n, c) => { if (c) { pass++; console.log("  ✓ " + n); } else { fail++; console.log("  ✗ " + n); } };
(async () => {
  const b = await chromium.launch();
  const pg = await b.newPage({ viewport: { width: 1280, height: 900 } });
  await pg.goto(APP, { waitUntil: "networkidle" });
  try { await pg.locator("#onb-atla").click({ timeout: 4000 }); await pg.waitForTimeout(600); } catch (e) {}
  await pg.click('[data-act="enterApp"]');
  await pg.evaluate(st => localStorage.setItem("analizmerkezi_v6", JSON.stringify(st)), MOCK);
  await pg.reload({ waitUntil: "networkidle" });
  await pg.waitForTimeout(700); // dönen kullanıcı: sınıf ekranı otomatik atlanır
  await pg.waitForSelector("#main-content .hello-row");
  await pg.evaluate(() => setTheme("dark"));
  await pg.waitForTimeout(300);
  const kart = await pg.$eval(".bento-card:not(.stat-box):not(.son-exam)", el => ({ bg: getComputedStyle(el).backgroundColor, bd: getComputedStyle(el).borderBottomColor }));
  ok("koyu kart #111 + kenar #303030", kart.bg === "rgb(17, 17, 17)" && kart.bd === "rgb(48, 48, 48)");
  await pg.evaluate(() => setTheme("light"));
  await pg.waitForTimeout(200);
  ok("açık zemin #F3F7FE", (await pg.$eval(".main-content", el => getComputedStyle(el).backgroundColor)) === "rgb(243, 247, 254)");
  await pg.setViewportSize({ width: 390, height: 844 });
  await pg.evaluate(() => setTheme("dark"));
  await pg.click('.bottom-nav-item[data-nav="dashboard"]');
  await pg.waitForTimeout(400);
  ok("mobil koyu navbar MAVİ", /47, ?107, ?238|31, ?78, ?216/.test(await pg.$eval(".bottom-nav", el => getComputedStyle(el).backgroundImage)));
  console.log("\nSONUÇ dark: " + pass + " ✓ / " + fail + " ✗");
  await b.close();
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error("FATAL:", e); process.exit(2); });
