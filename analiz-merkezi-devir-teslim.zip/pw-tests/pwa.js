// Tur-17 pwa — http://localhost:8123 (analiz-merkezi-pwa): PWA + Firebase katmanı,
// config boşken uygulama tam çalışır + giriş butonu + yol gösterici uyarı
const { chromium } = require("playwright");
let pass = 0, fail = 0;
const ok = (n, c) => { if (c) { pass++; console.log("  ✓ " + n); } else { fail++; console.log("  ✗ " + n); } };
(async () => {
  const b = await chromium.launch();
  const pg = await b.newPage({ viewport: { width: 1280, height: 900 } });
  const errs = [];
  pg.on("pageerror", e => errs.push(String(e)));
  pg.on("console", m => { if (m.type() === "error" && !/net::|Failed to load resource/.test(m.text())) errs.push("CN:" + m.text()); });
  await pg.goto("http://localhost:8123/index.html", { waitUntil: "networkidle" });
  try { await pg.locator("#onb-atla").click({ timeout: 4000 }); await pg.waitForTimeout(600); } catch (e) {}


  // PWA bağlantıları
  ok("manifest bağlantısı", (await pg.locator('link[rel="manifest"][href="manifest.json"]').count()) === 1);
  ok("PWA modülü bağlı", (await pg.locator('script[type="module"][src="app-pwa.js"]').count()) === 1);
  // Uygulama tam çalışıyor
  await pg.click('.splash-grade[data-grade="9"]');
  await pg.click('[data-act="enterApp"]');
  await pg.waitForSelector("#welcome-modal", { state: "visible" });
  await pg.fill("#welcome-name", "PWA Test");
  await pg.click('[data-act="completeWelcome"]');
  await pg.waitForSelector("#main-content .hello-row");
  ok("uygulama PWA paketinde açılıyor", (await pg.locator(".hello-row h2").textContent()).includes("PWA Test"));
  await pg.click('[data-nav="planning"]');
  await pg.waitForSelector("text=Çalışma Takvimi");
  ok("planlama render", true);
  // Service worker
  await pg.waitForTimeout(1200);
  const sw = await pg.evaluate(async () => {
    if (!("serviceWorker" in navigator)) return "yok";
    const r = await navigator.serviceWorker.getRegistration();
    return r ? r.active && r.active.scriptURL : null;
  });
  ok("service worker kayıtlı (sw.js)", !!(sw && String(sw).includes("sw.js")));
  // E-posta/şifre modalı + GERÇEK giriş (canlı Firebase)
  ok("avatar → profil + Giriş butonu", (await pg.locator("#sidebar-avatar").count()) === 1);
  await pg.click("#sidebar-avatar");
  await pg.waitForTimeout(350);
  await pg.click('#pwa-profile-modal [data-act="pwaAuth"]');
  await pg.waitForTimeout(700);
  ok("config dolu → giriş modalı AÇILIR", (await pg.evaluate(() => document.getElementById("pwa-auth-modal").style.display)) === "flex");
  await pg.fill("#pwa-email", "smoke-test@analiz-merkezi.app");
  await pg.fill("#pwa-pass", "Test1234!kok");
  await pg.click('[data-act="pwaAuthLogin"]');
  await pg.waitForFunction(() => {
    const l = document.getElementById("pwa-auth-label");
    return l && l.textContent.includes("Girişli");
  }, { timeout: 25000 });
  const label = await pg.evaluate(() => document.getElementById("pwa-auth-label").textContent);
  ok("GERÇEK e-posta/şifre girişi (canlı): " + label, label.includes("Girişli") && label.includes("smoke-test"));
  ok("modal kapandı", (await pg.evaluate(() => document.getElementById("pwa-auth-modal").style.display)) === "none");
  await pg.evaluate(() => saveState());
  await pg.waitForTimeout(6500); // 4 sn debounce + ağ
  // İkon/manifest varlıkları
  const mStat = await pg.evaluate(async () => (await fetch("manifest.json")).status);
  const iStat = await pg.evaluate(async () => (await fetch("icons/icon-192.png")).status);
  ok("manifest.json 200", mStat === 200);
  ok("ikon 200", iStat === 200);
  ok("konsol hatası 0 (" + errs.length + ")", errs.length === 0);
  if (errs.length) console.log(errs.slice(0, 3).join("\n"));
  // Bulut senkronu Firestore'a yazdı mı? (REST ile dışarıdan doğrula)
  const https = require("https");
  const jreq = (url, data, tok) => new Promise((res) => {
    const body = data ? JSON.stringify(data) : null;
    const r = https.request(url, { method: body ? "POST" : "GET", headers: Object.assign({ "Content-Type": "application/json" }, tok ? { Authorization: "Bearer " + tok } : {}) }, (rs) => { let b = ""; rs.on("data", c => b += c); rs.on("end", () => { try { res([rs.statusCode, JSON.parse(b)]); } catch (e) { res([rs.statusCode, null]); } }); });
    r.on("error", () => res([0, null]));
    if (body) r.write(body);
    r.end();
  });
  const [, lg] = await jreq("https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyD7X9Sqn6HEoVEtjqcjw7FcFMQfrzup_Ng", { email: "smoke-test@analiz-merkezi.app", password: "Test1234!kok", returnSecureToken: true });
  const [st, dc] = await jreq("https://firestore.googleapis.com/v1/projects/analiz-merkezi-87338/databases/(default)/documents/users/" + lg.localId + "/state/main", null, lg.idToken);
  const upd = st === 200 ? Number(dc.fields.updatedAt.integerValue) : 0;
  ok("Firestore'a bulut yedeği YAZILDI (updatedAt=" + (upd > 1 ? new Date(upd).toISOString().slice(0, 19) : upd) + ")", upd > 1);

  console.log("\nSONUÇ pwa: " + pass + " ✓ / " + fail + " ✗");
  await b.close();
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error("FATAL:", e); process.exit(2); });
