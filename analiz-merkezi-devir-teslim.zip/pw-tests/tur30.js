// Tur-30: SW sürüm damgası + oranlı hazırlık günleri + duyuru→takvim ithali + modal
const { chromium } = require("playwright");
let pass = 0, fail = 0;
const ok = (n, c) => { if (c) { pass++; console.log("  ✓ " + n); } else { fail++; console.log("  ✗ " + n); } };
(async () => {
  const b = await chromium.launch();
  const pg = await b.newPage({ viewport: { width: 1280, height: 900 } });
  const errs = [];
  pg.on("pageerror", e => errs.push(String(e).slice(0, 150)));
  await pg.goto("http://localhost:8123/index.html", { waitUntil: "networkidle" });
  // 1) SW: sürümlü cache + ağ-öncelikli
  await pg.waitForTimeout(1500);
  const sw = await pg.evaluate(async () => {
    const r = await navigator.serviceWorker.getRegistration();
    const keys = await caches.keys();
    return { aktif: !!(r && r.active), cacheAd: keys.find(k => /analiz-merkezi-v-\d+/.test(k)) || keys[0] || null };
  });
  ok("SW kayıtlı ve cache SÜRÜMLÜ: " + sw.cacheAd, sw.aktif && /analiz-merkezi-v-\d+/.test(sw.cacheAd || ""));
  // 2) uygulama aç
  await pg.click('.splash-grade[data-grade="9"]');
  await pg.click('[data-act="enterApp"]');
  await pg.waitForSelector("#welcome-modal", { state: "visible" });
  await pg.fill("#welcome-name", "Tur30");
  await pg.click('[data-act="completeWelcome"]');
  await pg.waitForSelector("#main-content .hello-row");
  // 3) oranlı hazırlık formülü
  const f = await pg.evaluate(() => ({
    d10: schoolPrepDaysFor(10), d4: schoolPrepDaysFor(4), d2: schoolPrepDaysFor(2), d20: schoolPrepDaysFor(20), d30: schoolPrepDaysFor(30)
  }));
  ok("10 gün → [5,3,1]", JSON.stringify(f.d10) === "[5,3,1]");
  ok("4 gün → [2,1] · 2 gün → [1]", JSON.stringify(f.d4) === "[2,1]" && JSON.stringify(f.d2) === "[1]");
  ok("20 gün → [10,5,1]", JSON.stringify(f.d20) === "[10,5,1]");
  // 4) okul sınavı 10 gün sonraya → takvimde -5/-3/-1 hazırlık rozetleri
  await pg.click('[data-nav="planning"]');
  await pg.waitForSelector("text=Okul Sınavları");
  await pg.selectOption("#school-lesson", "Fizik");
  await pg.waitForTimeout(350);
  await pg.locator(".school-topic").nth(0).check();
  await pg.evaluate(() => {
    const d = new Date(); d.setDate(d.getDate() + 10);
    document.getElementById("school-date").value = d.toISOString().slice(0, 10);
  });
  await pg.click('[data-act="addSchoolExam"]');
  await pg.waitForTimeout(400);
  const takvim = await pg.evaluate(() => {
    const se = state.plan.schoolExams[state.plan.schoolExams.length - 1];
    const map = calendarEventMap();
    const rozetler = Object.keys(map).filter(k => map[k].some(e => e.examId === se.id && e.tip === "hazirlik")).sort();
    return { prepDays: se.prepDays, rozetler };
  });
  ok("sınav kaydında prepDays [5,3,1] (" + JSON.stringify(takvim.prepDays) + ")", JSON.stringify(takvim.prepDays) === "[5,3,1]");
  ok("takvimde 3 hazırlık günü rozeti (" + takvim.rozetler.length + ")", takvim.rozetler.length === 3);
  // 5) duyuru → takvime otomatik ithal
  const eklenen = await pg.evaluate(() => okzDuyurularToSchoolExams([
    { baslik: "Matematik 1. Yazılı Sınavı 20.11.2026", url: "https://x.okul.tr/a", tarih: "2026-11-20", lesson: "Matematik" },
    { baslik: "Konser duyurusu", url: "https://x.okul.tr/b", tarih: "2026-11-01" } // ders yok → eklenmez
  ]));
  ok("otomatik ithal: 1 sınav eklendi", eklenen === 1);
  const otomatik = await pg.evaluate(() => {
    const se = state.plan.schoolExams.find(s => s.auto && s.lesson === "Matematik");
    return { var: !!se, prep: se && se.prepDays };
  });
  ok("takvimde: Matematik sınavı (auto) + oranlı hazırlık", otomatik.var && Array.isArray(otomatik.prep) && otomatik.prep.length >= 2);
  const eklenen2 = await pg.evaluate(() => okzDuyurularToSchoolExams([
    { baslik: "Matematik 1. Yazılı Sınavı 20.11.2026", url: "https://x.okul.tr/a", tarih: "2026-11-20", lesson: "Matematik" }
  ]));
  ok("aynı duyuru ikinci kez DUP-like edilmedi", eklenen2 === 0);
  // 6) Okulizyon modal hâlâ açılıyor + duyuru işareti
  await pg.evaluate(() => {
    state.okulizyon.duyurular = [
      { baslik: "Matematik 1. Yazılı Sınavı 20.11.2026", url: "https://x.okul.tr/a", tarih: "2026-11-20", lesson: "Matematik" },
      { baslik: "Konser duyurusu", url: "https://x.okul.tr/b", tarih: "2026-11-01" }
    ];
    saveState();
  });
  await pg.click("#pwa-okz-btn");
  await pg.waitForTimeout(500);
  const modal = await pg.evaluate(() => {
    const m = document.getElementById("pwa-okz-modal");
    return { acik: m.style.display === "flex", isaret: m.innerHTML.includes("takvime eklendi") };
  });
  ok("Okulizyon modalı açılıyor", modal.acik);
  ok("sınav duyurusu 'takvime eklendi' işaretli", modal.isaret);
  // 7) bildirimde oranlı hazırlık görünür
  await pg.click('[data-act="okzClose"]');
  await pg.waitForTimeout(250);
  await pg.evaluate(() => processDueNotifications());
  await pg.waitForTimeout(300);
  await pg.click('.sidebar [data-act="openNotif"]');
  await pg.waitForSelector("#notif-modal", { state: "visible" });
  const notif = await pg.locator("#notif-list").textContent();
  ok("bildirim listesinde okul sınavı hazırlıkları var", notif.includes("Matematik") || notif.includes("Fizik"));
  await pg.click('[data-act="closeModal"]');
  // 8) taşma + konsol
  let over = 0;
  for (const p2 of ["dashboard", "planning", "tracking", "knowledge"]) {
    await pg.click('[data-nav="' + p2 + '"]');
    await pg.waitForTimeout(200);
    if (await pg.evaluate(() => document.documentElement.scrollWidth > 1280)) over++;
  }
  ok("taşma 0", over === 0);
  ok("konsol 0 (" + errs.length + ")", errs.length === 0);
  if (errs.length) console.log(errs.slice(0, 3).join("\n"));
  console.log("\nSONUÇ tur30: " + pass + " ✓ / " + fail + " ✗");
  await b.close();
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error("FATAL:", e); process.exit(2); });
