// VAPID + FCM token kaydı — CANLI uçtan uca test
// Bildirim izni verilmiş tarayıcıda giriş → getToken → Firestore meta/fcm
const { chromium } = require("playwright");
try { require("fs").rmSync("/tmp/pw-push-profile", { recursive: true, force: true }); } catch (e) {} // her koşuda taze profil (splash artık atlanıyor)
const https = require("https");
function jreq(url, data, tok) {
  return new Promise((res) => {
    const body = data ? JSON.stringify(data) : null;
    const r = https.request(url, { method: body ? "POST" : "GET", headers: Object.assign({ "Content-Type": "application/json" }, tok ? { Authorization: "Bearer " + tok } : {}) }, (rs) => { let b = ""; rs.on("data", c => b += c); rs.on("end", () => { try { res([rs.statusCode, JSON.parse(b)]); } catch (e) { res([rs.statusCode, null]); } }); });
    r.on("error", () => res([0, null]));
    if (body) r.write(body);
    r.end();
  });
}
(async () => {
  let pass = 0, fail = 0;
  const ok = (n, c) => { if (c) { pass++; console.log("  ✓ " + n); } else { fail++; console.log("  ✗ " + n); } };
  const ctx = await chromium.launchPersistentContext("/tmp/pw-push-profile", { headless: process.env.HEADED ? false : true, viewport: { width: 1280, height: 900 } });
  await ctx.grantPermissions(["notifications"]);
  const pg = ctx.pages()[0] || await ctx.newPage();
  const b = ctx;
  const warns = [];
  pg.on("console", m => { if (m.type() === "warning" || m.type() === "error") warns.push(m.text().slice(0, 140)); });
  await pg.addInitScript(() => {
    if (typeof Notification !== "undefined") {
      try {
        Object.defineProperty(Notification, "permission", { get: () => "granted", configurable: true });
        Notification.requestPermission = (cb) => { if (typeof cb === "function") cb("granted"); return Promise.resolve("granted"); };
      } catch (e) {}
    }
  });
  await pg.goto("http://localhost:8123/index.html", { waitUntil: "networkidle" });
  try { await pg.locator("#onb-atla").click({ timeout: 4000 }); await pg.waitForTimeout(600); } catch (e) {}

  ok("bildirim izni: granted (" + (await pg.evaluate(() => Notification.permission)) + ")", (await pg.evaluate(() => Notification.permission)) === "granted");
  await pg.click('.splash-grade[data-grade="9"]');
  await pg.click('[data-act="enterApp"]');
  await pg.waitForSelector("#welcome-modal", { state: "visible" });
  await pg.fill("#welcome-name", "Push Test");
  await pg.click('[data-act="completeWelcome"]');
  await pg.waitForSelector("#main-content .hello-row");
  await pg.click("#sidebar-avatar");
  await pg.waitForTimeout(350);
  await pg.click('#pwa-profile-modal [data-act="pwaAuth"]');
  await pg.waitForTimeout(600);
  await pg.fill("#pwa-email", "smoke-test@analiz-merkezi.app");
  await pg.fill("#pwa-pass", "Test1234!kok");
  await pg.click('[data-act="pwaAuthLogin"]');
  await pg.waitForFunction(() => { const l = document.getElementById("pwa-auth-label"); return l && l.textContent.includes("Girişli"); }, { timeout: 25000 });
  ok("giriş ✓ (girişte registerFCM tetiklenir)", true);
  try { await pg.click('[data-act="pwaProfileClose"]', { timeout: 2000 }); } catch (e) {}
  await pg.waitForTimeout(300);
  // Uygulamanın bildirim izni butonu (kancamız izin sonrası registerFCM çağırır)
  await pg.click('.sidebar [data-act="openNotif"]');
  await pg.waitForSelector("#notif-modal", { state: "visible" });
  await pg.evaluate(() => document.querySelector('[data-act="toggleNotifPermission"]').click());
  await pg.waitForTimeout(1000);
  ok("izin butonu → granted", (await pg.evaluate(() => Notification.permission)) === "granted");
  await pg.click('[data-act="closeModal"]');
  console.log("  … token için 14 sn bekleniyor (FCM el sıkışması)");
  await pg.waitForTimeout(14000);
  const tokenVar = await pg.evaluate(async () => {
    try {
      const reg = await navigator.serviceWorker.ready;
      return { sw: !!reg, perm: Notification.permission };
    } catch (e) { return { sw: false, perm: Notification.permission }; }
  });
  ok("service worker hazır", tokenVar.sw);
  // Firestore'dan REST ile doğrula
  const KEY = "AIzaSyD7X9Sqn6HEoVEtjqcjw7FcFMQfrzup_Ng";
  const [, lg] = await jreq("https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=" + KEY, { email: "smoke-test@analiz-merkezi.app", password: "Test1234!kok", returnSecureToken: true });
  const [st, dc] = await jreq("https://firestore.googleapis.com/v1/projects/analiz-merkezi-87338/databases/(default)/documents/users/" + lg.localId + "/meta/fcm", null, lg.idToken);
  const token = st === 200 && dc.fields && dc.fields.token ? dc.fields.token.stringValue : "";
  ok("Firestore meta/fcm'de FCM token kayıtlı (" + (token ? token.slice(0, 18) + "…" : "YOK") + ")", token.length > 50);
  if (warns.length) console.log("  uyarılar:\n" + warns.slice(0, 6).join("\n   "));
  ok("FCM hata uyarısı yok", !warns.some(w => w.includes("FCM") && /hata|error|fail|reddedildi|izin/i.test(w)));
  if (token.length > 50) {
    console.log("  🎉 TOKEN KAYITLI — VAPID anahtarı geçerli, push zinciri tam");
  }
  console.log("\nSONUÇ push: " + pass + " ✓ / " + fail + " ✗");
  await b.close();
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error("FATAL:", e); process.exit(2); });
