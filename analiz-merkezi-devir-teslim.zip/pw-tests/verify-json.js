// JSON'un uygulamada içe aktarım doğrulaması (localStorage'a bas + yenile + motorları çalıştır)
const { chromium } = require("playwright");
const fs = require("fs");
const STATE = JSON.parse(fs.readFileSync("/home/user/ahmed-ibrahim-9-sinif-denemeleri.json", "utf8"));
let pass = 0, fail = 0;
const ok = (n, c) => { if (c) { pass++; console.log("  ✓ " + n); } else { fail++; console.log("  ✗ " + n); } };
(async () => {
  const b = await chromium.launch();
  const pg = await b.newPage({ viewport: { width: 1280, height: 900 } });
  const errs = [];
  pg.on("pageerror", e => errs.push(String(e).slice(0, 150)));
  await pg.goto("http://localhost:8123/index.html", { waitUntil: "networkidle" });
  try { const _a = await pg.$("#onb-atla"); if (_a) await _a.click(); } catch (e) {}
  await pg.evaluate(st => { localStorage.setItem("analizmerkezi_v6", JSON.stringify(st)); }, STATE);
  await pg.reload({ waitUntil: "networkidle" });
  await pg.waitForTimeout(800);
  const s = await pg.evaluate(() => {
    const st = examStats();
    const pr = calculatePriority();
    const dist = errorTypeDistribution();
    return {
      exams: state.exams.length,
      nets: state.exams.map(e => e.net),
      count: st.count, best: st.best, avg: st.avg,
      seriIlk: st.series[0] && st.series[0].name, seriSon: st.series[st.series.length - 1] && st.series[st.series.length - 1].name,
      seriNets: st.series.map(x => x.net),
      oncelik: pr.length, top3: pr.slice(0, 3).map(x => x[0] + " (" + x[1] + ")"),
      kae: dist.find(d => d.group === "KAE") && dist.find(d => d.group === "KAE").count,
      logs: state.exams.reduce((a, e) => a + e.errorLogs.length, 0),
      totals: state.exams.map(e => e.total),
      d1lessons: state.exams[0].lessons,
      dersSayilari: state.exams.map(e => Object.keys(e.lessons).length),
      agactaDisi: state.exams.reduce((a, e) => a + e.errorLogs.filter(l => !(CURRICULUM[9][l.lesson] || []).includes(l.topic)).length, 0),
      ahenkParcasi: state.exams.reduce((a, e) => a + e.errorLogs.filter(l => /ahenk/i.test(l.topic) && l.topic !== "Şiir Bilgisi (Şekil Unsurları)").length, 0),
      userName: state.user.name
    };
  });
  ok("içe aktarıldı: 7 deneme", s.exams === 7);
  ok("gerçek soru sayıları (netlerden): 121/119/118/119/122/119/120",
     JSON.stringify(s.totals) === JSON.stringify([121, 119, 118, 119, 122, 119, 120]));
  ok("her denemede 8 dersin TAMAMI", s.dersSayilari.every(n => n === 8));
  ok("tüm konular curriculum ağacından (eşleşme)", s.agactaDisi === 0);
  ok("kullanıcı: Ahmed İbrahim", s.userName === "Ahmed İbrahim");
  ok("Genel Netler PDF ile birebir: 85.5→78.5→65.25→77.75→82.25→67.5→78.5",
     JSON.stringify(s.nets) === JSON.stringify([85.5, 78.5, 65.25, 77.75, 82.25, 67.5, 78.5]));
  ok("istatistik: 7 deneme · en iyi 85.5 · ort " + s.avg, s.count === 7 && s.best === 85.5 && s.avg === 76.46);
  ok("grafik tarihe göre: ilk 'Süreç İzleme 1', son 'STS 4 - Ulti 4'", /Süreç İzleme 1$/.test(s.seriIlk) && /STS 4/.test(s.seriSon));
  ok("272 hata kaydı aktı (114Y + 160B)", s.logs === 272);
  ok("öncelik listesi dolu (" + s.oncelik + " konu)", s.oncelik >= 25);
  console.log("    TOP-3 öncelik: " + s.top3.join(" · "));
  ok("KAE grubu 272 kayıt (Konuyu Bilmiyordum + KONU EKSİKLİĞİ)", s.kae === 272);
  const d1 = s.d1lessons;
  ok("D1 gerçek ders netleri (26.25/9.5/3.5...)", Math.round((d1["Türk Dili ve Edebiyatı"].d - d1["Türk Dili ve Edebiyatı"].w/4)*100)/100 === 26.25 && d1["Din Kültürü"].d === 4 && d1["Kimya"].e === 2);
  ok("'ahenk' parçalara ayrılmamış (tek konu birleşti)", s.ahenkParcasi === 0);
  // Denemelerim sayfası görünürlüğü
  await pg.click('[data-nav="exams"]');
  await pg.waitForTimeout(500);
  const satirlar = await pg.locator(".exam-row").count();
  ok("Denemelerim: 7 satır listelendi", satirlar === 7);
  const govde = await pg.evaluate(() => document.getElementById("main-content").textContent);
  ok("net satırları görünür (85.5 / 78.5)", govde.includes("85.5") && govde.includes("78.5"));
  // Konu Takibi neden rozetleri
  await pg.click('[data-nav="tracking"]');
  await pg.waitForTimeout(500);
  const rozet = await pg.evaluate(() => document.getElementById("main-content").textContent);
  ok("Konu Takibi: 'Konuyu Bilmiyordum ×n' rozetleri", rozet.includes("Konuyu Bilmiyordum"));
  ok("Konu Takibi: 'KONU EKSİKLİĞİ ×n' rozetleri", rozet.includes("KONU EKSİKLİĞİ"));
  ok("konsol hatası 0 (" + errs.length + ")", errs.length === 0);
  if (errs.length) console.log(errs.slice(0, 3).join("\n"));
  console.log("\nSONUÇ verify-json: " + pass + " ✓ / " + fail + " ✗");
  await b.close();
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error("FATAL:", e.message); process.exit(2); });
