// Tur-17 g2 — mobil 390 + yatay 740: portal dokunuş, QB kırpma, okul sınavı, taşma
const { chromium } = require("playwright");
const fs = require("fs");
const APP = "file://" + encodeURI("/home/user/gelişmişuianalizmerkezi.html");
const MOCK = JSON.parse(fs.readFileSync("/home/user/analiz-merkezi/mock-data.json", "utf8")).state;
let pass = 0, fail = 0;
const ok = (n, c) => { if (c) { pass++; console.log("  ✓ " + n); } else { fail++; console.log("  ✗ " + n); } };
(async () => {
  const b = await chromium.launch();
  let pg = await b.newPage({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
  const errs = [];
  pg.on("pageerror", e => errs.push(String(e)));
  await pg.goto(APP, { waitUntil: "networkidle" });
  try { await pg.locator("#onb-atla").click({ timeout: 4000 }); await pg.waitForTimeout(600); } catch (e) {}
  await pg.tap('.splash-grade[data-grade="9"]');
  await pg.tap('[data-act="enterApp"]');
  await pg.waitForSelector("#welcome-modal", { state: "visible" });
  await pg.fill("#welcome-name", "Mehmet");
  await pg.click('[data-act="completeWelcome"]');
  await pg.waitForSelector("#main-content .hello-row");
  await pg.evaluate(st => localStorage.setItem("analizmerkezi_v6", JSON.stringify(st)), MOCK);
  await pg.reload({ waitUntil: "networkidle" });
  await pg.waitForTimeout(700); // dönen kullanıcı: sınıf ekranı otomatik atlanır
  await pg.waitForSelector("#main-content .hello-row");
  console.log("— MOBİL 390 —");
  const navBg = await pg.$eval(".bottom-nav", el => getComputedStyle(el).backgroundImage + getComputedStyle(el).backgroundColor);
  ok("alt navbar mavi", /47, ?107, ?238|31, ?78, ?216/.test(navBg));
  const sag = await pg.$$eval(".mobile-topbar > div:last-child > *", els => els.map(e => e.className + "/" + (e.dataset.act || e.id)));
  ok("sağ üst: streak → bildirim → ayarlar", sag[0].includes("streak-pill") && sag[1].includes("openNotif") && sag[2].includes("openSettings"));
  const goPage = async p => {
    const direct = await pg.$('.bottom-nav-item[data-nav="' + p + '"]');
    if (direct) { await direct.tap(); }
    else { await pg.tap('[data-act="openMore"]'); await pg.waitForTimeout(180); await pg.tap('#more-sheet [data-nav="' + p + '"]'); await pg.waitForTimeout(180); }
  };
  await goPage("exams");
  await pg.waitForSelector("#main-content h2");
  await pg.tap('[data-act="toggleExamForm"]');
  await pg.waitForSelector(".fc-body:not([hidden])");
  await pg.fill("#exam-name", "Mobil");
  await pg.fill('[data-exam-dwb="Matematik-d"]', "28");
  await pg.fill('[data-exam-dwb="Matematik-w"]', "2");
  await pg.waitForTimeout(350);
  ok("2 hata satırı", (await pg.locator('[data-error-area="Matematik"] .error-log-row').count()) === 2);
  const ddKonu = 'select[data-err="Matematik:0:topic"] + .dd';
  await pg.tap(ddKonu + " .dd-btn");
  await pg.waitForSelector(".dd-menu.dd-sheet .dd-opt", { state: "visible" });
  ok("portal alt-sheet", (await pg.evaluate(() => {
    const w = document.querySelector('select[data-err="Matematik:0:topic"] + .dd');
    const m = document.querySelector("body > .dd-menu.dd-sheet");
    return w.classList.contains("sheet") && !!m;
  })));
  const kb = await pg.locator(".dd-menu.dd-sheet .dd-opt").nth(1).boundingBox();
  await pg.touchscreen.tap(kb.x + kb.width / 2, kb.y + kb.height / 2);
  await pg.waitForTimeout(350);
  const konuVal = await pg.$eval('select[data-err="Matematik:0:topic"]', el => el.value);
  ok("GERÇEK DOKUNUŞLA konu: " + konuVal.slice(0, 12), konuVal.length > 3);
  const ddNeden = 'select[data-err="Matematik:0:type"] + .dd';
  await pg.tap(ddNeden + " .dd-btn");
  await pg.waitForSelector(".dd-menu.dd-sheet .dd-opt", { state: "visible" });
  const nb = await pg.locator(".dd-menu.dd-sheet .dd-opt").nth(1).boundingBox();
  await pg.touchscreen.tap(nb.x + nb.width / 2, nb.y + nb.height / 2);
  await pg.waitForTimeout(350);
  const nedenVal = await pg.$eval('select[data-err="Matematik:0:type"]', el => el.value);
  ok("GERÇEK DOKUNUŞLA neden: " + nedenVal, nedenVal.length > 3);
  await goPage("questionbank");
  await pg.waitForSelector("#main-content h2");
  await pg.tap('[data-act="toggleQBForm"]');
  await pg.waitForSelector(".fc-body:not([hidden])");
  await pg.selectOption("#qb-lesson", "Matematik");
  await pg.fill("#qb-total", "10");
  await pg.fill("#qb-d", "8");
  await pg.fill("#qb-w", "5");
  await pg.waitForTimeout(400);
  ok("mobil SINIR kırpma 5→2", (await pg.$eval("#qb-w", el => el.value)) === "2");
  await goPage("planning");
  await pg.waitForSelector("text=Okul Sınavları");
  ok("mobil: Deneme Hedefi + Okul Sınavları", (await pg.locator("text=Deneme Hedefi").count()) >= 1);
  let mOver = 0;
  for (const p of ["dashboard", "tasks", "exams", "tracking", "library", "planning", "knowledge", "questionbank"]) {
    await goPage(p);
    await pg.waitForTimeout(220);
    const w = await pg.evaluate(() => document.documentElement.scrollWidth);
    if (w > 390) { mOver++; console.log("    taşma: " + p + " " + w); }
  }
  ok("8 sayfa mobil taşma 0", mOver === 0);
  ok("mobil konsol 0", errs.length === 0);
  await pg.close();

  pg = await b.newPage({ viewport: { width: 740, height: 360 } });
  const errs2 = [];
  pg.on("pageerror", e => errs2.push(String(e)));
  await pg.goto(APP, { waitUntil: "networkidle" });
  try { await pg.locator("#onb-atla").click({ timeout: 4000 }); await pg.waitForTimeout(600); } catch (e) {}
  await pg.click('.splash-grade[data-grade="9"]');
  await pg.click('[data-act="enterApp"]');
  await pg.waitForSelector("#welcome-modal", { state: "visible" });
  await pg.fill("#welcome-name", "M");
  await pg.click('[data-act="completeWelcome"]');
  await pg.waitForSelector("#main-content .hello-row");
  console.log("— YATAY 740×360 —");
  const navBg2 = await pg.$eval(".bottom-nav", el => getComputedStyle(el).backgroundImage + getComputedStyle(el).backgroundColor);
  ok("yatay navbar mavi", /47, ?107, ?238|31, ?78, ?216/.test(navBg2));
  const goPage2 = async p => {
    const direct = await pg.$('.bottom-nav-item[data-nav="' + p + '"]');
    if (direct) { await direct.click(); }
    else { await pg.click('[data-act="openMore"]'); await pg.waitForTimeout(180); await pg.click('#more-sheet [data-nav="' + p + '"]'); await pg.waitForTimeout(180); }
  };
  let lOver = 0;
  for (const p of ["dashboard", "tasks", "exams", "tracking", "library", "planning", "knowledge", "questionbank"]) {
    await goPage2(p);
    await pg.waitForTimeout(220);
    const w = await pg.evaluate(() => document.documentElement.scrollWidth);
    if (w > 740) { lOver++; console.log("    yatay taşma: " + p + " " + w); }
  }
  ok("8 sayfa yatay taşma 0", lOver === 0);
  ok("yatay konsol 0", errs2.length === 0);
  console.log("\nSONUÇ g2: " + pass + " ✓ / " + fail + " ✗");
  await b.close();
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error("FATAL:", e); process.exit(2); });
