// Okulizyon butonu repro: tıkla → modal açılıyor mu + konsol hatası var mı
const { chromium } = require("playwright");
(async () => {
  const b = await chromium.launch();
  const pg = await b.newPage({ viewport: { width: 1280, height: 900 } });
  const errs = [];
  pg.on("pageerror", e => errs.push("PAGEERROR: " + String(e).slice(0, 200)));
  pg.on("console", m => { if (m.type() === "error") errs.push("CONSOLE: " + m.text().slice(0, 150)); });
  await pg.goto("http://localhost:8123/index.html", { waitUntil: "networkidle" });
  await pg.click('.splash-grade[data-grade="9"]');
  await pg.click('[data-act="enterApp"]');
  await pg.waitForSelector("#welcome-modal", { state: "visible" });
  await pg.fill("#welcome-name", "Test");
  await pg.click('[data-act="completeWelcome"]');
  await pg.waitForSelector("#main-content .hello-row");
  await pg.waitForTimeout(800);
  const btn = await pg.locator("#pwa-okz-btn").count();
  console.log("Okulizyon butonu DOM'da:", btn);
  if (btn) {
    await pg.click("#pwa-okz-btn");
    await pg.waitForTimeout(700);
    const durum = await pg.evaluate(() => {
      const m = document.getElementById("pwa-okz-modal");
      return m ? { display: m.style.display, icerik: m.innerHTML.length } : null;
    });
    console.log("Modal durumu:", JSON.stringify(durum));
    // DAHA'da da dene (mobil more sheet)
  }
  const moreBtn = await pg.locator('#more-sheet [data-act="pwaOkz"]').count();
  console.log("DAHA sayfası butonu:", moreBtn);
  console.log("Hatalar:", errs.length ? errs.slice(0, 4) : "yok");
  await b.close();
})().catch(e => { console.error("FATAL:", e.message); process.exit(2); });
