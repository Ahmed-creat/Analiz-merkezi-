// Tur-17 g1 — masaüstü 1280: alan YOK + tek AYT tablo, acil/hafıza toggle,
// okul sınavları, deneme detay, QB sınır, PWA paketi ayrı testte
const { chromium } = require("playwright");
const fs = require("fs");
const APP = "file://" + encodeURI("/home/user/gelişmişuianalizmerkezi.html");
const MOCK = JSON.parse(fs.readFileSync("/home/user/analiz-merkezi/mock-data.json", "utf8")).state;

let pass = 0, fail = 0;
const ok = (n, c) => { if (c) { pass++; console.log("  ✓ " + n); } else { fail++; console.log("  ✗ " + n); } };

(async () => {
  const b = await chromium.launch();
  const pg = await b.newPage({ viewport: { width: 1280, height: 900 } });
  const errs = [];
  pg.on("pageerror", e => errs.push(String(e)));
  await pg.goto(APP, { waitUntil: "networkidle" });
  try { await pg.locator("#onb-atla").click({ timeout: 4000 }); await pg.waitForTimeout(600); } catch (e) {}
  await pg.click('.splash-grade[data-grade="9"]');
  await pg.click('[data-act="enterApp"]');
  await pg.waitForSelector("#welcome-modal", { state: "visible" });
  await pg.fill("#welcome-name", "Mehmet Yılmaz");
  await pg.click('[data-act="completeWelcome"]');
  await pg.waitForSelector("#main-content .hello-row");
  await pg.evaluate(st => localStorage.setItem("analizmerkezi_v6", JSON.stringify(st)), MOCK);
  await pg.reload({ waitUntil: "networkidle" });
  await pg.waitForTimeout(700); // dönen kullanıcı: sınıf ekranı otomatik atlanır
  await pg.waitForSelector("#main-content .hello-row");
  ok("mock: Ahmed + 4 deneme", (await pg.evaluate(() => state.exams.length)) === 4);

  // 1) Tek AYT tablosu + alan YOK
  const w = await pg.evaluate(() => ({
    mat: AYT_WEIGHT["Matematik"], tde: AYT_WEIGHT["Türk Dili ve Edebiyatı"], fiz: AYT_WEIGHT["Fizik"],
    kim: AYT_WEIGHT["Kimya"], biyo: AYT_WEIGHT["Biyoloji"], tar: AYT_WEIGHT["Tarih"], cog: AYT_WEIGHT["Coğrafya"], din: AYT_WEIGHT["Din Kültürü"]
  }));
  ok("AYT tek tablo: Mat %30, TDE %18, Tarih %15, Coğ %13", w.mat === 0.30 && w.tde === 0.18 && w.tar === 0.15 && w.cog === 0.13);
  ok("AYT tek tablo: Fizik %10.5, Kimya %9.75, Biyo %9.75, Din %5", w.fiz === 0.105 && w.kim === 0.0975 && w.biyo === 0.0975 && w.din === 0.05);
  ok("AYT_WEIGHTS (alan tabloları) YOK", (await pg.evaluate(() => typeof AYT_WEIGHTS === "undefined")));
  await pg.click('.sidebar [data-act="openSettings"]');
  await pg.waitForSelector("#settings-drawer.open");
  ok("ayarlar: ALAN bölümü KALDIRILDI", (await pg.locator("text=ALAN (PUAN TÜRÜ)").count()) === 0);
  await pg.click('#settings-drawer [data-act="closeSettings"]');
  const skorN = await pg.evaluate(() => calculatePriority().length);
  ok("öncelik listesi tek AYT tabloyla üretildi (" + skorN + " konu)", skorN > 0);

  // 2) Denemeler: 5. deneme kaydet + satır tıklama
  await pg.click('[data-nav="exams"]');
  await pg.click('[data-act="toggleExamForm"]');
  await pg.waitForSelector(".fc-body:not([hidden])");
  await pg.fill("#exam-name", "TYT Deneme 5 (Tur-17)");
  await pg.fill('[data-exam-dwb="Matematik-d"]', "28");
  await pg.fill('[data-exam-dwb="Matematik-w"]', "2");
  await pg.waitForTimeout(250);
  const ddPick = async (errKey, idx) => {
    const ddSel = 'select[data-err="' + errKey + '"] + .dd';
    await pg.click(ddSel + " .dd-btn");
    await pg.waitForSelector(ddSel + ".open .dd-opt", { state: "visible", timeout: 4000 });
    await pg.click(ddSel + ".open .dd-opt >> nth=" + idx);
    return pg.$eval('select[data-err="' + errKey + '"]', el => el.value);
  };
  const t1 = await ddPick("Matematik:0:topic", 1);
  const n1 = await ddPick("Matematik:0:type", 1);
  await ddPick("Matematik:1:topic", 2);
  await ddPick("Matematik:1:type", 1);
  ok("dd konu+neden seçildi: " + t1.slice(0, 10) + "/" + n1, !!t1 && !!n1);
  await pg.click('[data-act="saveExam"]');
  await pg.waitForTimeout(300);
  ok("5 deneme kaydedildi", (await pg.evaluate(() => state.exams.length)) === 5);
  const isim = await pg.evaluate(() => state.exams[0].name);
  await pg.click('.list-row.exam-row[data-idx="0"]');
  await pg.waitForTimeout(300);
  const detay = await pg.locator("#main-content").textContent();
  ok("deneme satırına tıkla → detay onun adı", detay.includes(isim) && detay.includes("Ders Detayları"));

  // 3) QB: sınır + 2 alan + kayıt
  await pg.click('[data-nav="questionbank"]');
  await pg.waitForSelector("#main-content h2");
  await pg.click('[data-act="toggleQBForm"]');
  await pg.waitForSelector(".fc-body:not([hidden])");
  await pg.selectOption("#qb-lesson", "Matematik");
  await pg.fill("#qb-total", "10");
  await pg.fill("#qb-d", "8");
  await pg.fill("#qb-w", "5");
  await pg.waitForTimeout(350);
  ok("SINIR: yanlış 5→2 kırpıldı", (await pg.$eval("#qb-w", el => el.value)) === "2");
  ok("QB satırı DERS selecti YOK", (await pg.locator('select[data-qberr="0:lesson"]').count()) === 0);
  const ddK = 'select[data-qberr="0:topic"] + .dd';
  await pg.click(ddK + " .dd-btn");
  await pg.waitForSelector(ddK + ".open .dd-opt", { state: "visible" });
  await pg.click(ddK + ".open .dd-opt >> nth=1");
  const ddN = 'select[data-qberr="0:type"] + .dd';
  await pg.click(ddN + " .dd-btn");
  await pg.waitForSelector(ddN + ".open .dd-opt", { state: "visible" });
  await pg.click(ddN + ".open .dd-opt >> nth=1");
  const ddK2 = 'select[data-qberr="1:topic"] + .dd';
  await pg.click(ddK2 + " .dd-btn");
  await pg.waitForSelector(ddK2 + ".open .dd-opt", { state: "visible" });
  await pg.click(ddK2 + ".open .dd-opt >> nth=2");
  const ddN2 = 'select[data-qberr="1:type"] + .dd';
  await pg.click(ddN2 + " .dd-btn");
  await pg.waitForSelector(ddN2 + ".open .dd-opt", { state: "visible" });
  await pg.click(ddN2 + ".open .dd-opt >> nth=1");
  await pg.click('[data-act="saveQB"]');
  await pg.waitForTimeout(300);
  ok("QB kaydedildi", (await pg.evaluate(() => state.questions.length)) === 4);

  // 4) Acil toggle: 10 → 20 → Daha Az → 10
  await pg.click('[data-nav="tracking"]');
  await pg.waitForSelector("text=Acil Çalışılacaklar");
  const acilN = await pg.locator(".acil-row").count();
  ok("acil liste 10 satır (" + acilN + ")", acilN === 10);
  await pg.click('[data-act="moreUrgent"]');
  await pg.waitForTimeout(300);
  const acilN2 = await pg.locator(".acil-row").count();
  ok("Daha Fazla → büyüdü (" + acilN2 + ")", acilN2 > 10);
  // kalan konu varsa bir kez daha aç → tümü görünür → buton 'Daha Az' olur
  while (await pg.locator('[data-act="moreUrgent"]:has-text("Daha Fazla")').count()) {
    await pg.click('[data-act="moreUrgent"]');
    await pg.waitForTimeout(250);
  }
  ok("tamamı açılınca buton 'Daha Az Göster'", (await pg.locator('[data-act="moreUrgent"]:has-text("Daha Az")').count()) === 1);
  await pg.click('[data-act="moreUrgent"]');
  await pg.waitForTimeout(300);
  const acilN3 = await pg.locator(".acil-row").count();
  ok("Daha Az → KAPANDI (" + acilN3 + ")", acilN3 === 10);
  ok("Hata Nedenleri kartı YOK", (await pg.locator("text=Hata Nedenleri").count()) === 0);

  // 5) Hafıza toggle: 12 konu ile 10 → 12 → 10
  await pg.evaluate(() => {
    const base = Object.values(state.memory)[0] || { lastReview: null, reviewCount: 1, completedAt: new Date().toISOString(), schedule: {} };
    const tree = CURRICULUM[state.user.grade];
    const les = Object.keys(tree)[0];
    for (let k = 0; k < 12; k++) {
      const key = les + " > " + tree[les][k];
      state.memory[key] = JSON.parse(JSON.stringify(base));
      state.memory[key].completedAt = new Date(Date.now() - k * 86400000).toISOString();
      state.memory[key].schedule = {};
    }
    saveState();
  });
  await pg.reload({ waitUntil: "networkidle" });
  await pg.waitForTimeout(700); // dönen kullanıcı: sınıf ekranı otomatik atlanır
  await pg.click('[data-nav="tracking"]');
  await pg.waitForSelector("text=Acil Çalışılacaklar");
  await pg.waitForTimeout(400);
  const hafN = await pg.locator(".hafiza-row").count();
  ok("hafıza listesi ilk 10 ile sınırlı (" + hafN + ")", hafN === 10);
  const hafBtn = await pg.locator('[data-act="moreMemory"]').count();
  ok("hafıza 'Daha Fazla' butonu var", hafBtn === 1);
  if (hafBtn) {
    await pg.click('[data-act="moreMemory"]');
    await pg.waitForTimeout(300);
    const hafN2 = await pg.locator(".hafiza-row").count();
    ok("hafıza Daha Fazla → büyüdü (" + hafN2 + ")", hafN2 > 10);
    await pg.click('[data-act="moreMemory"]');
    await pg.waitForTimeout(300);
    const hafN3 = await pg.locator(".hafiza-row").count();
    ok("hafıza Daha Az → kapandı (" + hafN3 + ")", hafN3 === 10);
  }

  // 6) Okul sınavları + takvim + bildirimler
  await pg.click('[data-nav="planning"]');
  await pg.waitForSelector("text=Okul Sınavları");
  ok("Deneme Hedefi + Okul Sınavları bölümleri", (await pg.locator("text=Deneme Hedefi").count()) >= 1 && (await pg.locator("text=Okul Sınavları").count()) >= 1);
  await pg.selectOption("#school-lesson", "Matematik");
  await pg.waitForTimeout(350);
  await pg.locator(".school-topic").nth(0).check();
  await pg.locator(".school-topic").nth(1).check();
  const yarin = await pg.evaluate(() => { const d = new Date(); d.setDate(d.getDate() + 1); return d.toISOString().slice(0, 10); });
  await pg.fill("#school-date", yarin);
  await pg.fill("#school-time", "10:00");
  await pg.click('[data-act="addSchoolExam"]');
  await pg.waitForTimeout(400);
  ok("okul sınavı eklendi", (await pg.locator("text=Matematik Sınavı").count()) >= 1);
  await pg.locator(".cal-pill.sinav").first().click();
  await pg.waitForTimeout(350);
  const sDetay = await pg.locator("#cal-detail").textContent();
  ok("gün detayı: Okul Sınavı: Matematik + 10:00 + konular", sDetay.includes("Okul Sınavı: Matematik") && sDetay.includes("10:00"));
  await pg.click('[data-act="calDayClose"]');
  await pg.evaluate(() => processDueNotifications());
  await pg.waitForTimeout(300);
  await pg.click('.sidebar [data-act="openNotif"]');
  await pg.waitForSelector("#notif-modal", { state: "visible" });
  const notif = await pg.locator("#notif-list").textContent();
  ok("Bugünün Planı + Yarın Matematik Sınavı", notif.includes("Bugünün Planı") && notif.includes("Yarın Matematik Sınav"));
  await pg.click('[data-act="closeModal"]');

  // 7) Taşma + konsol
  let overflow = 0;
  for (const p of ["dashboard", "tasks", "exams", "tracking", "library", "planning", "knowledge", "questionbank"]) {
    await pg.click('[data-nav="' + p + '"]');
    await pg.waitForTimeout(220);
    const wd = await pg.evaluate(() => document.documentElement.scrollWidth);
    if (wd > 1280) { overflow++; console.log("    taşma: " + p + " " + wd); }
  }
  ok("8 sayfa taşma 0", overflow === 0);
  ok("konsol hatası 0 (" + errs.length + ")", errs.length === 0);
  if (errs.length) console.log(errs.slice(0, 3).join("\n"));

  console.log("\nSONUÇ g1: " + pass + " ✓ / " + fail + " ✗");
  await b.close();
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error("FATAL:", e); process.exit(2); });
