const { chromium } = require("playwright");
let pass = 0, fail = 0;
const ok = (n, c) => { if (c) { pass++; console.log("  ✓ " + n); } else { fail++; console.log("  ✗ " + n); } };
(async () => {
  const b = await chromium.launch();
  const pg = await b.newPage({ viewport: { width: 1280, height: 900 } });
  const errs = [];
  pg.on("pageerror", e => errs.push(String(e).slice(0, 150)));
  await pg.goto("http://localhost:8123/index.html", { waitUntil: "networkidle" });
  await pg.click('.splash-grade[data-grade="9"]');
  await pg.click('[data-act="enterApp"]');
  await pg.waitForSelector("#welcome-modal", { state: "visible" });
  await pg.fill("#welcome-name", "T31");
  await pg.click('[data-act="completeWelcome"]');
  await pg.waitForSelector("#main-content .hello-row");
  // Butonlar var ama gizli (Chrome henüz hazır değil)
  ok("yan menüde 'Uygulamayı Yükle' butonu (gizli)", (await pg.locator('.sidebar [data-act="pwaInstall"]').count()) === 1);
  const gizli = await pg.$eval('.sidebar [data-act="pwaInstall"]', el => el.style.display === "none");
  ok("beforeinstallprompt öncesi gizli", gizli);
  // Chrome hazır olunca (beforeinstallprompt) → görünür
  await pg.evaluate(() => {
    const e = new Event("beforeinstallprompt");
    e.preventDefault = () => {};
    e.prompt = () => Promise.resolve();
    e.userChoice = Promise.resolve({ outcome: "accepted" });
    window.dispatchEvent(e);
  });
  await pg.waitForTimeout(300);
  ok("beforeinstallprompt → yan menü butonu GÖRÜNÜR", (await pg.$eval('.sidebar [data-act="pwaInstall"]', el => el.style.display)) === "");
  ok("banner GÖRÜNÜR (YÜKLE + ✕)", (await pg.$eval("#pwa-install-banner", el => el.style.display)) === "flex");
  await pg.click('#pwa-install-banner [data-act="pwaInstallDismiss"]');
  await pg.waitForTimeout(200);
  ok("✕ ile banner kapanır", (await pg.$eval("#pwa-install-banner", el => el.style.display)) === "none");
  // prompt'lu tıklama
  await pg.evaluate(() => {
    const e = new Event("beforeinstallprompt");
    e.preventDefault = () => {};
    e.prompt = () => { window.__promptCagrildi = true; return Promise.resolve(); };
    e.userChoice = Promise.resolve({ outcome: "accepted" });
    window.dispatchEvent(e);
  });
  await pg.waitForTimeout(200);
  await pg.evaluate(() => document.querySelector('.sidebar [data-act="pwaInstall"]').click());
  await pg.waitForTimeout(300);
  ok("tıklama → Chrome yükleme diyaloğu tetiklendi (prompt)", (await pg.evaluate(() => window.__promptCagrildi)) === true);
  // prompt yokken tıklama → yönlendirici toast
  await pg.evaluate(() => document.querySelector('.sidebar [data-act="pwaInstall"]').click());
  await pg.waitForTimeout(400);
  const toast = await pg.evaluate(() => Array.from(document.querySelectorAll(".toast, #toast-container > *")).map(t => t.textContent).join(" | "));
  ok("prompt yokken → menü yönlendirmesi: " + toast.slice(0, 40), toast.includes("Uygulamayı yükle") || toast.includes("Ana ekrana"));
  // Okulizyon hâlâ çalışıyor mu (regresyon)
  await pg.click("#pwa-okz-btn");
  await pg.waitForTimeout(400);
  ok("Okulizyon modalı hâlâ açılıyor (v30.1)", (await pg.evaluate(() => document.getElementById("pwa-okz-modal").style.display)) === "flex");
  ok("konsol 0 (" + errs.length + ")", errs.length === 0);
  console.log("\nSONUÇ tur31: " + pass + " ✓ / " + fail + " ✗");
  await b.close();
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error("FATAL:", e); process.exit(2); });
