# -*- coding: utf-8 -*-
"""Ahmed İbrahim'in 7 gerçek denemesi → uygulama içe aktarma JSON'u (v3 — GERÇEK SONUÇLAR).

Kaynak: "1. Deneme_ 9. S.pdf" (ders bazlı gerçek netler + yanlış/boş kazanım dökümü).

KURALLAR:
1) D sayıları GERÇEK netten: D = gerçek net + Y/4 (uygulama net = D − Y/4).
   Böylece hem ders satırı neti hem Genel Net PDF ile birebir.
2) Her denemede 8 dersin TAMAMI (TYT şablonu); kazanımsız geçen dersler tam puan.
3) Kazanımlar curriculum.js 9. sınıf konu ağacına EŞLENDİ (ahenk parçaları birleşir).
4) Nedenler: yanlış → "Konuyu Bilmiyordum", boş → "KONU EKSİKLİĞİ".
5) PDF tutarlılık notları: 6 denemede ders netleri toplamı = Genel Net (birebir).
   3. denemede Coğrafya 1,50 yazıyor ama toplamın 65,25 olması için 6,25 gerek
   (D=7, Y=3, B=2 — kazanım listesiyle de tutarlı) → 6,25 kullanıldı.
   Bazı bölümler TYT şablonundan farklı soru sayısında (D1 Din 7, D2/D4/D6 Mat 29,
   D3 Tarih 11/Kimya 9, D5 Tarih 14) → gerçek netlerin gerektirdiği değerler kullanıldı.
"""
import json, re

DIV = 4  # NET_RULE.wrongDivisor (uygulama: net = d − w/4)

TDE, MAT, FIZ, KIM, BIYO, TAR, COG, DIN = (
    "Türk Dili ve Edebiyatı", "Matematik", "Fizik", "Kimya",
    "Biyoloji", "Tarih", "Coğrafya", "Din Kültürü")

# ---- curriculum.js 9. sınıf konu adları (birebir) ----
SIIR   = "Şiir Bilgisi (Şekil Unsurları)"
SIIRT  = "Konularına Göre Şiir Türleri"
METIN  = "Metin/Edebi Metin"
PARA   = "Paragraf"
YAZIM  = "Yazım Kuralları"
NOKTA  = "Noktalama İşaretleri"
SOZSAN = "Söz Sanatları (Edebi Sanatlar)"
SOZANL = "Sözcüğün Anlam Özellikleri"
HIKAYE = "Hikâye ve İnceleme Yöntemi"
GEZI   = "Gezi Yazısı"
DENEME = "Deneme"
ANLBIC = "Anlatım Biçimleri"
ANLOZ  = "Anlatım Özellikleri (Açıklık, Duruluk)"
DUSUNCE= "Paragrafta Düşünceyi Geliştirme"
SES    = "Ses Olayları"

USLU   = "1.1 Üslü ve Köklü Sayılarla İşlemler"
ARAL   = "1.2 Aralıklar ve Küme İşlemleri"
KUME   = "1.3 Sayı Kümelerinin Özellikleri"
ISLEM  = "1.4 Gerçek Sayıların İşlem Özellikleri"
DFONK  = "2.1 Doğrusal Fonksiyonlar"
MFONK  = "2.2 Mutlak Değer Fonksiyonları"
DENK   = "2.3 Denklem ve Eşitsizlik Problemleri"
UCGEN  = "3.1 Üçgende Açı ve Kenarlar"
DONUS  = "4.1 Geometrik Dönüşümler"
ESLIK  = "4.2 Eşlik ve Benzerlik Koşulları"
ESPROB = "4.5 Eşlik/Benzerlik Problemleri"
TALES  = "4.4 Tales, Öklid ve Pisagor"
ALGO   = "5.1 Algoritma ile Problem Çözme"
MANTIK = "5.2 Mantık Bağlaçları ve Niceleyiciler (Algoritma)"
VERI   = "6.1 Tek Değişkenli Veri Analizi"

# Her ders: (gerçek D, yanlış grupları, boş grupları, kazanımsız ek boş)
EXAMS = [
 {"name": "9. Sınıf Süreç İzleme 1", "date": "2025-10-22", "net": 85.50, "L": [
   (TDE, 27, [(SIIRT,1),(SIIR,1),(SES,1)], []),
   (MAT, 11, [(USLU,2),(ARAL,3),(KUME,1)], [(USLU,7),(VERI,3),(ARAL,2),(KUME,1)]),
   (FIZ,  9, [("1.2 Fiziğin Alt Dalları",1)], []),
   (KIM,  8, [], [("1.1.1 Günlük Hayatta Kimya",2)]),
   (BIYO, 8, [("1.2 Bilim ve Bilimsel Araştırma Süreçleri",1)], [("1.1 Biyolojinin Önemi ve Katkıları",1)]),
   (TAR, 11, [("1.1 Tarih Öğrenmenin Faydaları",1)], []),
   (COG, 11, [], [("2.1.1 Mekânın Sembolik Dili: Harita",1)]),
   (DIN,  4, [("1.1 İnsan ve Yaratılış",1),("1.3 İbadet ve Dua Eden Varlık",1)], [("1.3 İbadet ve Dua Eden Varlık",1)]),
 ]},
 {"name": "9. Sınıf Süreç Tarama Serisi 1", "date": "2025-11-24", "net": 78.50, "L": [
   (TDE, 23, [(YAZIM,1),(SOZSAN,1)], [(YAZIM,1),(SOZSAN,1),(PARA,1),(ANLOZ,1),(DUSUNCE,1)]),
   (MAT,  9, [(USLU,2),(ARAL,2),(MFONK,1),(ISLEM,1)], [(USLU,6),(ARAL,2),(MFONK,2),(ISLEM,1),(KUME,2),(VERI,1)]),
   (FIZ,  8, [("1.1 Fizik Bilimi",1)], [("1.2 Fiziğin Alt Dalları",1)]),
   (KIM, 10, [], []),
   (BIYO, 9, [], [("1.5 Sınıflandırma ve Modern Yaklaşımlar",1)]),
   (TAR,  8, [("1.1 Tarih Öğrenmenin Faydaları",2)], [("1.4 Dijital Dönüşüm ve Tarih",2)]),
   (COG,  9, [("1.1.2 Niçin Coğrafya Öğrenmeliyiz?",1),("2.1.1 Mekânın Sembolik Dili: Harita",2)], []),
   (DIN,  6, [], []),
 ]},
 {"name": "9. Sınıf Akademik Gelişim Analizi 1", "date": "2025-12-23", "net": 65.25, "L": [
   (TDE, 26, [(ANLBIC,1),(METIN,1)], [(METIN,1),(PARA,1)]),
   (MAT,  8, [(USLU,3),(ARAL,1)], [(USLU,3),(ARAL,1),(ISLEM,1),(KUME,3),(DFONK,6),(MANTIK,1),(DENK,3)]),
   (FIZ,  7, [("2.1 Temel ve Türetilmiş Nicelikler",1)], [("2.3 Vektörler",1),("2.5 Hareket Türleri",1)]),
   (KIM,  2, [("1.1.4 Güvenlik ve Kimya Sallar",1),("1.2.3 Periyodik Tabloda Yer Bulma",1)],
        [("1.2.4 Periyodik Özellikler",1),("1.2.2 Orbitaller ve Elektron Dizilimi",3),("2.1.1 Metalik Bağ",1)]),
   (BIYO, 6, [("1.2 Bilim ve Bilimsel Araştırma Süreçleri",1),("1.4 Canlıların Ortak Özellikleri",3)], []),
   (TAR,  8, [("1.3 Tarihsel Bilginin Üretimi",2)], [("1.3 Tarihsel Bilginin Üretimi",1)]),
   (COG,  7, [("1.1.3 Coğrafya Biliminin Gelişimi",1),("3.1.1 Hava Olayları",2)],
        [("2.1.1 Mekânın Sembolik Dili: Harita",1),("2.1.3 Mekânsal Bilgi Teknolojileri",1)]),
   (DIN,  6, [], []),
 ]},
 {"name": "9. Sınıf ENS 2", "date": "2026-02-07", "net": 77.75, "L": [
   (TDE, 18, [(METIN,3),(PARA,2),(YAZIM,1)], [(PARA,1),(SOZSAN,1),(METIN,1),(SIIRT,1),(DENEME,1),(DUSUNCE,1)]),
   (MAT, 19, [(KUME,1),(DFONK,1),(UCGEN,3)], [(UCGEN,4),(MFONK,1)]),
   (FIZ,  5, [("2.5 Hareket Türleri",2),("2.1 Temel ve Türetilmiş Nicelikler",1),("3.1 Basınç",1)], [("2.4 Doğadaki Temel Kuvvetler",1)]),
   (KIM,  7, [("2.1.4 Lewis Nokta Yapısı",1)], [("2.1.3 Kovalent Bağ",1),("2.1.5 Polarlık ve Apolarlık",1)]),
   (BIYO, 6, [("1.6 Üçüstâlem (Domain) Sistemi",2),("1.2 Bilim ve Bilimsel Araştırma Süreçleri",1)], [("1.4 Canlıların Ortak Özellikleri",1)]),
   (TAR, 12, [], []),
   (COG, 11, [("2.1.3 Mekânsal Bilgi Teknolojileri",1)], []),
   (DIN,  5, [("3.2 Temel İbadetler",1)], []),
 ]},
 {"name": "Gis-3", "date": "2026-03-14", "net": 82.25, "L": [
   (TDE, 22, [(ANLOZ,1),(YAZIM,1),(HIKAYE,1),(SIIR,1),(GEZI,1)], [(SIIR,1),(NOKTA,1),(GEZI,1)]),
   (MAT, 13, [(USLU,2),(ISLEM,1),(ESLIK,1),(DONUS,1),(MFONK,1)],
        [(USLU,2),(DFONK,2),(ARAL,2),(TALES,2),(ESLIK,1),(DONUS,1),(MFONK,1)]),
   (FIZ,  8, [("3.2 Sıvılarda Basınç",1)], [("3.2 Sıvılarda Basınç",1)]),
   (KIM,  8, [("2.1.2 İyonik Bağ",1)], [("2.1.1 Metalik Bağ",1)]),
   (BIYO, 7, [], [("1.5 Sınıflandırma ve Modern Yaklaşımlar",3)]),
   (TAR, 14, [], []),   # net 14,00 → 14 soruluk bölüm (şablonda 12)
   (COG, 10, [("3.1.2 İklim Sistemi",2)], []),
   (DIN,  4, [], [], 2),  # net 4,00: 2 boş kazanım belirtilmemiş → yalnız sayısal
 ]},
 {"name": "9. Sınıf Yayın Denizi 2", "date": "2026-03-26", "net": 67.50, "L": [
   (TDE, 21, [(SIIR,1),(PARA,2),(SIIRT,1),(YAZIM,1),(NOKTA,1)], [(SOZANL,1),(HIKAYE,1),(SES,1)]),
   (MAT, 12, [(DFONK,1)], [(DFONK,5),(MFONK,1),(USLU,2),(VERI,1),(UCGEN,5),(ESPROB,1),(ALGO,1)]),
   (FIZ,  5, [("2.5 Hareket Türleri",2),("3.1 Basınç",1),("3.2 Sıvılarda Basınç",1)], [("3.3 Açık Hava Basıncı",1)]),
   (KIM,  6, [("1.2.3 Periyodik Tabloda Yer Bulma",1),("1.2.4 Periyodik Özellikler",1),("2.1.6 Bileşiklerin Adlandırılması",1)],
        [("2.2.1 Moleküllerarası Etkileşimler",1)]),
   (BIYO, 4, [("1.4 Canlıların Ortak Özellikleri",1),("1.6 Üçüstâlem (Domain) Sistemi",1),("2.2 Organik Moleküller",1)],
        [("1.5 Sınıflandırma ve Modern Yaklaşımlar",3)]),
   (TAR, 10, [("1.4 Dijital Dönüşüm ve Tarih",1),("2.1 Tarım Devrimi'nin Etkileri",1)], []),
   (COG,  9, [("2.1.1 Mekânın Sembolik Dili: Harita",1),("3.1.2 İklim Sistemi",2)], []),
   (DIN,  6, [], []),
 ]},
 {"name": "9. Sınıf STS 4 - Ulti 4", "date": "2026-05-22", "net": 78.50, "L": [
   (TDE, 25, [(SIIR,1),(METIN,1)], [(PARA,1),(SES,1),(NOKTA,1)]),
   (MAT, 14, [(ARAL,1)], [(DFONK,2),(UCGEN,5),(ESLIK,1),(VERI,4),(MANTIK,1),(USLU,1),(ISLEM,1)]),
   (FIZ,  6, [], [("2.2 Skaler ve Vektörel Nicelikler",1),("2.3 Vektörler",1),("2.5 Hareket Türleri",2)]),
   (KIM,  7, [("1.2.3 Periyodik Tabloda Yer Bulma",2)], [("2.2.1 Moleküllerarası Etkileşimler",1)]),
   (BIYO,  1, [("2.2 Organik Moleküller",3)], [("2.4 Enzim Aktivitesi Koşulları",3),("1.6 Üçüstâlem (Domain) Sistemi",3)]),
   (TAR, 11, [("2.1 Tarım Devrimi'nin Etkileri",1)], []),
   (COG, 12, [], []),
   (DIN,  5, [("5.1 Hz. Muhammed'in Beşeri/Peygamberlik Yönü",1)], []),
 ]},
]

# Gerçek ders netleri (PDF) — doğrulama için
GERCEK_NET = {
 "9. Sınıf Süreç İzleme 1":            {TDE:26.25, MAT:9.50,  FIZ:8.75, KIM:8.00, BIYO:7.75, TAR:10.75, COG:11.00, DIN:3.50},
 "9. Sınıf Süreç Tarama Serisi 1":     {TDE:22.50, MAT:7.50,  FIZ:7.75, KIM:10.00,BIYO:9.00, TAR:7.50,  COG:8.25,  DIN:6.00},
 "9. Sınıf Akademik Gelişim Analizi 1":{TDE:25.50, MAT:7.00,  FIZ:6.75, KIM:1.50, BIYO:5.00, TAR:7.25,  COG:6.25,  DIN:6.00},  # Coğ: PDF 1,50 → 6,25 (Genel Net 65,25'in tutması için; yazım hatası)
 "9. Sınıf ENS 2":                     {TDE:16.50, MAT:17.75, FIZ:4.00, KIM:6.75, BIYO:5.25, TAR:12.00, COG:10.75, DIN:4.75},
 "Gis-3":                              {TDE:20.75, MAT:11.50, FIZ:7.75, KIM:7.75, BIYO:7.00, TAR:14.00, COG:9.50,  DIN:4.00},
 "9. Sınıf Yayın Denizi 2":            {TDE:19.50, MAT:11.75, FIZ:4.00, KIM:5.25, BIYO:3.25, TAR:9.50,  COG:8.25,  DIN:6.00},
 "9. Sınıf STS 4 - Ulti 4":            {TDE:24.50, MAT:13.75, FIZ:6.00, KIM:6.50, BIYO:0.25, TAR:10.75, COG:12.00, DIN:4.75},
}

# ---- curriculum.js 9. sınıf ağacını yükle ----
src = open("/home/user/analiz-merkezi-gelismui/src/js/data/curriculum.js", encoding="utf-8").read()
blk9 = src[src.index("  9: {"):src.index("  10: {")]
TREE = {}
for les in [TDE, MAT, FIZ, KIM, BIYO, TAR, COG, DIN]:
    m = re.search('"' + re.escape(les) + r'":\s*\[(.*?)\]', blk9, re.S)
    TREE[les] = re.findall(r'"((?:[^"\\]|\\.)*)"', m.group(1)) if m else []

def r2(x):
    return round(x + 1e-9, 2)

exams = []
for i, d in enumerate(EXAMS):
    lessons, logs = {}, []
    qno = 0
    for blok in d["L"]:
        les, dd, ygr, bgr = blok[0], blok[1], blok[2], blok[3]
        e_extra = blok[4] if len(blok) > 4 else 0
        w = sum(n for _, n in ygr)
        e = sum(n for _, n in bgr) + e_extra
        for t, _ in ygr: assert t in TREE[les], "AĞAÇTA YOK: " + les + " > " + t
        for t, _ in bgr: assert t in TREE[les], "AĞAÇTA YOK: " + les + " > " + t
        # net doğrulaması: D − Y/4 ≈ gerçek ders neti
        net_app = r2(dd - w / DIV)
        gercek = GERCEK_NET[d["name"]][les]
        assert abs(net_app - gercek) <= 0.26, (d["name"], les, net_app, gercek)
        lessons[les] = {"d": dd, "w": w, "e": e}
        for t, n in ygr:
            for _ in range(n):
                qno += 1
                logs.append({"qno": qno, "lesson": les, "topic": t, "type": "Konuyu Bilmiyordum", "date": d["date"]})
        for t, n in bgr:
            for _ in range(n):
                qno += 1
                logs.append({"qno": qno, "lesson": les, "topic": t, "type": "KONU EKSİKLİĞİ", "date": d["date"]})
    total = sum(v["d"] + v["w"] + v["e"] for v in lessons.values())
    assert len(lessons) == 8, d["name"]
    exams.append({"id": "deneme" + str(i + 1) + "-" + str(1300 + i), "name": d["name"], "date": d["date"],
                  "lessons": lessons, "errorLogs": logs, "total": total, "net": d["net"]})
    # Genel Net doğrulaması: ders netleri toplamı ≈ Genel Net
    toplam = r2(sum(v["d"] - v["w"] / DIV for v in lessons.values()))
    print("%-38s net %6.2f | ders toplamı %6.2f | %d soru | %d hata kaydı" % (d["name"], d["net"], toplam, total, len(logs)))

state = {"user": {"name": "Ahmed İbrahim", "grade": "9", "joined": None}, "exams": exams}
out = "/home/user/ahmed-ibrahim-9-sinif-denemeleri.json"
with open(out, "w", encoding="utf-8") as f:
    json.dump(state, f, ensure_ascii=False, indent=2)

print()
print("DOSYA:", out)
print("Genel Netler:", [e["net"] for e in exams], "← PDF ile birebir")
print("Toplam hata kaydı:", sum(len(e["errorLogs"]) for e in exams),
      "· yanlış:", sum(v["w"] for e in exams for v in e["lessons"].values()),
      "· boş:", sum(v["e"] for e in exams for v in e["lessons"].values()))
print("Özgün konu:", len(set(l["lesson"] + " > " + l["topic"] for e in exams for l in e["errorLogs"])), "(hepsi ağaçtan)")
