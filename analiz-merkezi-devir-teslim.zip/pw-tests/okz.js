// Okulizyon UI e2e: buton → modal → bilgi kaydet → pending → neden seç → deneme olarak kaydet
const { chromium } = require("playwright");
let pass = 0, fail = 0;
const ok = (n, c) => { if (c) { pass++; console.log("  ✓ " + n); } else { fail++; console.log("  ✗ " + n); } };
(async () => {
  const b = await chromium.launch();
  const pg = await b.newPage({ viewport: { width: 1280, height: 900 } });
  const errs = [];
  pg.on("pageerror", e => errs.push(String(e).slice(0, 150)));
  await pg.goto("http://localhost:8123/index.html", { waitUntil: "networkidle" });
  try { await pg.locator("#onb-atla").click({ timeout: 4000 }); await pg.waitForTimeout(600); } catch (e) {}

  await pg.click('.splash-grade[data-grade="9"]');
  await pg.click('[data-act="enterApp"]');
  await pg.waitForSelector("#welcome-modal", { state: "visible" });
  await pg.fill("#welcome-name", "Okz Test");
  await pg.click('[data-act="completeWelcome"]');
  await pg.waitForSelector("#main-content .hello-row");
  ok("yan menüde Okulizyon/Giriş butonu YOK (profil merkezli)", (await pg.locator("#pwa-okz-btn").count()) === 0 && (await pg.locator("#pwa-auth-btn").count()) === 0);
  await pg.click("#sidebar-avatar");
  await pg.waitForTimeout(400);
  ok("avatar → PROFİL açıldı", (await pg.evaluate(() => document.getElementById("pwa-profile-modal").style.display)) === "flex");
  ok("profilde Okulizyon alanları + Giriş butonu", (await pg.locator("#okz-ad").count()) === 1 && (await pg.locator("#okz-okulAdi").count()) === 1 && (await pg.locator('[data-act="pwaAuth"]').count()) >= 1);
  await pg.fill("#okz-ad", "Ahmet Yılmaz");
  await pg.fill("#okz-okulNo", "1234");
  await pg.selectOption("#okz-ilce", "Şahinbey");
  await pg.selectOption("#okz-okulAdi", "Akken Anadolu Lisesi");
  await pg.click('[data-act="okzSaveBilgi"]');
  await pg.waitForTimeout(500);
  const kayit = await pg.evaluate(() => state.settings.okulizyon);
  ok("bilgiler state'e kaydedildi (BÜYÜK HARF)", kayit && kayit.ad === "AHMET YILMAZ" && kayit.okulNo === "1234" && kayit.ilce === "Şahinbey" && kayit.okulAdi === "Akken Anadolu Lisesi");
  // Kuyruk simülasyonu (Actions'ın yazdığı belge yerine doğrudan state)
  await pg.evaluate(() => {
    state.okulizyon = { pending: [], importedKeys: [], pulledAt: Date.now(), duyurular: [{ baslik: "1. Yazılılar başlıyor", url: "https://ornek.okul.tr/duyuru", tarih: "2026-09-15" }] };
    state.okulizyon.pending.push({
      name: "9/A Matematik Yazılısı", date: new Date().toISOString().slice(0, 10),
      lessons: { "Matematik": { d: 12, w: 5, e: 3 } },
      rows: [
        { qno: 3, lesson: "Matematik", topic: "1.1 Üslü ve Köklü Sayılarla İşlemler", status: "w" },
        { qno: 7, lesson: "Matematik", topic: "2.4 Oran-Orantı", status: "e" },
        { qno: 12, lesson: "Matematik", topic: "3.2 Türev", status: "w" }
      ]
    });
    saveState();
  });
  await pg.click('#pwa-profile-modal [data-act="pwaOkz"]');
  await pg.waitForTimeout(400);
  ok("profilden Okulizyon → Analiz Bekliyor 3 satır (form YOK)", (await pg.locator(".okz-reason").count()) === 3 && (await pg.locator("#pwa-okz-modal #okz-ad").count()) === 0);
  ok("DUYURU: 1 yazılı duyurusu listelendi", (await pg.locator("text=1. Yazılılar başlıyor").count()) >= 1);
  // 2 satıra neden seç (3. atla), biri hızlı butonla
  await pg.click('[data-act="okzHepsi"][data-reason="Konuyu Bilmiyordum"]');
  await pg.evaluate(() => { document.querySelectorAll(".okz-reason")[2].value = ""; }); // son satırı atla
  const once = await pg.evaluate(() => state.exams.length);
  await pg.click('[data-act="okzAnalizKaydet"]');
  await pg.waitForTimeout(600);
  const sonra = await pg.evaluate(() => state.exams.length);
  ok("deneme olarak kaydedildi (" + once + "→" + sonra + ")", sonra === once + 1);
  const ex = await pg.evaluate(() => state.exams[state.exams.length - 1]);
  ok("sınav adı + ders toplamları + net", ex.name === "Okulizyon: 9/A Matematik Yazılısı" && ex.lessons["Matematik"].d === 12 && typeof ex.net === "number");
  ok("2 hata kaydı (3. atlandı), konu+neden birebir", ex.errorLogs.length === 2 && ex.errorLogs[0].topic === "1.1 Üslü ve Köklü Sayılarla İşlemler" && ex.errorLogs[0].type === "Konuyu Bilmiyordum" && ex.errorLogs[1].topic === "2.4 Oran-Orantı");
  const pr = await pg.evaluate(() => calculatePriority().map(r => r[0]));
  ok("öncelik listesinde: Üslü + Oran-Orantı", pr.some(k => k.includes("Üslü")) && pr.some(k => k.includes("Oran-Orantı")));
  ok("pending temizlendi + importedKeys", (await pg.evaluate(() => state.okulizyon.pending.length)) === 0 && (await pg.evaluate(() => state.okulizyon.importedKeys.length)) === 1);
  ok("kaydet sonrası modal kapandı", (await pg.evaluate(() => document.getElementById("pwa-okz-modal").style.display)) === "none");
  await pg.click("#sidebar-avatar");
  await pg.waitForTimeout(300);
  await pg.click('#pwa-profile-modal [data-act="pwaOkz"]');
  await pg.waitForTimeout(300);
  ok("modal artık boş durumda (form YOK)", (await pg.locator(".okz-reason").count()) === 0 && (await pg.locator("#pwa-okz-modal #okz-ad").count()) === 0);
  ok("konsol hatası 0 (" + errs.length + ")", errs.length === 0);
  if (errs.length) console.log(errs.slice(0, 3).join("\n"));
  console.log("\nSONUÇ okz: " + pass + " ✓ / " + fail + " ✗");
  await b.close();
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error("FATAL:", e); process.exit(2); });
