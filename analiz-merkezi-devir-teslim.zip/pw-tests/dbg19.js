// Bulut senkron debug: giriş → saveState → konsol + Firestore durumu
const { chromium } = require("playwright");
const https = require("https");
function jreq(url, data, tok, method) {
  return new Promise((res) => {
    const body = data ? JSON.stringify(data) : null;
    const r = https.request(url, { method: method || (body ? "POST" : "GET"), headers: Object.assign({ "Content-Type": "application/json" }, tok ? { Authorization: "Bearer " + tok } : {}) }, (rs) => { let b = ""; rs.on("data", c => b += c); rs.on("end", () => { try { res([rs.statusCode, JSON.parse(b)]); } catch (e) { res([rs.statusCode, b]); } }); });
    r.on("error", e => res([0, String(e)]));
    if (body) r.write(body);
    r.end();
  });
}
(async () => {
  const KEY = "AIzaSyD7X9Sqn6HEoVEtjqcjw7FcFMQfrzup_Ng";
  const b = await chromium.launch();
  const pg = await b.newPage({ viewport: { width: 1280, height: 900 } });
  const logs = [];
  pg.on("console", m => logs.push(m.type().toUpperCase() + ": " + m.text().slice(0, 160)));
  pg.on("pageerror", e => logs.push("PAGEERROR: " + String(e).slice(0, 200)));
  await pg.goto("http://localhost:8123/index.html", { waitUntil: "networkidle" });
  await pg.click('.splash-grade[data-grade="9"]');
  await pg.click('[data-act="enterApp"]');
  await pg.waitForSelector("#welcome-modal", { state: "visible" });
  await pg.fill("#welcome-name", "Dbg");
  await pg.click('[data-act="completeWelcome"]');
  await pg.waitForSelector("#main-content .hello-row");
  await pg.click("#pwa-auth-btn");
  await pg.waitForTimeout(600);
  await pg.fill("#pwa-email", "smoke-test@analiz-merkezi.app");
  await pg.fill("#pwa-pass", "Test1234!kok");
  await pg.click('[data-act="pwaAuthLogin"]');
  await pg.waitForFunction(() => { const l = document.getElementById("pwa-auth-label"); return l && l.textContent.includes("Çıkış"); }, { timeout: 25000 });
  console.log("giriş ✓");
  const durum = await pg.evaluate(() => ({ hooked: !!window.__saveHooked, saveTipi: typeof saveState, uidVarMi: !!document.getElementById("pwa-auth-label").textContent.includes("smoke") }));
  console.log("hook durumu:", JSON.stringify(durum));
  await pg.evaluate(() => saveState());
  console.log("saveState çağrıldı, 9 sn bekleniyor…");
  await pg.waitForTimeout(9000);
  const r = await pg.evaluate(async () => (await fetch("manifest.json")).status);
  console.log("sayfa hâlâ canlı:", r);
  // Firestore REST kontrol
  const [, login] = await jreq(`https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${KEY}`, { email: "smoke-test@analiz-merkezi.app", password: "Test1234!kok", returnSecureToken: true });
  const [st, docu] = await jreq(`https://firestore.googleapis.com/v1/projects/analiz-merkezi-87338/databases/(default)/documents/users/${login.localId}/state/main`, null, login.idToken);
  console.log("updatedAt:", st === 200 ? docu.fields.updatedAt : st);
  console.log("--- konsol (son 15):"); logs.slice(-15).forEach(l => console.log("  " + l));
  await b.close();
})().catch(e => { console.error("FATAL:", e); process.exit(2); });
