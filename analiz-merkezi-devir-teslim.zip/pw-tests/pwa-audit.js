// PWA KURULABİLİRLİK DENETİMİ — Chrome'un tüm kriterleri tek tek
const { chromium } = require("playwright");
(async () => {
  const b = await chromium.launch();
  const pg = await b.newPage();
  await pg.goto("http://localhost:8123/index.html", { waitUntil: "networkidle" });
  await pg.waitForTimeout(1500);
  const r = await pg.evaluate(async () => {
    const out = { kriterler: {}, hatalar: [] };
    out.kriterler["Güvenli bağlam (HTTPS/localhost)"] = window.isSecureContext;
    const link = document.querySelector('link[rel="manifest"]');
    out.kriterler["Manifest <link> var"] = !!link;
    if (!link) return out;
    let m;
    try { m = await (await fetch(link.href)).json(); }
    catch (e) { out.hatalar.push("manifest okunamadı: " + e); return out; }
    out.kriterler["name + short_name"] = !!(m.name && m.short_name);
    out.kriterler["start_url ('" + m.start_url + "')"] = !!m.start_url;
    out.kriterler["display: standalone"] = m.display === "standalone";
    for (const ic of (m.icons || [])) {
      try {
        const u = new URL(ic.src, location.href).href;
        const resp = await fetch(u);
        const blob = await resp.blob();
        const dim = await new Promise(res => { const img = new Image(); img.onload = () => res(img.naturalWidth + "x" + img.naturalHeight); img.onerror = () => res("ÇÖZÜLEMEDİ"); img.src = URL.createObjectURL(blob); });
        const [w, h] = dim.split("x").map(Number);
        const boyutDogru = w === Number(ic.sizes.split("x")[0]) && h === Number(ic.sizes.split("x")[1]);
        out.kriterler["ikon " + ic.sizes + " (" + ic.purpose + ") → gerçek " + dim + " · HTTP " + resp.status] = resp.status === 200 && boyutDogru;
      } catch (e) { out.hatalar.push("ikon " + ic.src + ": " + e); }
    }
    const reg = await navigator.serviceWorker.getRegistration();
    out.kriterler["Service worker kayıtlı + aktif (scope: " + (reg ? reg.scope : "YOK") + ")"] = !!(reg && reg.active);
    if (reg && reg.active) {
      const swText = await (await fetch(reg.active.scriptURL)).text();
      out.kriterler["SW fetch handler var"] = /addEventListener\(\s*["']fetch["']/.test(swText);
      out.kriterler["SW install + activate"] = /["']install["']/.test(swText) && /["']activate["']/.test(swText);
    }
    out.kriterler["Zaten kurulu mu (standalone)"] = matchMedia("(display-mode: standalone)").matches;
    return out;
  });
  console.log("=== PWA KURULABİLİRLİK RAPORU ===");
  Object.entries(r.kriterler).forEach(([k, v]) => console.log((v ? "✓" : "✗") + " " + k));
  if (r.hatalar.length) console.log("HATALAR:", r.hatalar.join("\n"));
  await b.close();
})().catch(e => console.error("FATAL:", e));
