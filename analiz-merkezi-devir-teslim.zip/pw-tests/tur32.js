// Tur-32: onboarding karşılama + profil merkezi + DAHA etiketleri
const { chromium } = require("playwright");
let pass = 0, fail = 0;
const ok = (n, c) => { if (c) { pass++; console.log("  ✓ " + n); } else { fail++; console.log("  ✗ " + n); } };
(async () => {
  const b = await chromium.launch();
  // --- 1) İLK AÇILIŞ: onboarding ---
  let pg = await b.newPage({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
  const errs = [];
  pg.on("pageerror", e => errs.push(String(e).slice(0, 150)));
  await pg.goto("http://localhost:8123/index.html", { waitUntil: "networkidle" });
  ok("ilk açılışta onboarding görünür", (await pg.locator("#onb").count()) === 1);
  ok("logo slaytı: ANALİZ MERKEZİ", (await pg.locator("#onb").textContent()).includes("ANALİZ MERKEZİ"));
  await pg.waitForTimeout(1800); // otomatik geçiş
  ok("otomatik slayt 2: Öncelik Motoru", (await pg.locator("#onb").textContent()).includes("Öncelik Motoru"));
  await pg.locator("#onb-ileri").tap();
  await pg.waitForTimeout(300);
  ok("Devam → Hafıza Gücü slaytı", (await pg.locator("#onb").textContent()).includes("Hafıza"));
  await pg.locator("#onb-ileri").tap(); await pg.waitForTimeout(250);
  await pg.locator("#onb-ileri").tap(); await pg.waitForTimeout(250);
  ok("son slayt: BAŞLA butonu", (await pg.locator("#onb-basla").count()) === 1);
  // geri swipe (touchstart/touchend dispatch — gerçek parmak hareketi simülasyonu)
  await pg.evaluate(() => {
    const o = document.getElementById("onb");
    o.dispatchEvent(new TouchEvent("touchstart", { touches: [new Touch({ identifier: 1, target: o, clientX: 60, clientY: 300 })] }));
    o.dispatchEvent(new TouchEvent("touchend", { changedTouches: [new Touch({ identifier: 1, target: o, clientX: 320, clientY: 300 })] }));
  });
  await pg.waitForTimeout(350);
  const yazi = await pg.locator("#onb").textContent();
  ok("swipe geri → önceki slayt (Okul Sınavları)", yazi.includes("Okul Sınavları"));
  await pg.locator("#onb-ileri").tap();
  await pg.waitForTimeout(250);
  await pg.locator("#onb-basla").tap();
  await pg.waitForTimeout(600);
  ok("BAŞLA → onboarding kapandı, splash görünüyor", (await pg.locator("#onb").count()) === 0 && (await pg.locator("#splash").count()) === 1);
  ok("bayrak kaydedildi (2. açılışta gelmez)", (await pg.evaluate(() => localStorage.getItem("am_onb_v1"))) === "1");
  await pg.close();

  // --- 2) İKİNCİ AÇILIŞ: onboarding YOK ---
  pg = await b.newPage({ viewport: { width: 1280, height: 900 } });
  pg.on("pageerror", e => errs.push(String(e).slice(0, 150)));
  // dönen kullanıcı: bayrak zaten kayıtlı
  await pg.addInitScript(() => localStorage.setItem("am_onb_v1", "1"));
  await pg.goto("http://localhost:8123/index.html", { waitUntil: "networkidle" });
  await pg.waitForTimeout(400);
  ok("ikinci açılışta onboarding yok", (await pg.locator("#onb").count()) === 0);
  ok("2. açılışta sınıf seçme ekranı YOK (tanıtım yapıldıysa da atlanır)", (await pg.locator(".splash-grade").count()) === 0);
  // isim henüz yok → karşılama otomatik açılır
  await pg.waitForSelector("#welcome-modal", { state: "visible" });
  await pg.fill("#welcome-name", "T32");
  await pg.click('[data-act="completeWelcome"]');
  await pg.waitForSelector("#main-content .hello-row");
  // sınıf seçme ekranı yalnız İLK kez gelir
  await pg.reload({ waitUntil: "networkidle" });
  await pg.waitForTimeout(600);
  ok("yeniden açılışta sınıf seçme ekranı YOK (doğrudan uygulama)", (await pg.locator(".splash-grade").count()) === 0 && (await pg.locator("#main-content .hello-row").count()) >= 1);
  // --- 3) PROFİL MERKEZİ ---
  await pg.click("#sidebar-avatar");
  await pg.waitForTimeout(400);
  ok("avatar → profil açıldı", (await pg.evaluate(() => document.getElementById("pwa-profile-modal").style.display)) === "flex");
  const profMetin = await pg.locator("#pwa-profile-modal").textContent();
  ok("Profil: 'her sabah' sistem açıklaması YOK", !profMetin.includes("her sabah"));
  ok("HESAP: giriş durumu + Giriş Yap butonu", (await pg.locator("#pwa-auth-label").count()) === 1 && (await pg.locator('#pwa-profile-modal [data-act="pwaAuth"]').count()) === 1);
  let alanlarOk = true;
  for (const k of ["ad","okulNo","sinif","il","ilce","okulAdi"]) {
    if ((await pg.locator("#okz-" + k).count()) !== 1) alanlarOk = false;
  }
  ok("OKULIZYON: AD SOYAD/OKUL NO/İL/İLÇE/OKUL/SINIF", alanlarOk);
  await pg.fill("#okz-ad", "ahmet yılmaz");
  await pg.fill("#okz-okulNo", "1234");
  await pg.click('[data-act="okzSaveBilgi"]');
  await pg.waitForTimeout(400);
  const kayit = await pg.evaluate(() => state.settings.okulizyon);
  ok("kayıt büyük harf + tüm alanlar", kayit.ad === "AHMET YILMAZ" && kayit.okulNo === "1234" && kayit.il === "Gaziantep" && kayit.okulAdi === "Akken Anadolu Lisesi");
  ok("Analiz Bekliyor butonu profilde", (await pg.locator('#pwa-profile-modal [data-act="pwaOkz"]').count()) === 1);
  await pg.click('#pwa-profile-modal [data-act="pwaOkz"]');
  await pg.waitForTimeout(400);
  await pg.waitForTimeout(250);
  const okzAcik = await pg.locator("#pwa-okz-modal").isVisible();
  const formGizli = !(await pg.locator("#okz-ad").isVisible());
  ok("→ Okulizyon modalı (form yok, boş durum)", okzAcik && formGizli);
  const okzMetin = await pg.locator("#pwa-okz-modal").textContent();
  ok("Okulizyon boş durum: açıklama yazısı YOK", !okzMetin.includes("Analiz bekleyen soru yok") && !okzMetin.includes("otomatik"));
  await pg.click('[data-act="okzClose"]');
  await pg.waitForTimeout(250);
  // --- 4) giriş ekranı profilden ---
  await pg.click("#sidebar-avatar");
  await pg.waitForTimeout(300);
  await pg.click('#pwa-profile-modal [data-act="pwaAuth"]');
  await pg.waitForTimeout(600);
  ok("Giriş Yap → e-posta modalı açılır", (await pg.evaluate(() => document.getElementById("pwa-auth-modal").style.display)) === "flex");
  await pg.click('[data-act="pwaAuthClose"]');
  await pg.click('[data-act="pwaProfileClose"]');
  await pg.waitForTimeout(250);
  // --- 4b) gereksiz sistem açıklamaları YOK ---
  await pg.click('[data-nav="tasks"]');
  await pg.waitForTimeout(300);
  const govde = await pg.evaluate(() => document.body.textContent);
  ok("Görevler: 'elle işaretlenmez' YOK", !govde.includes("elle işaretlenmez"));
  ok("Ayarlar: 'AYRI HESAPTIR' YOK", !govde.includes("AYRI HESAPTIR"));
  await pg.click('[data-nav="dashboard"]');
  await pg.waitForTimeout(300);
  // --- 5) MOBİL: üst bar ismi → profil + DAHA'da giriş/okulizyon YOK ---
  await pg.setViewportSize({ width: 390, height: 844 });
  await pg.waitForTimeout(400);
  ok("mobil üst barda logo YOK", (await pg.locator(".mobile-topbar img").count()) === 0);
  ok("mobil profil simgesi (baş harfler avatarı)", (await pg.locator("#topbar-avatar").count()) === 1 && ((await pg.locator("#topbar-avatar").textContent()) || "").trim().length >= 1);
  await pg.click("#topbar-avatar");
  await pg.waitForTimeout(400);
  ok("profil simgesi → profil açıldı", (await pg.evaluate(() => document.getElementById("pwa-profile-modal").style.display)) === "flex");
  await pg.click('[data-act="pwaProfileClose"]');
  await pg.waitForTimeout(250);
  await pg.click("#topbar-name");
  await pg.waitForTimeout(400);
  ok("mobil isim tıklaması → profil açıldı", (await pg.evaluate(() => document.getElementById("pwa-profile-modal").style.display)) === "flex");
  await pg.click('[data-act="pwaProfileClose"]');
  await pg.waitForTimeout(250);
  await pg.click('[data-act="openMore"]');
  await pg.waitForTimeout(300);
  const daha = await pg.locator("#more-sheet").textContent();
  ok("DAHA'da Giriş Yap + Okulizyon YOK", !daha.includes("Giriş Yap") && !daha.includes("Okulizyon"));
  ok("konsol 0 (" + errs.length + ")", errs.length === 0);
  if (errs.length) console.log(errs.slice(0, 3).join("\n"));
  console.log("\nSONUÇ tur32: " + pass + " ✓ / " + fail + " ✗");
  await b.close();
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error("FATAL:", e); process.exit(2); });
