# GitHub Kurulumu — Sıfırdan (tarayıcıyla, ~10 dk)

GitHub'a hiçbir şey yapmadıysan buradan başla. Bu kurulum **bildirim motorunu** (sabah 07:30 / akşam 19:30 push) ve **okul çekimini** (07:00) çalıştıracak sunucuyu ücretsiz kurar.

---

## 1) GitHub hesabı + depo (2 dk)
1. [github.com](https://github.com) → üye ol / giriş yap
2. Sağ üst **+** → **New repository**
3. Repository name: `analiz-merkezi` · **Private** seç → **Create repository**

## 2) Dosyaları yükle (3 dk)
1. `analiz-merkezi-pwa.zip` indir ve bilgisayarda/telefonda **aç** (zip açıcı herhangi biri)
2. GitHub'da depo sayfasında **"uploading an existing file"** bağlantısına tıkla
3. `analiz-merkezi-pwa` **klasörünün İÇİNDEKİ** her şeyi sürükle:
   `index.html, manifest.json, sw.js, app-pwa.js, firebase-config.js, firebase-messaging-sw.js, firebase.json, README-PWA.md, icons klasörü, functions klasörü (6 .js + package.json)`
   ⚠️ Klasörü değil **içindekileri** yükle (dosyalar deponun kökünde olmalı)
4. **Commit changes** → yeşil buton

> 📱 Telefonda: dosya yöneticisinden çoklu seçim ile yükleyebilirsin; klasörler için GitHub mobil tarayıcıda "upload" hâlâ çalışır (masaüstü moduna geç).

## 3) Tek iş akışı dosyası oluştur (2 dk) — ÖNEMLİ
GitHub'un yükleme ekranı **gizli `.github` klasörünü yüklemez** — bu yüzden elle oluşturacağız (kopyala-yapıştır):

1. Depo sayfası → **Add file → Create new file**
2. Üstteki dosya adı kutusuna şunu **tam olarak** yaz:
   ```
   .github/workflows/bildirim.yml
   ```
   (nokta dahil — eğik çizgiler klasörleri otomatik oluşturur)
3. İçine: bu sohbetteki **`github-kurulum/bildirim.yml`** dosyasının İÇERİĞİNİN TAMAMINI kopyala → yapıştır
4. **Commit changes**

> Bu tek dosya hem okul çekimini (Okulizyon + okul sitesi) hem bildirimleri yönetir: sabah 07:30 çekim + tam set, akşam 19:30 yalnız kritikler.

## 4) Firebase hizmet anahtarı (2 dk)
1. [console.firebase.google.com](https://console.firebase.google.com) → projen → ⚙️ **Project settings**
2. **Service accounts** sekmesi → **Generate new private key** → json dosyası iner
3. Dosyayı not defteriyle aç → **tüm içeriği** kopyala ( `{` ile başlar `}` ile biter)

## 5) Anahtarı depoya gizli olarak ekle (1 dk)
1. GitHub → depo → **Settings** → sol menüden **Secrets and variables → Actions**
2. **New repository secret**:
   - Name: `FIREBASE_SERVICE_ACCOUNT`
   - Secret: json'un tamamını yapıştır
   - **Add secret**
3. Başka anahtar GEREKMEZ — görsel okuma Tesseract OCR kütüphanesiyle yapılır

## 6) Çalıştır + test et (1 dk)
1. Depo → **Actions** sekmesi (üstte) → açılan yeşil banner'da **Enable** / **I understand** gibi buton varsa bas
2. Sol menüde **"Bildirim Motoru"** → sağda **Run workflow** → açılan kutuda **"test"** seçeneğini **✓ işaretle** → yeşil **Run workflow** butonu
   - **test ✓** = herkese ANINDA deneme bildirimi gider (saat beklemez) — kurulumu denemek için bunu kullan
   - işaretlemezsen normal mod: sabah 07:30 tam set / akşam 19:30 yalnız kritikler (İstanbul saati)
3. Çalışan job'a tıkla → logda şu satırı görmen lazım:
   `=== BİTTİ: 0 bildirim, N pas geçilen kullanıcı ===`
   (0 bildirim normal — telefon kurulumu henüz yapılmadıysa token yok demektir; kırmızı ✗ YOKsa kurulum doğru)

---

## Kontrol listesi
- [ ] Depo **Private**
- [ ] Dosyalar kökte (index.html depoyu açınca görünüyor)
- [ ] `.github/workflows/bildirim.yml` var (Actions sekmesinde "Bildirim Motoru" görünür)
- [ ] Secret eklendi: `FIREBASE_SERVICE_ACCOUNT`
- [ ] Actions → Bildirim Motoru → Run workflow → yeşil ✓

## Güncelleme (kurulumu yapanlar — v32)
Depoda 3 dosyayı yenisiyle değiştir (her biri için: dosyayı aç → kalem ✏️ → içini sil → yenisini yapıştır → Commit):
1. `functions/bildirim-gonder.js` → bu sohbetteki **github-kurulum/bildirim-gonder.js** (TEST modu + ayrıntılı token logları)
2. `functions/okulizyon-cek.js` → **github-kurulum/okulizyon-cek.js** (İLK çekimde TÜM denemeler — 15'e kadar; sonraki çekimler 5)
3. `.github/workflows/bildirim.yml` → **github-kurulum/bildirim.yml** ("test" seçenekli)

> ⚠️ Domain değiştiği için (yeni site: **analizmerkezii.netlify.app**) eski bildirim token'ları öldü.
> Telefonda: yeni siteyi aç → **Profil (avatar) → Giriş Yap** → bildirim izni **Ver** → sonra Actions'tan **Run workflow + test ✓** → bildirim anında gelmeli.

## Sonra ne olacak?
- Her sabah **07:30** okul çekimi (yapılandırma dolunca) + tam bildirim seti; akşam **19:30** yalnız kritikler — tamamen otomatik
- Telefonda siteyi aç → uygulamayı yükle → giriş yap + bildirim izni ver → push'lar gelmeye başlar
- Hata görürsen: Actions → kırmızı koşu → logu aç → hata satırını bana yapıştır
