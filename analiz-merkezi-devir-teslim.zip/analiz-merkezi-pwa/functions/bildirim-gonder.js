// ============================================================
// ANALİZ MERKEZİ — BULUT BİLDİRİM GÖNDERİCİ (GitHub Actions çalıştırır)
// Cloud Functions/Blaze GEREKMEZ: bu betik GitHub Actions'ın ücretsiz
// sunucusunda çalışır, Firestore'u okur, FCM push gönderir.
// Mantık functions/bildirim-logic.js ile uygulamayla birebir aynı.
//
// Çalıştırma:  FIREBASE_SERVICE_ACCOUNT="<serviceAccount.json içeriği>" node bildirim-gonder.js
// Seçenekler:  SAAT=sabah|aksam (yoksa İstanbul saatine göre otomatik) · DRY_RUN=1 (göndermez, yazdırır)
// ============================================================
const { buildMessages } = require("./bildirim-logic");

const DRY = process.env.DRY_RUN === "1";
const KRITIK_ANAHTARLAR = ["schooleve@", "schooltoday@", "exam@1", ":memcrit"];
const APP_ORIGIN = (process.env.APP_ORIGIN || "https://analizmerkezii.netlify.app").replace(/\/$/, "");
const APP_URL = APP_ORIGIN + "/";
const ICON_URL = APP_ORIGIN + "/icons/icon-192.png";
function webpushOptions(extraData = {}) {
  const data = Object.assign({ url: APP_URL }, extraData);
  Object.keys(data).forEach((k) => { if (data[k] == null) delete data[k]; else data[k] = String(data[k]); });
  return {
    notification: { icon: ICON_URL, badge: ICON_URL },
    fcmOptions: { link: APP_URL },
    data
  };
}

function istanbulSaat() {
  return Number(new Date().toLocaleString("tr-TR", { timeZone: "Europe/Istanbul", hour: "numeric", hour12: false }));
}
function turkiyeBugun() {
  return new Date().toLocaleDateString("sv-SE", { timeZone: "Europe/Istanbul" }); // YYYY-MM-DD
}

async function main() {
  const cred = process.env.FIREBASE_SERVICE_ACCOUNT;
  if (!cred) {
    console.error("HATA: FIREBASE_SERVICE_ACCOUNT ortam değişkeni yok.");
    console.error("GitHub → Repo → Settings → Secrets and variables → Actions → New repository secret");
    console.error("Ad: FIREBASE_SERVICE_ACCOUNT · Değer: serviceAccountKey.json dosyasının TAM içeriği");
    process.exit(1);
  }
  let credential;
  try { credential = JSON.parse(cred); }
  catch (e) { console.error("HATA: FIREBASE_SERVICE_ACCOUNT geçerli JSON değil."); process.exit(1); }

  // firebase-admin yalnızca gerçek koşuda yüklenir (DRY/uyarı yolu bağımlılıksız çalışır)
  const admin = require("firebase-admin");
  admin.initializeApp({ credential: admin.credential.cert(credential) });
  const db = admin.firestore();
  const users = await db.collection("users").listDocuments();

  // ---- TEST MODU: her kullanıcıya doğrudan push (bekleme/tekilleştirme yok) ----
  if (process.env.TEST === "1") {
    console.log("=== TEST MODU: tüm kullanıcılara anında push ===");
    let gonderildi = 0, hata = 0;
    for (const userRef of users) {
      const t = await userRef.collection("meta").doc("fcm").get();
      if (!t.exists) { console.log("  · " + userRef.id.slice(0, 6) + "… token YOK — telefonda: uygulamayı aç → Profil → Giriş Yap → bildirim izni ver"); continue; }
      try {
        await admin.messaging().send({
          token: t.data().token,
          notification: { title: "\ud83d\udd14 Test Bildirimi \u2014 Analiz Merkezi", body: "Bildirim zinciri \u00e7al\u0131\u015f\u0131yor! Bu bir test mesaj\u0131." },
          webpush: webpushOptions({ key: "test" }),
          android: { priority: "high" }
        });
        gonderildi++; console.log("  \u2713 g\u00f6nderildi " + userRef.id.slice(0, 6) + "\u2026");
      } catch (e) {
        hata++; console.log("  \u2717 " + userRef.id.slice(0, 6) + "\u2026 " + String(e.message).slice(0, 90));
        // Gerçek FCM hata kodu: "messaging/registration-token-not-registered" ("unregistered" yazımı YOK!)
        if (/not-registered|unregistered/.test(String(e.code))) {
          await userRef.collection("meta").doc("fcm").delete();
          console.log("    \u2192 \u00f6l\u00fc token silindi: telefonda uygulamay\u0131 a\u00e7, izin ver, giri\u015Fle \u2014 yeni token kaydolur");
        }
      }
    }
    console.log("=== TEST B\u0130TT\u0130: " + gonderildi + " g\u00f6nderildi, " + hata + " hata ===");
    process.exit(0);
  }

  const saat = process.env.SAAT || (istanbulSaat() >= 17 || istanbulSaat() < 5 ? "aksam" : "sabah");
  const sadeceAksam = saat === "aksam";
  console.log("=== Analiz Merkezi bildirim turu (" + saat + (DRY ? ", KURU ÇALIŞTIRMA" : "") + ") — İstanbul " + turkiyeBugun() + " " + istanbulSaat() + ":00 ===");

  // Firestore saati Türkiye gününe göre değerlendirilsin (buildMessages simdi=İstanbul bugünü)
  const simdi = new Date(turkiyeBugun() + "T" + String(istanbulSaat()).padStart(2, "0") + ":45:00");

  let gonderilen = 0, atlanan = 0;
  for (const userRef of users) {
    const uid = userRef.id;
    const [stateSnap, tokenSnap] = await Promise.all([
      userRef.collection("state").doc("main").get(),
      userRef.collection("meta").doc("fcm").get()
    ]);
    if (!stateSnap.exists || !tokenSnap.exists) { atlanan++; console.log("  · " + uid.slice(0, 6) + "… " + (!stateSnap.exists ? "state yok" : "FCM token yok (giriş+izin gerekli)")); continue; }
    const token = tokenSnap.data().token;
    let state;
    try { state = JSON.parse(stateSnap.data().json || "{}"); } catch (e) { atlanan++; continue; }
    if (!token || !state.plan) { atlanan++; continue; }

    const hepsi = buildMessages(state, simdi);
    const liste = sadeceAksam ? hepsi.filter(m => KRITIK_ANAHTARLAR.some(k => m.key.includes(k))) : hepsi;

    const logRef = userRef.collection("meta").doc("notifLog");
    const logSnap = await logRef.get();
    const log = logSnap.exists ? logSnap.data() || {} : {};
    const bugunPrefix = turkiyeBugun();
    const yeni = {};
    // Yalnız BUGÜN gönderilen anahtarları tut (aynı gün tekrar gitmesin), eski günleri temizle
    Object.keys(log).forEach(k => { if (k.startsWith(bugunPrefix) && Object.keys(yeni).length < 500) yeni[k.slice(0, 200)] = true; });

    for (const m of liste) {
      if (log[m.key]) continue;
      if (DRY) {
        console.log("  [KURU] " + uid.slice(0, 6) + "… → " + m.title + " | " + m.body.slice(0, 80));
        yeni[m.key] = true; gonderilen++;
        continue;
      }
      try {
        await admin.messaging().send({
          token: token,
          notification: { title: m.title, body: m.body },
          webpush: webpushOptions({ key: m.key, title: m.title, body: m.body }),
          android: { priority: "high" }
        });
        console.log("  ✓ " + uid.slice(0, 6) + "… ← " + m.title);
        gonderilen++;
        yeni[m.key] = true;
      } catch (e) {
        console.warn("  ✗ " + uid.slice(0, 6) + "… " + m.title + ": " + e.message);
        if (/not-registered|unregistered/.test(String(e.code))) await userRef.collection("meta").doc("fcm").delete();
      }
    }
    if (!DRY) await logRef.set(yeni, { merge: false });
  }
  console.log("=== BİTTİ: " + gonderilen + " bildirim, " + atlanan + " pas geçilen kullanıcı ===");
  process.exit(0);
}

main().catch(e => { console.error("FATAL:", e.message); process.exit(1); });
  
