// ============================================================
// ANALİZ MERKEZİ v5.1 — UYGULAMA ÖNYÜKLEMESİ (modül: js/app.js)
// Olay delegasyonu: dinamik onclick YOK -> tırnak hatları imkansız
// ============================================================

// CDN erişilemezse uygulama yine çalışır (offline dayanıklılık)
if (typeof lucide === "undefined") { window.lucide = { createIcons: function () {} }; }
if (typeof Chart === "undefined") { window.Chart = function () { return { destroy: function () {}, update: function () {} }; }; }

document.addEventListener("DOMContentLoaded", function () {
  initOnboarding();
  loadState();
  // Dönen kullanıcı: sınıf seçme ekranı ATLAMA (sınıf değiştirme: Ayarlar → SINIF)
  let onbBitmis = false;
  try { onbBitmis = !!localStorage.getItem("am_onb_v1"); } catch (e) {}
  if ((state.user && state.user.name) || onbBitmis) {
    window.__entered = true;
    const sp = document.getElementById("splash");
    if (sp) { sp.classList.add("gone"); setTimeout(() => sp.remove(), 450); }
    if (!state.user.name) openModal("welcome-modal"); // isim henüz girilmemişse sor
  }
  checkDailyStreak();
  initChrome();
  initSidebarPreference();

  // Olay delegasyonu — tüm tıklamalar buradan geçer
  document.addEventListener("click", function (e) {
    const nav = e.target.closest("[data-nav]");
    if (nav) { navigate(nav.dataset.nav); return; }

    const el = e.target.closest("[data-act]");
    if (!el) return;
    const act = el.dataset.act;

    switch (act) {
      case "completeWelcome": completeWelcome(); break;
      case "closeConfirm": closeConfirm(); break;
      case "executeConfirm": executeConfirm(); break;
      case "closeModal": closeAllModals(); break;
      case "enterApp": { // Açılış sayfası: kapat + yeni kullanıcıysa karşılama
        const sp = document.getElementById("splash");
        if (sp) { sp.classList.add("gone"); setTimeout(() => sp.remove(), 450); }
        if (!window.__entered) { window.__entered = true; if (!state.user.name) openModal("welcome-modal"); }
        break;
      }
      case "toggleBookForm": bookFormOpen = !bookFormOpen; renderLibrary(document.getElementById("main-content")); window.scrollTo({ top: 0 }); break;
      case "toggleExamForm": examFormOpen = !examFormOpen; renderExams(document.getElementById("main-content")); window.scrollTo({ top: 0 }); break;
      case "toggleQBForm": qbFormOpen = !qbFormOpen; renderQuestionBank(document.getElementById("main-content")); window.scrollTo({ top: 0 }); break;
      case "openMore": toggleMoreSheet(); break;
      case "openSettings": closeAllModals(); closeMoreSheet(); openSettings(); break;
      case "closeSettings": closeSettings(); break;
      case "openHelp": openHelp(); break;
      case "openNotif": renderNotifList(); openModal("notif-modal"); break;
      case "markAllRead": state.notifications.forEach(function (n) { n.read = true; }); saveState(); renderNotifList(); updateBellBadges(); break;
      case "toggleNotifPermission": requestNotifPermission(); break;
      case "setTheme": setTheme(el.dataset.theme); break;
      case "toggleTheme": toggleTheme(); break;
      case "setGrade": setGrade(el.dataset.grade); break;
      case "splashGrade": splashGrade(el.dataset.grade); break;
      // Planlama: sınav kapsamı

      case "exportData": exportData(); break;
      case "confirmReset": confirmReset(el.dataset.target); break;
      case "toggleSidebar": toggleSidebar(); break;
      case "collapseSidebar": setSidebarCollapsed(true); break;
      case "openSidebarDesktop": setSidebarCollapsed(false); break;
      case "toggleCoach": toggleCoachPanel(); break;
      case "nav": navigate(el.dataset.page); break;
      // Görevler
      case "toggleTask": toggleTask(el.dataset.key); break;
      // Denemeler
      case "saveExam": saveExam(); break;
      case "deleteExam": deleteExam(el.dataset.idx); break;
      case "examDetail": examDetailSelect(Number(el.dataset.idx)); break;
      // Konu takibi
      case "startStudy": startStudy(el.dataset.topic); break;
      case "moreUrgent": moreUrgentTopics(); break;
      case "moreMemory": moreMemoryRows(); break;
      case "reviewTopic": reviewTopic(el.dataset.topic); break;
      case "earlyReview": earlyReview(el.dataset.topic); break;
      case "resetTopic": resetTopic(el.dataset.topic); break;
      // Kitaplık
      case "addBook": addBook(); break;
      case "deleteBook": deleteBook(el.dataset.idx); break;
      case "updateBookRead": updateBookRead(el.dataset.idx); break;
      // Planlama
      case "setRhythm": setRhythm(el.dataset.rhythm); break;
      case "savePlan": savePlan(); break;
      case "calPrev": calShift(-1); break;
      case "calNext": calShift(1); break;
      case "calDay": selectCalDay(el.dataset.date); break;
      case "addSchoolExam": addSchoolExam(); break;
      case "delSchoolExam": delSchoolExam(el.dataset.id); break;
      case "calDayClose": calSelected = null; renderPlanning(document.getElementById("main-content")); if (window.lucide && lucide.createIcons) lucide.createIcons(); break;
      // Bilgi bankası
      case "toggleTree": toggleTree(el.dataset.lesson); break;
      case "selectTopic": selectKnowledgeTopic(el.dataset.topic); break;
      case "completeStep": completeStep(el.dataset.topic, Number(el.dataset.step)); break;
      case "completeTopic": completeTopic(el.dataset.topic); break;
      // Soru bankası
      case "saveQB": saveQB(); break;
      case "deleteQB": deleteQB(el.dataset.idx); break;
    }
  });

  // change olayları (dosya yükleme)
  document.addEventListener("change", function (e) {
    const el = e.target.closest("[data-act-change]");
    if (!el) return;
    if (el.dataset.actChange === "importData") importData(el);
  });

  // ESC ile üst katmanları kapat
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") { closeAllModals(); closeSettings(); toggleSidebar(false); closeDDMenus(); closeMoreSheet(); }
  });

  // Açılış: uygulama açılış sayfasının ARKASINDA hazır; "Başla" ile devam
  ddify(document); // tüm native select'ler temalı özel açılır listeye dönüşür
  updateUserUI();
  navigate("dashboard");

  // Bildirim motoru: açılışta + dakikalık kontrol (tekrar saatleri, kritik hafıza)
  processDueNotifications();
  setInterval(processDueNotifications, 60000);
  setInterval(updateCountdowns, 1000);

  // Grafik ilk çizim (deneme sayfası açıksa)
  renderExamChart();

  console.log("%cANALİZ MERKEZİ V5.1 — INFINITE ENGINE AKTİF", "font-weight:bold;font-size:14px;color:#2563EB;");
});
