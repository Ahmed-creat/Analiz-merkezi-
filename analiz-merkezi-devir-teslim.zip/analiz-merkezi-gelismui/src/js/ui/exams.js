// ============================================================
// ANALİZ MERKEZİ v5.1 — DENEMELERİM / MODÜL A (modül: ui/exams.js)
// 8 TYT dersli form + dinamik hata satırları + Net Gelişimi grafiği
// ============================================================

const examForm = { lessons: {}, errorRows: [] };
let examDetailIdx = null; // null = son deneme; satıra tıklanınca o deneme
let examFormOpen = false; // Form varsayılan KAPALI — 'Yeni Deneme Ekle' ile açılır

function renderExams(container) {
  const st = examStats();
  let html = '<div class="top-bar" style="margin-bottom:14px;"><h2 style="font-size:20px;font-weight:700;">' + icon("clipboard-list", 22, "vertical-align:middle;margin-right:6px;color:var(--brand-blue);") + " Denemelerim</h2>" +
    '<button class="btn btn-primary btn-sm" data-act="toggleExamForm">' + icon(examFormOpen ? "x" : "plus", 15) + " " + (examFormOpen ? "Formu Kapat" : "Yeni Deneme Ekle") + "</button></div>";

  // Özet kartları (4 kutu)
  html += '<div class="stat-grid" style="margin-bottom:20px;">' + statBox("Toplam Deneme", st.count) + statBox("Ortalama Net", st.avg || "-") + statBox("En Yüksek Net", st.best || "-") + statBox("Son Net", st.last || "-") + "</div>";

  html += '<div class="bento-grid"><div>';
  // Form (sol panel)
  html += '<div class="bento-card" style="margin-bottom:20px;" id="exam-form-card">';
  html += '<div class="fc-body"' + (examFormOpen ? "" : " hidden") + ">";
  html += '<input type="text" id="exam-name" class="input" placeholder="Deneme Adı" style="margin-bottom:10px;">';
  html += '<input type="date" id="exam-date" class="input" value="' + todayStr() + '" style="margin-bottom:10px;">';
  html += '<div class="flex justify-between text-xs text-muted tabular" style="margin-bottom:6px;"><span>Toplam Soru</span><span id="exam-total-label">0 / 120</span></div>';
  html += '<div class="progress" style="margin-bottom:14px;"><div id="exam-total-bar" style="width:0%;background:var(--brand-gradient);"></div></div>';

  Object.keys(LESSON_CONFIG).forEach(lesson => {
    const cfg = LESSON_CONFIG[lesson];
    html += '<div class="lesson-card"><div class="lesson-head"><span style="font-weight:700;font-size:13px;">' + esc(lesson) + '</span><span class="text-xs text-muted tabular">max ' + cfg.max + "</span></div>";
    html += '<div class="dwb-row">' +
      '<div class="field d"><label>DOĞRU</label><input type="number" inputmode="numeric" min="0" max="' + cfg.max + '" data-exam-dwb="' + attr(lesson) + '-d"></div>' +
      '<div class="field w"><label>YANLIŞ</label><input type="number" inputmode="numeric" min="0" max="' + cfg.max + '" data-exam-dwb="' + attr(lesson) + '-w"></div>' +
      '<div class="field b"><label>BOŞ (OTO)</label><input type="number" inputmode="numeric" min="0" max="' + cfg.max + '" data-exam-dwb="' + attr(lesson) + '-e"></div>' +
      "</div>";
    html += '<div data-error-area="' + attr(lesson) + '"></div><div class="lesson-warn" data-lesson-warn="' + attr(lesson) + '"></div></div>';
  });

  html += '<div id="exam-validation"></div>';
  html += '<button class="btn btn-primary w-full btn-sticky" data-act="saveExam" style="margin-top:8px;">' + icon("save", 16) + " Denemeyi Kaydet</button>";
  html += "</div></div>";

  // Net gelişim grafiği
  if (st.series.length >= 2) {
    html += '<div class="bento-card"><h3 style="font-size:15px;font-weight:700;margin-bottom:12px;">' + icon("trending-up", 16, "vertical-align:middle;margin-right:6px;color:var(--brand-blue);") + " Net Gelişimi</h3><div class=\"chart-wrap\"><canvas id=\"exam-chart\"></canvas></div></div>";
  }
  html += "</div>";

  // Son denemeler (sağ)
  html += '<div><div class="bento-card"><h3 style="font-size:15px;font-weight:700;margin-bottom:8px;">' + icon("history", 16, "vertical-align:middle;margin-right:6px;color:var(--brand-blue);") + " Son Denemeler</h3>";
  if (state.exams.length) {
    html += state.exams.slice().reverse().map((ex, ri) => {
      const idx = state.exams.length - 1 - ri;
      const secili = (examDetailIdx !== null ? examDetailIdx : state.exams.length - 1) === idx;
      return '<div class="list-row exam-row' + (secili ? " active" : "") + '" style="cursor:pointer;flex-wrap:wrap;" data-act="examDetail" data-idx="' + idx + '"><div style="flex:1;min-width:0;"><div style="font-weight:600;font-size:13px;">' + esc(ex.name) + '</div>' +
        '<div class="text-xs text-muted tabular">' + fmtDate(ex.date) + " · " + ex.total + " soru · " + (ex.errorLogs || []).length + " hata kaydı</div></div>" +
        '<span class="tabular font-bold" style="color:var(--brand-blue);">' + ex.net + "</span>" +
        '<span class="badge badge-info" style="flex-shrink:0;">DETAY</span>' +
        '<button class="icon-btn" data-act="deleteExam" data-idx="' + idx + '" style="min-width:48px;min-height:48px;">' + icon("trash-2", 15, "color:var(--semantic-error);") + "</button></div>";
    }).join("");
  } else {
    html += '<div class="empty-state">' + icon("clipboard-list", 34) + "<div>İlk denemeni gir; motorlar veriyle uyanır.</div></div>";
  }
  html += "</div></div></div>";
  // Ders Detayları — SEÇİLİ denemenin ders bazlı dökümü (satıra tıklayınca değişir)
  const sonEx = state.exams[examDetailIdx !== null ? examDetailIdx : state.exams.length - 1];
  if (sonEx) {
    html += '<div class="bento-card" style="margin-top:20px;"><h3 style="font-size:15px;font-weight:700;margin-bottom:12px;">' + icon("table", 16, "vertical-align:middle;margin-right:6px;color:var(--brand-blue);") + " Ders Detayları <span class='text-xs text-muted' style='font-weight:600;'>(" + esc(sonEx.name) + ")</span></h3>";
    html += '<div class="ders-tablo"><div class="dt-baslik"><span>Ders</span><span>Doğru</span><span>Yanlış</span><span>Boş</span><span>Net</span></div>';
    Object.keys(LESSON_CONFIG).forEach(l => {
      const v = (sonEx.lessons || {})[l];
      const net = v ? Math.round(netOf(v.d, v.w) * 100) / 100 : "-";
      html += '<div class="dt-satir' + (v ? "" : " bos") + '"><span>' + esc(l) + "</span><span class='d'>" + (v ? v.d : "—") + "</span><span class='w'>" + (v ? v.w : "—") + "</span><span>" + (v ? v.e : "—") + "</span><b class='tabular'>" + net + "</b></div>";
    });
    html += "</div></div>";
  }

  container.innerHTML = html;
  ddify(container); // tüm select'ler temalı özel açılır listeye dönüşür
  bindExamForm();
  renderExamChart(); // sayfaya navigate ile gelindiğinde de grafik çizilsin
}

function examDetailSelect(idx) {
  examDetailIdx = (idx >= 0 && idx < state.exams.length) ? idx : null;
  renderExams(document.getElementById("main-content"));
  if (window.lucide && lucide.createIcons) lucide.createIcons();
}

function bindExamForm() {
  document.querySelectorAll("[data-exam-dwb]").forEach(inp => {
    inp.addEventListener("input", () => {
      const lesson = inp.dataset.examDwb.replace(/-([dwe])$/, "");
      const field = inp.dataset.examDwb.slice(-1);
      const cfg = LESSON_CONFIG[lesson];
      let vals = readLessonDWB(lesson);
      const entered = Number(inp.value) || 0;
      let clamped = false;
      // CANLI SINIR 1: negatif ve ders max'ını aşan girişler anında kırpılır
      let v = clamp(entered, 0, cfg.max);
      if (entered !== v) clamped = true;
      // CANLI SINIR 2: D + Y ders max'ını aşarsa son girilen alan kısılarak sığdırılır
      if (field !== "e" && vals.d + vals.w > cfg.max) {
        const other = field === "d" ? vals.w : vals.d;
        v = clamp(cfg.max - other, 0, cfg.max);
        clamped = true;
      }
      inp.value = v;
      vals = readLessonDWB(lesson);
      // Boş (OTO): D + Y + B = max kuralı otomatik uygulanır
      if (field !== "e") {
        const auto = clamp(cfg.max - vals.d - vals.w, 0, cfg.max);
        const eInput = document.querySelector('[data-exam-dwb="' + sel(lesson + "-e") + '"]');
        if (eInput) { eInput.value = auto; vals.e = auto; }
      }
      lessonWarn(lesson, clamped ? "Bu dersin soru sınırı " + cfg.max + " — giriş kısıldı." : "");
      updateExamTotal();
      updateExamErrorAreas(lesson, vals);
    });
    // Auto-Advance: giriş sonrası sıradaki derse odaklan (mobil klavye açık kalır)
    inp.addEventListener("keyup", e => {
      if (e.key === "Enter") {
        const all = Array.from(document.querySelectorAll("[data-exam-dwb]"));
        const i = all.indexOf(inp);
        if (i >= 0 && i < all.length - 1) all[i + 1].focus();
      }
    });
  });
  updateExamTotal();
}

function readLessonDWB(lesson) {
  const get = f => { const el = document.querySelector('[data-exam-dwb="' + sel(lesson + "-" + f) + '"]'); return Number(el && el.value) || 0; };
  return { d: get("d"), w: get("w"), e: get("e") };
}

function examAllLessons() {
  const data = {};
  Object.keys(LESSON_CONFIG).forEach(l => data[l] = readLessonDWB(l));
  return data;
}

function lessonWarn(lesson, msg) {
  const el = document.querySelector('[data-lesson-warn="' + sel(lesson) + '"]');
  if (!el) return;
  el.textContent = msg;
  el.classList.toggle("show", !!msg);
}

function updateExamTotal() {
  const data = examAllLessons();
  let total = 0, d = 0, w = 0;
  Object.values(data).forEach(v => { total += v.d + v.w + v.e; d += v.d; w += v.w; });
  const lbl = document.getElementById("exam-total-label");
  const bar = document.getElementById("exam-total-bar");
  if (lbl) lbl.textContent = total + " / 120";
  if (bar) bar.style.width = clamp((total / 120) * 100, 0, 100) + "%";
}

// Yanlış/boş sayısına göre dinamik hata satırları (Soru No, Konu, Neden)
// Değerler sayı değişse de KORUNUR (yeniden çizim sırasında geri yüklenir)
function updateExamErrorAreas(lesson, vals) {
  const area = document.querySelector('[data-error-area="' + sel(lesson) + '"]');
  if (!area) return;
  const prev = {};
  area.querySelectorAll("select[data-err]").forEach(el => {
    const parts = el.dataset.err.split(":");
    prev[parts[1] + ":" + parts[2]] = el.value;
  });
  const need = vals.w + vals.e;
  // HIZ: yanlış/boş sayısı DEĞİŞMEDİYSE satırları yeniden çizme (her tuş vuruşunda
  // 30 satır × 30 seçenek yeniden kuruluyordu → mobilde gecikme yapıyordu)
  const mevcutSatir = area.querySelectorAll(".error-log-row").length;
  const mevcutYanlis = area.querySelectorAll(".error-log-row.is-wrong").length;
  if (need > 0 && mevcutSatir === need && mevcutYanlis === vals.w) { updateErrorProgress(lesson); return; }
  const topics = topicsOfLesson(lesson);
  let html = "";
  for (let i = 0; i < need; i++) {
    const isWrong = i < vals.w;
    html += '<div class="error-log-row ' + (isWrong ? "is-wrong" : "is-empty") + '" data-row="' + i + '">' +
      '<span class="err-badge ' + (isWrong ? "wrong" : "empty") + '">' + (isWrong ? "YANLIŞ" : "BOŞ") + '<span class="n">#' + (i + 1) + "</span></span>" +
      '<div class="err-fields">' +
      '<div style="flex:1.4;min-width:0;"><span class="err-label">KONU SEÇ</span>' +
      '<select data-err="' + attr(lesson) + ":" + i + ':topic"><option value="">Konu Seç…</option>' +
      topics.map(tp => '<option value="' + attr(tp) + '">' + esc(tp) + "</option>").join("") + "</select></div>" +
      '<div style="flex:1;min-width:0;"><span class="err-label">NEDEN SEÇ</span>' +
      '<select data-err="' + attr(lesson) + ":" + i + ':type"><option value="">Neden Seç…</option>' +
      (isWrong ? WRONG_REASONS : EMPTY_REASONS).map(r => '<option value="' + attr(r) + '">' + esc(r) + "</option>").join("") + "</select></div>" +
      "</div></div>";
  }
  area.innerHTML = html;
  ddify(area); // native select gizlenir, temalı özel açılır liste takılır
  // önceki seçimleri geri yükle
  Object.entries(prev).forEach(([k, v]) => {
    const el = area.querySelector('[data-err="' + sel(lesson + ":" + k) + '"]');
    if (el && v) { try { el.value = v; ddSync(el); } catch (err) {} }
  });
  if (!area.dataset.bound) {
    area.dataset.bound = "1";
    area.addEventListener("change", () => updateErrorProgress(lesson));
    area.addEventListener("input", () => updateErrorProgress(lesson));
  }
  updateErrorProgress(lesson);
}

// "İşlenen hata: 3/10" sayacı — kaç satırda Konu+Neden seçilmiş
function updateErrorProgress(lesson) {
  const area = document.querySelector('[data-error-area="' + sel(lesson) + '"]');
  if (!area) return;
  const rows = area.querySelectorAll(".error-log-row");
  if (!rows.length) return;
  let done = 0;
  rows.forEach(r => {
    const s = r.querySelector("select");
    const s2 = r.querySelectorAll("select")[1];
    const full = !!(s && s2 && s.value && s2.value);
    if (full) done++;
    r.classList.toggle("filled", full);
  });
  const total = rows.length;
  let line = area.querySelector("[data-progress]");
  if (!line) {
    line = document.createElement("div");
    line.setAttribute("data-progress", "1");
    line.className = "text-xs";
    line.style.cssText = "margin-bottom:4px;font-weight:600;";
    area.insertBefore(line, area.firstChild);
  }
  line.textContent = "İşlenen hata: " + done + "/" + total + (done < total ? " — her yanlış/boş için Konu + Neden seç" : " ✓ tamam");
  line.style.color = done < total ? "var(--on-warning-bg)" : "var(--on-success-bg)";
}

// Her yanlış/boş satırı: Konu + Neden zorunlu, Soru No opsiyonel (boşsa sıra numarası atanır)
function collectErrorLogs(examDate) {
  const logs = [];
  const rows = {};
  document.querySelectorAll("[data-err]").forEach(el => {
    const parts = el.dataset.err.split(":");
    const k = parts[0] + ":" + parts[1];
    rows[k] = rows[k] || {};
    rows[k][parts[2]] = el.value;
  });
  Object.keys(rows).sort().forEach((k, idx) => {
    const r = rows[k];
    const lesson = k.split(":")[0];
    if (r.topic && r.type) logs.push({ qno: idx + 1, lesson: lesson, topic: r.topic, type: r.type, date: examDate || todayStr() });
  });
  return logs;
}

function saveExam() {
  const name = document.getElementById("exam-name").value.trim();
  const date = document.getElementById("exam-date").value || todayStr();
  const box = document.getElementById("exam-validation");
  const lessons = examAllLessons();
  let total = 0, d = 0, w = 0;
  const fail = msg => { box.innerHTML = '<div class="validation-msg">' + icon("alert-circle", 15) + esc(msg) + "</div>"; toast(msg, "error"); };

  if (!name) return fail("Deneme adı gerekli.");
  for (const lesson of Object.keys(lessons)) {
    const v = lessons[lesson], cfg = LESSON_CONFIG[lesson];
    const t = v.d + v.w + v.e;
    if (t > cfg.max) return fail(lesson + ": toplam soru sayısı " + cfg.max + "'yi aşamaz (şu an " + t + ").");
    if (v.d + v.w + v.e > 0 && v.d + v.w + v.e < cfg.max) { /* kısmi giriş serbest */ }
    total += t; d += v.d; w += v.w;
  }
  if (total === 0) return fail("En az bir derse D/Y/B girişi yap.");
  if (total > 120) return fail("Toplam soru sayısı 120'yi aşamaz.");

  const errorLogs = collectErrorLogs(date);
  // ZORUNLU: her yanlış ve boş soru için ayrı Konu + Neden girilmeli
  const gap = [];
  Object.keys(lessons).forEach(l => {
    const v = lessons[l];
    const need = (Number(v.w) || 0) + (Number(v.e) || 0);
    const got = errorLogs.filter(x => x.lesson === l).length;
    if (got < need) gap.push(esc(l) + " (" + (need - got) + " eksik)");
  });
  if (gap.length) return fail("Her yanlış ve boş için Konu + Neden girilmeli: " + gap.join(", ") + ".");
  const exam = { id: uid(), name: name, date: date, lessons: lessons, errorLogs: errorLogs, total: total, net: Math.round(netOf(d, w) * 100) / 100 };
  state.exams.push(exam);
  state.dailyTasks.solve = true; // 120 soru çözdün → günlük görev otomatik tamam
  ensureDailyStreakCount();
  saveState();
  evaluateBadges();
  if (state.settings.notifPermission !== "granted") requestNotifPermission(); // ilk kullanıcı hareketi (User Gesture)
  toast("Deneme kaydedildi · Net " + exam.net + " · " + errorLogs.length + " hata kaydı işlendi — Konu Takibi listesi hazır!", "success");
  examFormOpen = false;
  renderExams(document.getElementById("main-content"));
  renderExamChart();
  if (window.lucide && lucide.createIcons) lucide.createIcons();
}

function deleteExam(idx) {
  const ex = state.exams[Number(idx)];
  if (!ex) return;
  openConfirm('"' + ex.name + '" denemesi ve hata kayıtları silinecek. Emin misin?', () => {
    state.exams.splice(Number(idx), 1); saveState();
    toast("Deneme silindi.", "success"); navigate("exams");
  });
}

function renderExamChart() {
  const cv = document.getElementById("exam-chart");
  if (!cv || typeof Chart === "undefined") return;
  const st = examStats();
  try {
    if (window.__examChart) { window.__examChart.destroy(); }
    window.__examChart = new Chart(cv, {
      type: "line",
      data: { labels: st.series.map(s => s.name), datasets: [{ label: "Net", data: st.series.map(s => s.net), borderColor: cssVar("--brand-blue", "#2563EB"), backgroundColor: "rgba(37,99,235,0.08)", fill: true, tension: 0.35, pointRadius: 4, pointBackgroundColor: cssVar("--brand-blue", "#2563EB") }] },
      options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { color: cssVar("--text-muted", "#64748B") }, grid: { color: cssVar("--border-card", "#E8EEF8") } }, x: { ticks: { color: cssVar("--text-muted", "#64748B") }, grid: { color: cssVar("--border-card", "#E8EEF8") } } } }
    });
  } catch (e) { /* grafik çizilemezse sessiz atla */ }
}
