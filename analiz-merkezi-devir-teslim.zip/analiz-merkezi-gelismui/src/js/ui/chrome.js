// ============================================================
// ANALİZ MERKEZİ v5.1 — ARAYÜZ KABUĞU (modül: ui/chrome.js)
// Navigasyon, modallar, toast, çekmeceler, koç paneli, kılavuz
// ============================================================

let currentPage = "dashboard";
let confirmCallback = null;

// ===== TEMA SİSTEMİ (toplam 2 tema: Açık / Koyu — tema.pdf) =====
function currentTheme() { return document.documentElement.getAttribute("data-theme") === "dark" ? "dark" : "light"; }
function setTheme(t) {
  document.documentElement.setAttribute("data-theme", t);
  try { localStorage.setItem("am_theme", t); } catch (e) {}
  const m = document.getElementById("meta-theme");
  if (m) m.setAttribute("content", t === "dark" ? "#000000" : "#F3F7FE");
  updateThemeButtons();
}
function toggleTheme() { setTheme(currentTheme() === "dark" ? "light" : "dark"); }
function updateThemeButtons() {
  const cur = currentTheme();
  document.querySelectorAll(".theme-btn").forEach(b => b.classList.toggle("active", b.dataset.theme === cur));
  const q = document.getElementById("quick-theme");
  if (q) {
    q.innerHTML = '<i data-lucide="' + (cur === "dark" ? "sun" : "moon") + '" style="width:18px;height:18px;"></i>';
    if (window.lucide && lucide.createIcons) lucide.createIcons();
  }
}

function initChrome() {
  document.getElementById("sidebar-date").textContent = new Date().toLocaleDateString("tr-TR", { day: "numeric", month: "long", year: "numeric", weekday: "long" });
  updateThemeButtons();
  updateBellBadges();
  updateNotifPermLabel();
  renderCoachPanel();
}

function navigate(page) {
  currentPage = page;
  document.querySelectorAll(".nav-item, .bottom-nav-item").forEach(el => el.classList.toggle("active", el.dataset.nav === page));
  const content = document.getElementById("main-content");
  content.classList.remove("fade-in"); void content.offsetWidth; content.classList.add("fade-in");
  const renderers = {
    dashboard: renderDashboard, tasks: renderTasks, exams: renderExams, tracking: renderTracking,
    library: renderLibrary, planning: renderPlanning, knowledge: renderKnowledge, questionbank: renderQuestionBank
  };
  content.innerHTML = "";
  (renderers[page] || renderDashboard)(content);
  const CRUMBS = { dashboard: "Ana Sayfa", tasks: "Günlük Görevler", exams: "Denemelerim", tracking: "Konu Takibi", library: "Kitaplık", planning: "Planlama", knowledge: "Bilgi Bankası", questionbank: "Soru Bankası" };
  const crumb = document.getElementById("topbar-crumb");
  if (crumb) crumb.textContent = CRUMBS[page] || "Ana Sayfa";
  const tg = document.getElementById("topbar-grade");
  if (tg) tg.textContent = state.user.grade ? state.user.grade + ". Sınıf" : "";
  if (window.lucide && lucide.createIcons) lucide.createIcons();
  if (window.innerWidth < 1024) toggleSidebar(false);
  closeMoreSheet();
  if (typeof closeDDMenus === "function") closeDDMenus();
  if (typeof updateCountdowns === "function") updateCountdowns();
  window.scrollTo({ top: 0 });
}

// ===== DAHA SAYFASI (mobil) =====
function closeMoreSheet() {
  const sh = document.getElementById("more-sheet");
  const bd = document.getElementById("more-backdrop");
  if (sh) sh.classList.remove("open");
  if (bd) bd.style.display = "none";
}
function toggleMoreSheet() {
  const sh = document.getElementById("more-sheet");
  const bd = document.getElementById("more-backdrop");
  if (!sh) return;
  const open = !sh.classList.contains("open");
  sh.classList.toggle("open", open);
  bd.style.display = open ? "block" : "none";
}

/* ===== ÖZEL AÇILIR LİSTE (Custom Dropdown) =====
   Neden: Android/iOS'ta native select popup'ı işletim sistemi tarafından ÇİZİLİR —
   CSS theme renkleri option listesine işlemez, popup bembeyaz kalır.
   Çözüm: native select DOM'da gizli olarak kalır (değer deposu), görünür arayüz
   tamamen bizim temalı .dd buton+menümüz. Değişimde change event fırlatılır;
   mevcut tüm dinleyiciler/validasyon aynen çalışır. */
function ddify(root) {
  const sel = (root || document).querySelectorAll("select:not(.dd-done)");
  sel.forEach(function (selEl) {
    selEl.classList.add("dd-done", "dd-native");
    const wrap = document.createElement("div");
    wrap.className = "dd";
    wrap.innerHTML = '<button type="button" class="dd-btn" type="button"><span class="dd-cur"></span>' + icon("chevron-down", 16) + '</button><div class="dd-menu" hidden></div>';
    selEl.parentNode.insertBefore(wrap, selEl.nextSibling);
    const menu = wrap.querySelector(".dd-menu");
    const opts = Array.from(selEl.options).map(function (o) { return { v: o.value, t: o.textContent }; });
    if (opts.length > 12) {
      const sr = document.createElement("div");
      sr.className = "dd-search";
      sr.innerHTML = '<input type="text" placeholder="Ara…">';
      menu.appendChild(sr);
    }
    opts.forEach(function (o) {
      const b = document.createElement("button");
      b.type = "button"; b.className = "dd-opt"; b.dataset.v = o.v; b.textContent = o.t;
      menu.appendChild(b);
    });
    ddSync(selEl);
  });
}
function ddSync(selEl) {
  const wrap = selEl.nextElementSibling;
  if (!wrap || !wrap.classList || !wrap.classList.contains("dd")) return;
  const chosen = selEl.selectedOptions && selEl.selectedOptions[0];
  wrap.querySelector(".dd-cur").textContent = chosen ? chosen.textContent : "";
  wrap.classList.toggle("placeholder", !selEl.value);
  wrap.querySelectorAll(".dd-opt").forEach(function (b) { b.classList.toggle("sel", b.dataset.v === selEl.value); });
}
function closeDDMenus() {
  document.querySelectorAll(".dd.open").forEach(function (w) {
    w.classList.remove("open", "sheet");
    const m = w.querySelector(".dd-menu"); if (m) m.hidden = true;
  });
  // Portal sheet menüleri geri yerleştir
  document.querySelectorAll(".dd-menu.dd-sheet").forEach(function (m) {
    m.classList.remove("dd-sheet");
    m.hidden = true;
    if (m.__wrap) m.__wrap.appendChild(m);
  });
  ddBackdrop(false);
}
// Mobil dd alt-sheet karartma katmanı
function ddBackdrop(show) {
  let bd = document.getElementById("dd-backdrop");
  if (show) {
    if (!bd) {
      bd = document.createElement("div");
      bd.id = "dd-backdrop";
      bd.addEventListener("click", closeDDMenus);
      document.body.appendChild(bd);
    }
    bd.style.display = "block";
  } else if (bd) bd.style.display = "none";
}
function ddFilter(wrap, q) {
  q = (q || "").toLocaleLowerCase("tr");
  wrap.querySelectorAll(".dd-opt").forEach(function (b) {
    b.style.display = b.textContent.toLocaleLowerCase("tr").indexOf(q) !== -1 ? "" : "none";
  });
}
document.addEventListener("click", function (e) {
  const btn = e.target.closest(".dd-btn");
  if (btn) {
    const wrap = btn.closest(".dd");
    const wasOpen = wrap.classList.contains("open");
    closeDDMenus();
    if (!wasOpen) {
      wrap.classList.add("open");
      const m = wrap.querySelector(".dd-menu"); m.hidden = false;
      // MOBİL/YATAY (≤1023px): menü alt-sheet olarak açılır — altındaki
      // alanı (örn. NEDEN SEÇ butonu) ÖRTMEZ, tek dokunuşla iki liste de kullanılabilir
      const isCompact = window.matchMedia("(max-width: 1023px)").matches;
      if (isCompact) {
        wrap.classList.add("sheet");
        m.classList.add("dd-sheet");
        m.__wrap = wrap;
        document.body.appendChild(m); // PORTAL: menü body'ye taşınır — dokunuş kesişimi/stack sorunu olmaz
        ddBackdrop(true);
      } else {
        const r = wrap.getBoundingClientRect();
        wrap.classList.toggle("up", r.bottom + Math.min(m.scrollHeight || 260, 300) > window.innerHeight && r.top > 320);
      }
      const si = m.querySelector(".dd-search input");
      if (si) { si.value = ""; ddFilter(wrap, ""); }
    }
    return;
  }
  const opt = e.target.closest(".dd-opt");
  if (opt) {
    // Portal sheet: menü body'de olabilir — gerçek wrap menünün __wrap'ında
    const menuHost = opt.closest(".dd-menu");
    const wrap = opt.closest(".dd") || (menuHost && menuHost.__wrap);
    const selEl = wrap ? wrap.previousElementSibling : null;
    if (selEl && selEl.tagName === "SELECT") {
      selEl.value = opt.dataset.v;
      ddSync(selEl);
      selEl.dispatchEvent(new Event("change", { bubbles: true }));
    }
    closeDDMenus();
    return;
  }
  if (!e.target.closest(".dd") && !e.target.closest(".dd-menu.dd-sheet")) closeDDMenus();
});
document.addEventListener("input", function (e) {
  if (e.target.closest && e.target.closest(".dd-search")) {
    const kok = e.target.closest(".dd") || e.target.closest(".dd-menu"); // portal: menü kökü
    ddFilter(kok, e.target.value);
  }
});

// Masaüstü: yan menüyü küçült/genişlet (tercih hatırlanır — ekran yapısı §1)
function setSidebarCollapsed(collapsed) {
  document.body.classList.toggle("sb-collapsed", collapsed);
  try { localStorage.setItem("am_sidebar_collapsed", collapsed ? "1" : "0"); } catch (e) {}
}
function initSidebarPreference() {
  if (window.innerWidth >= 1024) {
    /* Gelişmiş arayüzde menü her zaman açık — daraltma kaldırıldı */
  }
}

function toggleSidebar(force) {
  const sb = document.getElementById("sidebar");
  const ov = document.getElementById("sidebar-overlay");
  const open = force !== undefined ? force : !sb.classList.contains("open");
  sb.classList.toggle("open", open);
  ov.classList.toggle("show", open);
}

function openModal(id) { document.getElementById(id).classList.add("open"); }
function closeModal(id) { document.getElementById(id).classList.remove("open"); }
function closeAllModals() { document.querySelectorAll("[data-modal]").forEach(m => m.classList.remove("open")); }

function openConfirm(message, cb) {
  document.getElementById("confirm-message").textContent = message;
  confirmCallback = cb;
  openModal("confirm-modal");
}
function closeConfirm() { confirmCallback = null; closeModal("confirm-modal"); }
function executeConfirm() { if (typeof confirmCallback === "function") confirmCallback(); closeConfirm(); }

function openSettings() { updateGradeButtons(); document.getElementById("settings-drawer").classList.add("open"); document.getElementById("settings-overlay").classList.add("show"); }
function closeSettings() { document.getElementById("settings-drawer").classList.remove("open"); document.getElementById("settings-overlay").classList.remove("show"); }

function toast(msg, type) {
  type = type || "info";
  const iconsMap = { success: "check-circle", error: "alert-circle", warning: "alert-triangle", info: "info" };
  const el = document.createElement("div");
  el.className = "toast " + type;
  el.innerHTML = icon(iconsMap[type] || "info", 16) + "<span>" + esc(msg) + "</span>";
  document.getElementById("toast-container").appendChild(el);
  setTimeout(() => { el.classList.add("hide"); setTimeout(() => el.remove(), 320); }, 3500);
}


// ===== İLK AÇILIŞ KARŞILAMA EKRANI (logo → kaydırmalı tanıtım → giriş) =====
const ONB_SLAYTLAR = [
  { logo: true, baslik: "ANALİZ MERKEZİ", alt: "Denemelerin, eksiklerin ve çalışma planın — hepsi tek uygulamada." },
  { ikon: "target", baslik: "Akıllı Öncelik Motoru", alt: "Deneme sonuçlarına göre hangi konudan başlayacağını söyleyen kişisel bir çalışma sırası edinirsin." },
  { ikon: "brain", baslik: "Hafıza Gücü + Tekrar Takvimi", alt: "Öğrendiğin konular tam unutulmadan, tam gereken günde tekrar listene düşer." },
  { ikon: "calendar-days", baslik: "Okul Sınavları Takvimi", alt: "Sınav günlerin takvimine kendiliğinden işlenir; hazırlık planın tarihe göre hazırlanır." },
  { ikon: "bell-ring", baslik: "Aklında Tutma", alt: "Çalışma saatlerin, tekrarların ve sınav günlerin bildirimle hatırlatılır — uygulamayı açık tutmana gerek yok.", son: true }
];
function initOnboarding() {
  try { if (localStorage.getItem("am_onb_v1")) return; } catch (e) { return; }
  const logoSrc = (document.querySelector(".splash-logo") || {}).src || "";
  if (!document.getElementById("onb-style")) {
    const st = document.createElement("style");
    st.id = "onb-style";
    st.textContent =
      "@keyframes onbYukari{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:none}}" +
      "@keyframes onbBelir{from{opacity:0}to{opacity:1}}" +
      "#onb .onb-icerik{animation:onbYukari .55s cubic-bezier(.22,1,.36,1) both}" +
      "#onb .onb-seg{transition:width .35s cubic-bezier(.22,1,.36,1),background .35s}" +
      "#onb-basla:hover{transform:translateY(-1px);box-shadow:0 18px 46px rgba(37,99,235,.55)!important}" +
      "#onb-ileri:hover{background:rgba(255,255,255,.2)!important}" +
      "#onb-atla:hover{background:rgba(255,255,255,.16)!important}";
    document.head.appendChild(st);
  }
  const ov = document.createElement("div");
  ov.id = "onb";
  ov.style.cssText = "position:fixed;inset:0;z-index:10000;display:flex;flex-direction:column;align-items:center;justify-content:center;color:#fff;padding:26px;transition:opacity .45s;background:radial-gradient(1100px 750px at 18% -12%,rgba(59,130,246,.38),transparent 58%),radial-gradient(900px 700px at 112% 112%,rgba(29,78,216,.42),transparent 55%),linear-gradient(160deg,#0B1220 0%,#0F1A33 48%,#16213A 100%);";
  let idx = 0, bitti = false;
  const ciz = () => {
    const sl = ONB_SLAYTLAR[idx];
    const icerik = sl.logo
      ? '<img src="' + logoSrc + '" alt="Analiz Merkezi" style="width:116px;height:116px;border-radius:28px;box-shadow:0 26px 60px rgba(0,0,0,.5),0 0 0 1px rgba(255,255,255,.18);margin-bottom:26px;">' +
        '<div style="width:44px;height:3px;border-radius:99px;background:linear-gradient(90deg,transparent,rgba(255,255,255,.75),transparent);margin:0 auto 26px;"></div>'
      : '<div style="width:96px;height:96px;border-radius:28px;background:linear-gradient(145deg,rgba(255,255,255,.17),rgba(255,255,255,.05));border:1px solid rgba(255,255,255,.22);box-shadow:0 20px 50px rgba(0,0,0,.42),inset 0 1px 0 rgba(255,255,255,.25);display:flex;align-items:center;justify-content:center;margin-bottom:26px;"><i data-lucide="' + sl.ikon + '" style="width:42px;height:42px;"></i></div>';
    const baslik = sl.logo
      ? '<div style="font-size:30px;font-weight:800;letter-spacing:.1em;margin-bottom:14px;">' + sl.baslik + "</div>"
      : '<div style="font-size:25px;font-weight:800;letter-spacing:-.01em;margin-bottom:14px;">' + sl.baslik + "</div>";
    ov.innerHTML =
      '<button id="onb-atla" style="position:absolute;z-index:2;top:calc(18px + env(safe-area-inset-top,0px));right:18px;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.18);backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);color:rgba(255,255,255,.85);border-radius:99px;padding:8px 18px;font-size:12.5px;font-weight:600;cursor:pointer;">Atla</button>' +
      '<div class="onb-icerik" style="flex:1;pointer-events:none;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;max-width:420px;">' + icerik + baslik +
      '<div style="font-size:15px;line-height:1.7;color:rgba(255,255,255,.82);">' + sl.alt + "</div></div>" +
      '<div style="display:flex;gap:6px;margin-bottom:26px;">' + ONB_SLAYTLAR.map((_, i) => '<span class="onb-seg" style="width:' + (i === idx ? "26px" : "8px") + ";height:5px;border-radius:99px;background:" + (i === idx ? "#fff" : "rgba(255,255,255,.28)") + ';"></span>').join("") + "</div>" +
      (sl.son
        ? '<button id="onb-basla" style="background:#fff;color:#1D4ED8;border:0;border-radius:16px;padding:15px 56px;font-weight:800;font-size:16px;cursor:pointer;box-shadow:0 16px 40px rgba(37,99,235,.45);transition:transform .2s,box-shadow .2s;">BAŞLA</button>'
        : '<button id="onb-ileri" style="background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.28);color:#fff;border-radius:99px;padding:12px 42px;font-weight:700;font-size:14.5px;cursor:pointer;backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px);transition:background .2s;">Devam →</button>');
    if (sl.logo) setTimeout(() => { if (!bitti && idx === 0 && document.getElementById("onb")) { idx = 1; ciz(); } }, 1600);
    if (window.lucide && lucide.createIcons) lucide.createIcons();
  };
  const bitir = () => {
    if (bitti) return;
    bitti = true;
    try { localStorage.setItem("am_onb_v1", "1"); } catch (e) {}
    ov.style.opacity = "0";
    ov.style.pointerEvents = "none"; // solma sırasında tıklamaları engellemesin
    setTimeout(() => ov.remove(), 480);
  };
  const git = (n) => { idx = Math.max(0, Math.min(ONB_SLAYTLAR.length - 1, n)); ciz(); };
  ov.addEventListener("click", (e) => {
    if (e.target.id === "onb-atla" || e.target.id === "onb-basla") bitir();
    else if (e.target.id === "onb-ileri") git(idx + 1);
  });
  let x0 = null;
  ov.addEventListener("touchstart", (e) => { x0 = e.touches[0].clientX; }, { passive: true });
  ov.addEventListener("touchend", (e) => {
    if (x0 === null) return;
    const dx = e.changedTouches[0].clientX - x0;
    if (dx < -40) git(idx + 1); else if (dx > 40) git(idx - 1);
    x0 = null;
  });
  document.body.appendChild(ov);
  ciz();
}

function updateUserUI() {
  document.getElementById("sidebar-user-name").textContent = state.user.name || "Misafir";
  document.getElementById("sidebar-user-grade").textContent = state.user.grade ? state.user.grade + ". Sınıf" : "-";
  document.getElementById("topbar-name").textContent = state.user.name || "Analiz Merkezi";
  const onbAv = document.getElementById("topbar-avatar");
  if (onbAv) {
    const kelimeler = ((state.user.name || "Analiz Merkezi") + "").trim().split(/\s+/).filter(Boolean);
    onbAv.textContent = (kelimeler.length ? kelimeler[0][0] + (kelimeler[1] ? kelimeler[1][0] : "") : "AM").toLocaleUpperCase("tr-TR");
  }
  document.getElementById("sidebar-streak").textContent = state.streak.count;
  document.getElementById("topbar-streak").textContent = state.streak.count;
  const gEl = document.getElementById("topbar-grade");
  if (gEl) gEl.textContent = state.user.grade ? state.user.grade + ". Sınıf" : "";
  updateGradeButtons();
}

// ===== SINIF DEĞİŞTİRME (Ayarlar) — AYRI HESAP MODELİ =====
// Her sınıf kendi hesabıdır: deneme/soru/kitap/hafıza/plan/rozet/bildirim
// o sınıfa aittir. Sınıf değişince eski sınıfın verisi arşivlenir
// (analizmerkezi_v6_g9 / _g10), yeni sınıfın hesabı yüklenir (yoksa boş açılır).
// Kullanıcı adı her iki hesapta korunur.
function setGrade(g) {
  if (["9", "10"].indexOf(g) < 0) return;
  const oldG = state.user.grade || "9";
  if (oldG === g) { updateGradeButtons(); return; }
  try { localStorage.setItem("analizmerkezi_v6_g" + oldG, JSON.stringify(state)); } catch (e) {}
  let saved = null;
  try { saved = localStorage.getItem("analizmerkezi_v6_g" + g); } catch (e) {}
  const adi = (state.user.name || "").trim();
  if (saved) {
    try { state = mergeDeep(freshState(), JSON.parse(saved)); } catch (e) { state = freshState(); }
  } else {
    state = freshState();
    state.user.joined = new Date().toISOString();
  }
  if (adi && !state.user.name) state.user.name = adi;
  state.user.grade = g;
  saveState();
  updateGradeButtons();
  updateUserUI();
  updateBellBadges();
  renderCoachPanel();
  toast(saved
    ? g + ". sınıf hesabına geçildi — " + g + ". sınıf kayıtların yüklendi. (" + oldG + ". sınıf verilerin ayrıca korundu.)"
    : g + ". sınıf hesabı açıldı — boş bir hesapla başlıyorsun. (" + oldG + ". sınıf verilerin ayrıca korundu.)", "success");
  navigate(currentPage);
  if (window.lucide && lucide.createIcons) lucide.createIcons();
}

// Açılış (splash) ekranındaki sınıf seçimi
function splashGrade(g) {
  window.__splashGrade = g;
  document.querySelectorAll(".splash-grade").forEach(function (b) {
    b.classList.toggle("active", b.dataset.grade === g);
  });
}

function updateGradeButtons() {
  document.querySelectorAll(".grade-btn").forEach(function (b) {
    b.classList.toggle("active", b.dataset.grade === state.user.grade);
  });
}

function completeWelcome() {
  const name = document.getElementById("welcome-name").value.trim();
  const grade = window.__splashGrade || "9";
  if (!name) { toast("Lütfen adını yaz.", "error"); return; }
  state.user = { name: name, grade: grade, joined: new Date().toISOString() };
  state.streak.lastCheck = todayStr();
  saveState();
  closeModal("welcome-modal");
  updateUserUI();
  toast("Hoş geldin, " + name + "! Motorlar çalışıyor.", "success");
  navigate("dashboard");
}

// ===== GÜNLÜK SERİ + FREEZE (haftalık 1 dondurma hakkı) =====
function isoWeek(d) {
  const dt = new Date(d); dt.setHours(0, 0, 0, 0);
  dt.setDate(dt.getDate() + 4 - (dt.getDay() || 7));
  const yearStart = new Date(dt.getFullYear(), 0, 1);
  return Math.ceil((((dt - yearStart) / 86400000) + 1) / 7);
}

function checkDailyStreak() {
  const today = todayStr();
  if (!state.dailyTasks.date) { state.dailyTasks.date = today; saveState(); return; }
  if (state.dailyTasks.date === today) return;
  const yest = new Date(); yest.setDate(yest.getDate() - 1); yest.setHours(0, 0, 0, 0);
  const yStr = toDayStr(yest);
  const anyDoneYesterday = state.dailyTasks.study || state.dailyTasks.read || state.dailyTasks.solve;
  if (state.dailyTasks.date !== yStr || !anyDoneYesterday) {
    const gap = state.dailyTasks.date !== yStr && state.dailyTasks.date !== today;
    if (gap) {
      const thisWeek = isoWeek(new Date()) + "-" + new Date().getFullYear();
      const freezeAvailable = state.streak.freezeWeek !== thisWeek;
      if (state.streak.count > 0 && freezeAvailable) {
        state.streak.freezeWeek = thisWeek; state.streak.freezeUsed = true;
        addNotification({ title: "Seri Donduruldu (Streak Freeze)", body: "1 günlük boşluk serini yakmadı. Bu haftalık dondurma hakkın kullanıldı.", kind: "info" });
      } else if (state.streak.count > 0) {
        state.streak.count = 0;
        addNotification({ title: "Seri Söndü", body: "Dün hiçbir görev yapılmadı ve dondurma hakkı yoktu. Yeni seriyi bugün başlat!", kind: "info" });
      }
    }
  }
  state.dailyTasks = { study: false, read: false, solve: false, date: today };
  saveState();
}

// ===== NUDGE KARTI (günlük check-in; ekranı kilitlemez, dürtür) =====
function renderNudge() {
  const t = state.dailyTasks;
  const done = t.study || t.read || t.solve;
  if (done) return "";
  return '<div class="nudge-card">' + icon("hand-metal", 20) +
    '<div style="flex:1;"><div style="font-weight:700;font-size:14px;color:var(--on-warning-bg);">Günlük Check-in bekliyor</div>' +
    '<div style="font-size:12.5px;color:var(--on-warning-bg-soft);">Bugün ders çalıştın mı? Kitap okudun mu? Serini korumak için 1 dakika ayır.</div></div>' +
    '<button class="btn btn-sm btn-ghost" data-act="nav" data-page="tasks" style="background:var(--bg-card);border-color:rgba(245,158,11,0.4);color:var(--on-warning-bg);">Git</button></div>';
}

// ===== KOÇLUK PANELİ =====
function toggleCoachPanel() {
  document.getElementById("coach-panel").classList.toggle("hidden");
}
function renderCoachPanel() {
  const box = document.getElementById("coach-messages");
  if (box) box.innerHTML = coachMessages().map(m => '<div class="coach-msg">' + m + "</div>").join("");
}

// ===== KULLANIM KILAVUZU =====
const HELP_MODULES = [
  { icon: "clipboard-list", color: "var(--brand-blue)", title: "Denemelerim (Modül A)", text: "Uygulamanın tüm veri giriş merkezi. 8 TYT dersinin D/Y/B girişini yap; yanlış ve boşlarda Soru No + Konu + Neden satırları otomatik açılır. Her hata, Priorite motoruna beslenir." },
  { icon: "radar", color: "var(--memory-indigo)", title: "Konu Takibi (Modül B)", text: "Laplace düzeltmeli Priorite Puanı'na göre Acil Çalışılacaklar listesi, ders başarı oranları ve Ebbinghaus Hafıza Gücü takibi. %20 altı konular için ACİL TEKRAR butonu çıkar." },
  { icon: "library", color: "#059669", title: "Kitaplık (Modül C)", text: "Okuma disiplinini SKYA hatalarıyla ilişkilendirir. Günlük sayfa girişi yap; Disiplin Puanı, Okuma Hızı ve (5+ deneme sonrası) Bilişsel Kondisyon Eğilimi hesaplanır." },
  { icon: "calendar-clock", color: "var(--semantic-warning)", title: "Planlama (Modül D)", text: "Sınav tarihi + hedef net ile tersine planlama: Haftalık İvme Hedefi = (HedefNet - MevcutOrt) / KalanHafta. Sirkadiyen ritmine göre Altın Saat konuları atanır." },
  { icon: "graduation-cap", color: "var(--brand-blue)", title: "Bilgi Bankası (Modül E)", text: "Müfredat ağacından konu seç; 4 adımlı kanıta dayalı motor çalışır: 0) Ön Test (bilişsel kanca) → 1) Aktif Çalışma → 2) Çözümlü Örnek → 3) Karışık Pratik. Adımlar sıralı kilitlidir. Tamamlandığında 3-7-14-21-28 gün tekrar takvimi kurulur." },
  { icon: "pen-tool", color: "var(--semantic-error)", title: "Soru Bankası (Modül F)", text: "Günlük çözümlerini gir; zorluk seviyesi önerisi al (≤%40 TEMEL, ≤%75 ORTA, >%75 ZOR/YENİ NESİL). Denemelerle aynı analitik motora bağlanır (1.0x ağırlık)." },
  { icon: "check-square", color: "#059669", title: "Günlük Görevler (Modül G)", text: "Streak (seri) sistemi. Haftada 1 Streak Freeze hakkın var: bir gün boş geçse bile serin yanmaz." }
];

function openHelp() {
  const box = document.getElementById("help-content");
  box.innerHTML =
    HELP_MODULES.map(m =>
      '<div class="bento-card" style="padding:16px;margin-bottom:12px;"><h4 style="color:' + m.color + ';margin-bottom:6px;">' + icon(m.icon, 16, "vertical-align:middle;margin-right:4px;") + " " + m.title + "</h4>" +
      '<p style="font-size:13px;color:var(--text-muted);">' + m.text + "</p></div>"
    ).join("") +
    '<div class="bento-card" style="padding:16px;background:var(--memory-indigo-bg);border:none;">' +
      "<h4 style=\"color:var(--memory-indigo);margin-bottom:8px;\">" + icon("brain", 16, "vertical-align:middle;margin-right:4px;") + ' Bilimsel Algoritmalar</h4>' +
      '<ul style="font-size:12.5px;color:var(--text-main);padding-left:18px;display:flex;flex-direction:column;gap:6px;">' +
      "<li><b>Ebbinghaus:</b> Hafıza %100'den başlar, üstel sönümle azalır. Her tekrar unutma hızını %10 yavaşlatır.</li>" +
      "<li><b>Cepeda %10-20 kuralı:</b> İdeal tekrar aralığı = max(1, round(KalanGün × 0.15)). Sınav yaklaştıkça aralıklar otomatik sıklaşır.</li>" +
      "<li><b>Laplace düzeltmeli Priorite:</b> [1.5·Deneme + 1.0·Test + 0.5·(İşlem+Anlama)] × (1 + AYT Ağırlığı).</li>" +
      "<li><b>Çapraz ilişkilendirme:</b> İlişkili konular (ör. Trigonometri ↔ Dalgalar) arasındaki başarı farkı %30'u aşarsa Kök Eksik Uyarısı üretilir.</li>" +
      "</ul></div>" +
    '<div class="bento-card" style="padding:16px;margin-top:12px;"><h4 style="color:var(--semantic-warning);margin-bottom:8px;">' + icon("zap", 16, "vertical-align:middle;margin-right:4px;") + ' Pro İpuçları</h4>' +
      '<ul style="font-size:12.5px;color:var(--text-muted);padding-left:18px;display:flex;flex-direction:column;gap:5px;">' +
      "<li>Haftalık ivmenin altında kalmamak için her denemeden sonra Modül B'yi kontrol et.</li>" +
      "<li>Son haftada yeni konu açma; sadece kırmızı hataları tarama (rejim tablosu Planlama'da).</li>" +
      "<li>Verilerini Ayarlar → Dışa Aktar ile haftada bir yedekle.</li>" +
      "</ul></div>";
  if (window.lucide && lucide.createIcons) lucide.createIcons();
  openModal("help-modal");
}

// ===== GERİ SAYIM (canlı) =====
function updateCountdowns() {
  document.querySelectorAll("[data-countdown]").forEach(el => {
    const target = parseDay(el.dataset.countdown);
    if (!target) return;
    const now = new Date();
    let s = Math.floor((target - now) / 1000);
    if (s < 0) s = 0;
    const d = Math.floor(s / 86400), h = Math.floor((s % 86400) / 3600), mnt = Math.floor((s % 3600) / 60), sec = s % 60;
    const set = (sel, v) => { const x = el.querySelector(sel); if (x) x.textContent = String(v).padStart(2, "0"); };
    set(".days", d); set(".hours", h); set(".minutes", mnt); set(".seconds", sec);
  });
}
