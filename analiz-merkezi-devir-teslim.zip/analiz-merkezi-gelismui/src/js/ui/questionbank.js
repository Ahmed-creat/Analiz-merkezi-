// ============================================================
// ANALİZ MERKEZİ v5.1 — SORU BANKASI / MODÜL F (modül: ui/questionbank.js)
// Zorluk önerisi + günlük D/Y grafiği (yığılmış) + son çözümler
// ============================================================

let qbFormOpen = false; // Form varsayılan KAPALI

function renderQuestionBank(container) {
  const pr = calculatePriority();
  let html = '<div class="top-bar" style="margin-bottom:14px;"><h2 style="font-size:20px;font-weight:700;">' + icon("pen-tool", 22, "vertical-align:middle;margin-right:6px;color:var(--brand-blue);") + " Soru Bankası</h2>" +
    '<button class="btn btn-primary btn-sm" data-act="toggleQBForm">' + icon(qbFormOpen ? "x" : "plus", 15) + " " + (qbFormOpen ? "Formu Kapat" : "Soru Girişi Aç") + "</button></div>";
  html += '<!--QBKPI-->';

  // Zorluk önerisi (Akıllı Filtre)
  html += '<div class="bento-card" style="margin-bottom:20px;"><h3 style="font-size:15px;font-weight:700;margin-bottom:10px;">' + icon("filter", 16, "vertical-align:middle;margin-right:6px;color:var(--semantic-warning);") + " Akıllı Zorluk Filtresi</h3>";
  if (pr.length) {
    html += '<p class="text-xs text-muted" style="margin-bottom:10px;">Başarı yüzdesine göre önerilen soru tipi: ≤%40 TEMEL · ≤%75 ORTA · >%75 ZOR/YENİ NESİL</p>';
    html += pr.slice(0, 4).map(p => {
      const d = difficultyFor(p[0]);
      return '<div class="topic-row"><span class="topic-rank">' + icon("zap", 13) + '</span><div class="topic-info"><span style="font-weight:600;font-size:13.5px;">' + esc(splitKey(p[0]).topic) + '</span><span class="text-xs text-muted">' + esc(splitKey(p[0]).lesson) + '</span></div>' +
        '<span class="badge" style="background:' + d.color + '22;color:' + d.color + ';">' + d.level + (d.rate !== null ? " · %" + d.rate : "") + "</span></div>";
    }).join("");
  } else {
    html += '<div class="empty-state">' + icon("filter", 30) + "<div>Deneme/soru verisi girince hatalı konulara göre zorluk seviyesi önerilir.</div></div>";
  }
  html += "</div>";

  // Giriş formu
  html += '<div class="bento-card" style="margin-bottom:20px;" id="qb-form-card">';
  html += '<div class="fc-body"' + (qbFormOpen ? "" : " hidden") + ">";
  html += '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px;">' +
    '<div><label class="text-xs text-muted">Ders</label><select id="qb-lesson" class="select"><option value="">Ders Seç…</option>' +
    Object.keys(LESSON_CONFIG).map(l => '<option value="' + attr(l) + '">' + esc(l) + "</option>").join("") + "</select></div>" +
    '<div><label class="text-xs text-muted">Tarih</label><input type="date" id="qb-date" class="input" value="' + todayStr() + '"></div>' +
    '<div><label class="text-xs text-muted">Toplam Çözülen</label><input type="number" inputmode="numeric" id="qb-total" class="input" min="1" placeholder="0"></div>' +
    "</div>";
  html += '<div class="dwb-row" style="margin-top:10px;">' +
    '<div class="field d"><label>DOĞRU</label><input type="number" inputmode="numeric" id="qb-d" min="0" placeholder="0"></div>' +
    '<div class="field w"><label>YANLIŞ</label><input type="number" inputmode="numeric" id="qb-w" min="0" placeholder="0"></div>' +
    '<div class="field b"><label>BOŞ</label><input type="number" inputmode="numeric" id="qb-e" min="0" placeholder="0"></div></div>';
  html += '<div id="qb-error-area" style="margin-top:10px;"></div>';
  html += '<div id="qb-validation"></div>';
  html += '<button class="btn btn-primary w-full btn-sticky" data-act="saveQB" style="margin-top:8px;">' + icon("save", 15) + " Kaydet</button>";
  html += "</div></div>";

  // Günlük çözüm grafiği
  if (state.questions.length >= 2) {
    html += '<div class="bento-card" style="margin-bottom:20px;"><h3 style="font-size:15px;font-weight:700;margin-bottom:12px;">' + icon("bar-chart-3", 16, "vertical-align:middle;margin-right:6px;color:var(--brand-blue);") + ' Günlük Çözüm İstatistikleri</h3><div class="chart-wrap"><canvas id="qb-chart"></canvas></div></div>';
  }

  // Son çözümler
  html += '<div class="bento-card"><h3 style="font-size:15px;font-weight:700;margin-bottom:8px;">Son Çözümler</h3>';
  if (state.questions.length) {
    html += state.questions.slice().reverse().map((q, ri) => {
      const idx = state.questions.length - 1 - ri;
      const noLog = (q.errorLogs || []).length === 0 && (q.w + q.e) > 0;
      return '<div class="list-row"><div style="flex:1;min-width:0;"><div style="font-weight:600;font-size:13px;">' + esc(q.lesson) + '</div>' +
        '<div class="text-xs text-muted tabular">' + fmtDate(q.date) + " · " + q.total + " soru · D" + q.d + "/Y" + q.w + "/B" + q.e + (noLog ? ' · <span style="color:var(--on-warning-bg-soft);">⚠ hata kaydı girilmedi</span>' : "") + "</div></div>" +
        '<button class="icon-btn" data-act="deleteQB" data-idx="' + idx + '" style="min-width:48px;min-height:48px;">' + icon("trash-2", 15, "color:var(--semantic-error);") + "</button></div>";
    }).join("");
  } else {
    html += '<div class="empty-state">' + icon("pen-tool", 34) + "<div>Günlük çözümlerini gir; grafik ve öneriler oluşsun.</div></div>";
  }
  html += "</div>";

  // KPI satırı (§10: Toplam Çözülen · Doğru · Yanlış · Başarı)
  {
    let td = 0, tw = 0, te = 0;
    state.questions.forEach(q => { td += q.d || 0; tw += q.w || 0; te += q.e || 0; });
    const toplam = td + tw + te;
    const basari = toplam ? Math.round(td / toplam * 100) : 0;
    const kp = examStats; // (yoksay)
    html = html.replace("<!--QBKPI-->",
      '<div class="stat-grid" style="margin-bottom:18px;">' +
      '<div class="bento-card stat-box" style="border-top:3px solid var(--brand-blue);"><div class="flex items-center justify-between"><span class="text-xs text-muted" style="font-weight:700;letter-spacing:0.05em;">TOPLAM ÇÖZÜLEN</span></div><div class="tabular" style="font-size:23px;font-weight:800;margin-top:4px;">' + toplam + "</div></div>" +
      '<div class="bento-card stat-box" style="border-top:3px solid var(--semantic-success);"><div class="flex items-center justify-between"><span class="text-xs text-muted" style="font-weight:700;letter-spacing:0.05em;">DOĞRU</span></div><div class="tabular" style="font-size:23px;font-weight:800;margin-top:4px;color:var(--semantic-success);">' + td + "</div></div>" +
      '<div class="bento-card stat-box" style="border-top:3px solid var(--semantic-error);"><div class="flex items-center justify-between"><span class="text-xs text-muted" style="font-weight:700;letter-spacing:0.05em;">YANLIŞ</span></div><div class="tabular" style="font-size:23px;font-weight:800;margin-top:4px;color:var(--semantic-error);">' + tw + "</div></div>" +
      '<div class="bento-card stat-box" style="border-top:3px solid var(--memory-indigo);"><div class="flex items-center justify-between"><span class="text-xs text-muted" style="font-weight:700;letter-spacing:0.05em;">BAŞARI</span></div><div class="tabular" style="font-size:23px;font-weight:800;margin-top:4px;color:var(--memory-indigo);">%' + basari + "</div></div>" +
      "</div>");
  }

  container.innerHTML = html;
  ddify(container); // tüm select'ler (Ders dahil) temalı özel açılır listeye dönüşür
  bindQBForm();
  renderQBChart();
}

function bindQBForm() {
  const d = document.getElementById("qb-d"), w = document.getElementById("qb-w"), e = document.getElementById("qb-e"), t = document.getElementById("qb-total");
  const lessonSel = document.getElementById("qb-lesson");
  const live = document.getElementById("qb-validation");
  const refresh = () => {
    // CANLI SINIR: negatif ve abartılı girişler anında kırpılır
    [d, w, e].forEach(el => { if (el) el.value = clamp(Number(el.value) || 0, 0, 999); });
    let dv = Number(d.value) || 0, wv = Number(w.value) || 0, ev = Number(e.value) || 0;
    let total = Number(t.value) || 0;
    // Toplam otomatik türetilir — ANCAK kullanıcı toplamı elle girdiyse dokunma
    // (SINIR: D+Y+B elle girilen toplamı AŞAMAZ, clampQB kırpar)
    if (!t || !t.dataset.user) {
      if (total < dv + wv + ev) total = dv + wv + ev;
      if (t) t.value = total || "";
    }
    // CANLI VALIDASYON (kırmızı kutu — ekran yapısı Modül F)
    const msgs = [];
    if (total > 200) msgs.push("Tek girişte en fazla 200 soru girebilirsin.");
    if (lessonSel && !lessonSel.value && (wv + ev) > 0) msgs.push("Yanlış/boş konusu girebilmek için önce Ders seçmelisin.");
    if (live) live.innerHTML = msgs.length ? '<div class="validation-msg">' + icon("alert-circle", 15) + esc(msgs[0]) + "</div>" : "";
    updateQBErrors(dv, wv, ev);
  };

  // SINIR: D+Y+B, "Toplam Çözülen"i aşamaz (aşılan giriş anında kırpılır)
  const clampQB = (changed) => {
    const capRaw = Number(t.value) || 0;
    const cap = capRaw > 0 ? capRaw : 200;
    const dig = { d: Number(d.value) || 0, w: Number(w.value) || 0, e: Number(e.value) || 0 };
    const f = changed === d ? "d" : changed === w ? "w" : "e";
    if (changed !== t) {
      const others = dig.d + dig.w + dig.e - dig[f];
      let v = Math.min(dig[f], Math.max(0, cap - others));
      if (v !== dig[f]) {
        changed.value = v;
        dig[f] = v;
        if (live) live.innerHTML = '<div class="validation-msg">' + icon("alert-circle", 15) + "Doğru+Yanlış+Boş, toplam soru sayısını (" + cap + ") geçemez — giriş kırpıldı.</div>";
      }
    }
    return dig;
  };
  // olay sırası: önce kırp, sonra yenile (satırlar doğru sayıda açılır)
  [d, w, e].forEach(el => el && el.addEventListener("input", () => { clampQB(el); refresh(); }));
  if (t) t.addEventListener("input", () => { t.dataset.user = t.value ? "1" : ""; refresh(); });
  // DERS DEĞİŞİNCE hata satırları (Konu Seç) anında yenilenir — konu seçilebilmesi için
  if (lessonSel) lessonSel.addEventListener("change", refresh);
  refresh();
}

function updateQBErrors(dv, wv, ev) {
  const area = document.getElementById("qb-error-area");
  if (!area) return;
  const lesson = document.getElementById("qb-lesson").value;
  // Önceki seçimleri KORU (satırlar yeniden çizilse de konu/neden seçimleri kaybolmaz)
  const prev = {};
  area.querySelectorAll("select[data-qberr]").forEach(el => {
    const parts = el.dataset.qberr.split(":");
    prev[parts[0] + ":" + parts[1]] = el.value;
  });
  if (!lesson) {
    area.innerHTML = (wv + ev) > 0
      ? '<div class="err-hint">' + icon("mouse-pointer-click", 15, "flex-shrink:0;") + "Önce <b>&nbsp;Ders&nbsp;</b> seç — yanlış/boş sorularının konu ve neden satırları burada açılır.</div>"
      : "";
    return;
  }
  const need = Math.min(wv + ev, 30); // DOM koruma: ilk 30 hata için satır açılır
  // HIZ: sayı değişmedikçe satırları yeniden çizme (mobil gecikme düzeltmesi)
  const mevcutSatir = area.querySelectorAll(".error-log-row").length;
  const mevcutYanlis = area.querySelectorAll(".error-log-row.is-wrong").length;
  if (need > 0 && mevcutSatir === need && mevcutYanlis === Math.min(wv, 30)) { updateQBProgress(); return; }
  let html = (wv + ev > 30) ? '<div class="text-xs text-muted" style="margin-bottom:6px;">İlk 30 hata için konu satırı açıldı.</div>' : "";
  for (let i = 0; i < need; i++) {
    const isWrong = i < wv;
    html += '<div class="error-log-row ' + (isWrong ? "is-wrong" : "is-empty") + '" data-row="' + i + '">' +
      '<span class="err-badge ' + (isWrong ? "wrong" : "empty") + '">' + (isWrong ? "YANLIŞ" : "BOŞ") + '<span class="n">#' + (i + 1) + "</span></span>" +
      '<div class="err-fields">' +
      '<div style="flex:1.4;min-width:0;"><span class="err-label">KONU SEÇ <span class="text-xs text-muted font-normal">(' + esc(lesson) + ')</span></span>' +
      '<select data-qberr="' + i + ':topic"><option value="">Konu Seç…</option>' + topicsOfLesson(lesson).map(tp => '<option value="' + attr(tp) + '"' + (prev[i + ":topic"] === tp ? " selected" : "") + ">" + esc(tp) + "</option>").join("") + "</select></div>" +
      '<div style="flex:1;min-width:0;"><span class="err-label">NEDEN SEÇ</span>' +
      '<select data-qberr="' + i + ':type"><option value="">Neden Seç…</option>' + (isWrong ? WRONG_REASONS : EMPTY_REASONS).map(r => '<option value="' + attr(r) + '">' + esc(r) + "</option>").join("") + "</select></div>" +
      "</div></div>";
  }
  area.innerHTML = html;
  ddify(area); // temalı özel açılır liste
  // korunan seçimleri geri yükle
  Object.entries(prev).forEach(([k, v]) => {
    const el = area.querySelector('[data-qberr="' + sel(k) + '"]');
    if (el && v) { try { el.value = v; ddSync(el); } catch (err) {} }
  });
  if (!area.dataset.bound) {
    area.dataset.bound = "1";
    area.addEventListener("change", updateQBProgress);
    area.addEventListener("input", updateQBProgress);
  }
  updateQBProgress();
}

function updateQBProgress() {
  const area = document.getElementById("qb-error-area");
  if (!area) return;
  const rows = area.querySelectorAll(".error-log-row");
  if (!rows.length) return;
  let done = 0;
  rows.forEach(r => { const s = r.querySelectorAll("select"); const full = !!Array.from(s).length && Array.from(s).every(x => x.value); if (full) done++; r.classList.toggle("filled", full); });
  let line = area.querySelector("[data-progress]");
  if (!line) {
    line = document.createElement("div");
    line.setAttribute("data-progress", "1");
    line.className = "text-xs";
    line.style.cssText = "margin-bottom:4px;font-weight:600;";
    area.insertBefore(line, area.firstChild);
  }
  line.textContent = "İşlenen hata: " + done + "/" + rows.length + (done < rows.length ? " — her yanlış/boş için Konu + Neden seç" : " ✓ tamam");
  line.style.color = done < rows.length ? "var(--on-warning-bg)" : "var(--on-success-bg)";
}

function saveQB() {
  const box = document.getElementById("qb-validation");
  const fail = msg => { box.innerHTML = '<div class="validation-msg">' + icon("alert-circle", 15) + esc(msg) + "</div>"; toast(msg, "error"); };
  const lesson = document.getElementById("qb-lesson").value;
  const date = document.getElementById("qb-date").value || todayStr();
  const dv = Number(document.getElementById("qb-d").value) || 0;
  const wv = Number(document.getElementById("qb-w").value) || 0;
  const ev = Number(document.getElementById("qb-e").value) || 0;
  let total = Number(document.getElementById("qb-total").value) || (dv + wv + ev);
  if (!lesson) return fail("Ders seçmelisin.");
  if (dv + wv + ev === 0) return fail("D/Y/B değerlerinden en az biri sıfırdan büyük olmalı.");
  if (total > 0 && dv + wv + ev > total) return fail("Doğru+Yanlış+Boş toplamı (" + (dv + wv + ev) + "), toplam soru sayısını (" + total + ") geçemez.");
  if (dv + wv + ev > total) total = dv + wv + ev;
  if (total > 200) return fail("Tek girişte en fazla 200 soru.");

  const errorLogs = [];
  const rows = {};
  document.querySelectorAll("[data-qberr]").forEach(el => {
    const parts = el.dataset.qberr.split(":");
    rows[parts[0]] = rows[parts[0]] || {};
    rows[parts[0]][parts[1]] = el.value;
  });
  Object.keys(rows).sort().forEach((k, idx) => {
    const r = rows[k];
    if (r.topic && r.type) errorLogs.push({ qno: idx + 1, lesson: lesson, topic: r.topic, type: r.type, date: date });
  });
  // ZORUNLU: her yanlış ve boş için ayrı Konu + Neden
  const need = wv + ev;
  if (errorLogs.length < need) {
    return fail("Her yanlış ve boş için Konu + Neden girilmeli (" + (need - errorLogs.length) + " satır eksik).");
  }

  state.questions.push({ id: uid(), lesson: lesson, date: date, total: total, d: dv, w: wv, e: ev, errorLogs: errorLogs });
  state.dailyTasks.solve = true;
  ensureDailyStreakCount();
  saveState();
  evaluateBadges();
  toast("Çözüm kaydedildi · " + errorLogs.length + " hata kaydı işlendi.", "success");
  qbFormOpen = false;
  renderQuestionBank(document.getElementById("main-content"));
  if (window.lucide && lucide.createIcons) lucide.createIcons();
}

function deleteQB(idx) {
  const q = state.questions[Number(idx)];
  if (!q) return;
  openConfirm("Bu çözüm kaydı silinecek. Emin misin?", () => { state.questions.splice(Number(idx), 1); saveState(); toast("Kayıt silindi.", "success"); navigate("questionbank"); });
}

function renderQBChart() {
  const cv = document.getElementById("qb-chart");
  if (!cv || typeof Chart === "undefined") return;
  try {
    const byDate = {};
    state.questions.forEach(q => {
      const d = q.date || "-";
      if (!byDate[d]) byDate[d] = { d: 0, w: 0 };
      byDate[d].d += q.d; byDate[d].w += q.w;
    });
    const labels = Object.keys(byDate).sort();
    if (window.__qbChart) window.__qbChart.destroy();
    window.__qbChart = new Chart(cv, {
      type: "bar",
      data: {
        labels: labels.map(fmtDate),
        datasets: [
          { label: "Doğru", data: labels.map(k => byDate[k].d), backgroundColor: cssVar("--semantic-success", "#10B981"), borderRadius: 6, stack: "s" },
          { label: "Yanlış", data: labels.map(k => byDate[k].w), backgroundColor: cssVar("--semantic-error", "#EF4444"), borderRadius: 6, stack: "s" }
        ]
      },
      options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: "bottom", labels: { color: cssVar("--text-muted", "#64748B") } } }, scales: { x: { stacked: true, ticks: { color: cssVar("--text-muted", "#64748B") }, grid: { color: cssVar("--border-card", "#E8EEF8") } }, y: { stacked: true, beginAtZero: true, ticks: { color: cssVar("--text-muted", "#64748B") }, grid: { color: cssVar("--border-card", "#E8EEF8") } } } }
    });
  } catch (e) { /* Chart yoksa sessiz atla */ }
}
