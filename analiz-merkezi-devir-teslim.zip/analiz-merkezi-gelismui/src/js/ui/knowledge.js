// ============================================================
// ANALİZ MERKEZİ v5.1 — BİLGİ BANKASI / MODÜL E (modül: ui/knowledge.js)
// Müfredat ağacı + 4 adımlı kanıta dayalı motor (sıralı kilit)
// ============================================================

const ROADMAP_STEPS = [
  { title: "Ön Test (Bilişsel Kanca)", desc: "Konuya başlamadan 1 soru çöz/tahmin et. Bilmesen bile tahmin yapmak beyni eksik bilgiyi fark etmeye zorlar (%30 kalıcılık artışı).", icon: "help-circle" },
  { title: "Aktif Çalışma", desc: "Kitaptan oku, kitabı kapat ve 1 dakika boyunca kendi cümlelerinle 'Neden?' diye açıkla.", icon: "book-open" },
  { title: "Çözümlü Örnek İnceleme", desc: "En az 3 çözümlü örneğin adımlarını incele; çözüm şablonunu kavramaya çalış.", icon: "eye" },
  { title: "Karışık Pratik & Hata Girişi", desc: "15 soru çöz (karıştırılmış). Yanlış/boşların nedenlerini Soru Bankası veya Deneme girişine işle → döngü kapanır.", icon: "pen-tool" }
];

let selectedTopicKey = null;
let expandedLessons = {};

function renderKnowledge(container) {
  const tree = CURRICULUM[state.user.grade || "9"] || {};
  const dl = daysLeftToExam();

  let html = '<div class="top-bar" style="margin-bottom:16px;"><h2 style="font-size:20px;font-weight:700;">' + icon("graduation-cap", 22, "vertical-align:middle;margin-right:6px;color:var(--brand-blue);") + " Bilgi Bankası</h2></div>";

  if (dl !== null && dl <= 7) {
    html += '<div class="validation-msg" style="background:var(--semantic-warning-bg);color:var(--on-warning-bg);">' + icon("lock", 15) + " Sınava " + dl + " gün kaldı: rejim gereği yeni konu açılması ÖNERİLMEZ (%100 hata taraması dönemi). Özerklik senin: bilinçli devam edebilirsin.</div>";
  }

  html += '<div class="bento-grid" style="grid-template-columns:340px 1fr;"><div>';
  // Ders seçim paneli (müfredat ağacı)
  html += '<div class="bento-card"><h3 style="font-size:15px;font-weight:700;margin-bottom:10px;">' + icon("list-tree", 16, "vertical-align:middle;margin-right:6px;color:var(--brand-blue);") + " Müfredat Ağacı</h3><div class=\"curriculum-tree\">";
  Object.keys(tree).forEach(lesson => {
    const expanded = !!expandedLessons[lesson];
    html += '<button class="tree-lesson ' + (expanded ? "expanded" : "") + '" data-act="toggleTree" data-lesson="' + attr(lesson) + '">' + icon("chevron-right", 14, "flex-shrink:0;") + "<span>" + esc(lesson) + ' <span class="text-xs text-muted">(' + tree[lesson].length + ")</span></span></button>";
    if (expanded) {
      html += '<div class="tree-children">';
      tree[lesson].forEach(topic => {
        const key = lesson + " > " + topic;
        const mem = state.memory[key];
        const done = mem && mem.completedAt;
        const status = done ? '<span class="badge badge-success">' + icon("check", 10) + " %" + getMemoryStrength(key) + "</span>" : (state.topics[key] && state.topics[key].step > 0 ? '<span class="badge badge-info">ADIM ' + state.topics[key].step + "</span>" : "");
        html += '<button class="tree-child ' + (selectedTopicKey === key ? "active" : "") + '" data-act="selectTopic" data-topic="' + attr(key) + '"><span>' + esc(topic) + "</span>" + status + "</button>";
      });
      html += "</div>";
    }
  });
  html += "</div></div></div>";

  // Yol haritası paneli
  html += "<div>";
  if (!selectedTopicKey) {
    // §8: Konu Seçin paneli — genel durum istatistikleri
    const ms = memoryStats();
    let tam = 0, calis = 0, toplam = 0;
    Object.keys(tree).forEach(l => {
      tree[l].forEach(tp => {
        const key = l + " > " + tp;
        toplam++;
        if (state.memory[key] && state.memory[key].completedAt) tam++;
        else if (state.topics[key] && state.topics[key].step > 0) calis++;
      });
    });
    html += '<div class="bento-card" style="margin-bottom:16px;"><h3 style="font-size:16px;font-weight:700;margin-bottom:14px;">' + icon("mouse-pointer-click", 17, "vertical-align:-3px;margin-right:6px;color:var(--brand-blue);") + " Konu Seçin</h3>";
    html += '<div class="kb-kpi"><div><b class="tabular">' + tam + '</b><span>Tamamlanan</span></div><div><b class="tabular" style="color:var(--semantic-warning);">' + calis + '</b><span>\u00c7al\u0131\u015f\u0131lan</span></div><div><b class="tabular">' + toplam + "</b><span>Toplam</span></div></div>";
    html += '<div class="kb-kpi kb-kpi2"><div><b class="tabular" style="color:var(--semantic-error);">' + ms.waiting + '</b><span>Tekrar Bekleyen</span></div><div><b class="tabular" style="color:var(--memory-indigo);">%' + ms.avg + '</b><span>Ort. Haf\u0131za</span></div><div><b class="tabular" style="color:var(--semantic-error);">' + ms.critical + "</b><span>Kritik</span></div></div>";
    html += '<p class="text-xs text-muted" style="margin-top:10px;">Soldaki Müfredat Ağacı' + APRX + "ndan bir konu seç; <b>4 adımlı kanıta dayalı çalışma motoru</b> başlasın.</p></div>";
  } else {
    const p = splitKey(selectedTopicKey);
    const tstate = state.topics[selectedTopicKey] || { step: 0, completedAt: null };
    const mem = state.memory[selectedTopicKey];
    const done = mem && mem.completedAt;
    const diff = difficultyFor(selectedTopicKey);

    html += '<div class="bento-card" style="margin-bottom:16px;"><div class="flex items-center justify-between" style="flex-wrap:wrap;gap:8px;"><div><span class="badge badge-info">' + esc(p.lesson) + "</span>" +
      '<h3 style="font-size:18px;font-weight:700;margin-top:6px;">' + esc(p.topic) + "</h3></div>" +
      '<span class="badge" style="background:' + diff.color + '22;color:' + diff.color + ';">Soru önerisi: ' + diff.level + (diff.rate !== null ? " (başarı %" + diff.rate + ")" : "") + "</span></div></div>";

    if (done) {
      const pct = getMemoryStrength(selectedTopicKey);
      const nr = nextReviewInfo(selectedTopicKey);
      html += '<div class="bento-card" style="margin-bottom:16px;">' +
        '<div class="flex items-center gap-2" style="margin-bottom:10px;">' + icon("check-circle-2", 22, "color:var(--semantic-success);") +
        '<b style="font-size:14px;">Tamamland' + APRX + ' — hafıza takibinde</b></div>' +
        '<div class="kb-hafiza"><span class="text-xs text-muted">Hafıza Gücü</span><div class="progress" style="flex:1;"><div style="width:' + pct + "%;background:" + memoryColor(pct) + ';"></div></div><b class="tabular" style="color:' + memoryColor(pct) + '; font-size:16px;">%' + pct + "</b></div>" +
        '<div class="kb-satir tabular"><span>Tekrar: <b>' + (mem.reviewCount || 0) + '</b></span><span>Tamamlanma: <b>' + fmtDate(mem.completedAt) + "</b></span><span>Son Tekrar: <b>" + (mem.lastReview ? fmtDate(mem.lastReview) : "-") + "</b></span><span>Sıradaki: <b>" + (nr ? fmtDate(nr.date) + " (" + nr.day + ". gün)" : "-") + "</b></span></div>" +
        '<div class="flex gap-2" style="margin-top:12px;flex-wrap:wrap;">' +
        '<button class="btn btn-success btn-sm" data-act="reviewTopic" data-topic="' + attr(selectedTopicKey) + '">' + icon("refresh-cw", 14) + " Tekrar Ettim</button>" +
        '<button class="btn btn-primary btn-sm" data-act="earlyReview" data-topic="' + attr(selectedTopicKey) + '">' + icon("fast-forward", 14) + " Erken Tekrar</button>" +
        '<button class="btn btn-ghost btn-sm" data-act="resetTopic" data-topic="' + attr(selectedTopicKey) + '" style="color:var(--semantic-error);margin-left:auto;">' + icon("rotate-ccw", 14) + " Sıfırla</button></div></div>";
    } else {
      // 4 adım (0-3), sıralı kilit
      html += '<div class="bento-card"><h3 style="font-size:15px;font-weight:700;margin-bottom:12px;">' + icon("map", 16, "vertical-align:middle;margin-right:6px;color:var(--brand-blue);") + ' Çalışma Yol Haritası</h3>';
      ROADMAP_STEPS.forEach((st, i) => {
        const isDone = tstate.step > i;
        const isActive = tstate.step === i;
        const locked = tstate.step < i;
        html += '<div class="roadmap-step ' + (isDone ? "completed" : isActive ? "active" : "locked") + '">' +
          '<div class="step-number">' + (isDone ? icon("check", 15) : i) + "</div>" +
          '<div style="flex:1;min-width:0;"><div style="font-weight:700;font-size:14px;">' + esc(st.title) + (locked ? " " + icon("lock", 12, "opacity:0.5;") : "") + "</div>" +
          '<div class="text-xs text-muted" style="margin-top:2px;">' + esc(st.desc) + "</div>";
        if (isActive) html += '<button class="btn btn-sm btn-primary" style="margin-top:8px;" data-act="completeStep" data-topic="' + attr(selectedTopicKey) + '" data-step="' + i + '">' + icon("check", 13) + " Tamamla</button>";
        else if (isDone) html += '<span class="badge badge-success" style="margin-top:8px;">TAMAMLANDI</span>';
        html += "</div></div>";
      });
      if (tstate.step >= ROADMAP_STEPS.length) {
        html += '<button class="btn btn-success w-full" style="margin-top:6px;" data-act="completeTopic" data-topic="' + attr(selectedTopicKey) + '">' + icon("check-circle-2", 16) + " ✓ Konuyu Tamamlandı Olarak İşaretle</button>";
      }
      html += "</div>";
    }
  }
  html += "</div></div>";
  container.innerHTML = html;
}

function toggleTree(lesson) { expandedLessons[lesson] = !expandedLessons[lesson]; renderKnowledge(document.getElementById("main-content")); if (window.lucide && lucide.createIcons) lucide.createIcons(); }

function selectKnowledgeTopic(key) {
  selectedTopicKey = key;
  // NOT: Konu ağacı otomatik AÇILMAZ — "Çalış" ile gelindiğinde doğrudan konu
  // paneli görünür; ağacı kullanıcı isterse kendisi açar.
  if (!state.topics[key]) state.topics[key] = { step: 0, completedAt: null };
  renderKnowledge(document.getElementById("main-content"));
  if (window.lucide && lucide.createIcons) lucide.createIcons();
}

function completeStep(key, step) {
  if (!state.topics[key]) state.topics[key] = { step: 0 };
  if (state.topics[key].step !== step) return; // sıralı kilit: sadece aktif adım tamamlanır
  state.topics[key].step = step + 1;
  state.dailyTasks.study = true; // gerçek çalışma eylemi → günlük görev otomatik tamam
  ensureDailyStreakCount();
  saveState();
  renderKnowledge(document.getElementById("main-content"));
  if (window.lucide && lucide.createIcons) lucide.createIcons();
}

function completeTopic(key) {
  const now = new Date().toISOString();
  state.topics[key] = { step: ROADMAP_STEPS.length, completedAt: now };
  state.memory[key] = { lastReview: now, reviewCount: 0, completedAt: now, schedule: {} };
  scheduleReviews(key); // 3-7-14-21-28 gün sonrası için hatırlatıcılar
  state.dailyTasks.study = true;
  ensureDailyStreakCount();
  saveState();
  evaluateBadges();
  fireConfetti();
  const nr = nextReviewInfo(key);
  addNotification({
    title: "Yeni Konu Tamamlandı: " + splitKey(key).topic,
    body: "Ebbinghaus takvimi kuruldu. İlk tekrar: " + (nr ? fmtDate(nr.date) : "-") + ". Hafıza barı %100'den başladı.",
    kind: "review", topicKey: key + "@complete"
  });
  toast("Konu tamamlandı! Tekrar takvimi kuruldu (3-7-14-21-28 gün).", "success");
  renderKnowledge(document.getElementById("main-content"));
  if (window.lucide && lucide.createIcons) lucide.createIcons();
}
