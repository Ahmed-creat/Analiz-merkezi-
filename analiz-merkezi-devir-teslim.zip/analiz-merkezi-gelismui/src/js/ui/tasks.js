// ============================================================
// ANALİZ MERKEZİ v5.1 — GÜNLÜK GÖREVLER / MODÜL G (modül: ui/tasks.js)
// Streak + Freeze + 3 görev satırı
// Görevler ELLE işaretlenmez: gerçek eylem yapılınca otomatik tamamlanır.
//   study -> Bilgi Bankası'nda adım/konu tamamlamak
//   read  -> Kitaplık'tan okunan sayfa girmek
//   solve -> Soru Bankası'na çözüm girmek veya deneme kaydetmek
// ============================================================

function renderTasks(container) {
  const t = state.dailyTasks;
  const doneCount = (t.study ? 1 : 0) + (t.read ? 1 : 0) + (t.solve ? 1 : 0);
  const thisWeek = isoWeek(new Date()) + "-" + new Date().getFullYear();
  const freezeAvailable = state.streak.freezeWeek !== thisWeek;

  // §2: solda görev listesi, sağda seri istatistikleri
  const tasks = [
    { key: "study", icon: "book-open", title: "Ders Çalışma + Soru Çöz", page: "knowledge", bt: "Bilgi Bankası'na git", desc: "Bilgi Bankası" + APRX + "nda bir adım tamamla veya konu bitir" },
    { key: "read", icon: "library", title: "Kitap Oku", page: "library", bt: "Kitaplığa git", desc: "Kitaplık" + APRX + "tan okuduğun sayfayı gir" + (state.plan.dailyReading ? " (hedef: " + state.plan.dailyReading + " sayfa)" : "") },
    { key: "solve", icon: "pen-tool", title: "Soru Çözümü", page: "questionbank", bt: "Soru Bankası'na git", desc: "Soru Bankası" + APRX + "na çözüm gir veya deneme kaydet" }
  ];

  let html = '<div class="top-bar" style="margin-bottom:14px;"><h2 style="font-size:20px;font-weight:700;">' + icon("check-square", 22, "vertical-align:middle;margin-right:6px;color:var(--brand-blue);") + " Günlük Görevler</h2>";
  html += '<span class="tagpill ' + (doneCount === 3 ? "ok" : "warn") + '">' + doneCount + "/3 görev</span></div>";

  html += '<div class="ikili-grid">';
  // SOL: Günlük Hedefler
  html += '<div class="bento-card"><h3 style="font-size:15px;font-weight:700;margin-bottom:4px;">Günlük Hedefler</h3>';
  html += tasks.map(tsk => {
    const ok = !!t[tsk.key];
    return '<div class="gorev-row ' + (ok ? "ok" : "") + '">' +
      '<span class="gorev-ic">' + icon(ok ? "check-circle-2" : tsk.icon, 18, ok ? "color:var(--semantic-success);" : "color:var(--text-muted);") + "</span>" +
      '<div style="flex:1;min-width:0;"><div style="font-weight:700;font-size:13.5px;">' + tsk.title + " " + (ok ? '<span class="tagpill ok">tamam</span>' : '<span class="tagpill danger">Eksik</span>') + "</div>" +
      '<div class="text-xs text-muted" style="margin-top:1px;">' + tsk.desc + "</div>" +
      (ok ? "" : '<button class="btn btn-sm btn-ghost" style="margin-top:6px;" data-act="nav" data-page="' + tsk.page + '">' + icon("arrow-right", 12) + " " + tsk.bt + "</button>") +
      "</div></div>";
  }).join("");
  html += "</div>";

  // SAĞ: Seri İstatistikleri
  html += '<div class="bento-card"><h3 style="font-size:15px;font-weight:700;margin-bottom:12px;">' + icon("bar-chart-3", 15, "vertical-align:-3px;color:var(--brand-blue);") + " Seri İstatistikleri</h3>";
  html += '<div class="seri-kutu"><div><div class="text-xs text-muted">MEVCUT SER' + APRX + "</div><div class='tabular' style='font-size:22px;font-weight:800;'>" + state.streak.count + '<span class="text-xs text-muted" style="font-weight:600;"> / 3+ gün</span></div></div>' +
    '<div style="text-align:right;"><div class="text-xs text-muted">BUGÜN</div><div class="tabular" style="font-size:22px;font-weight:800;color:var(--brand-blue);">' + doneCount + '<span class="text-xs text-muted" style="font-weight:600;"> / 3 görev</span></div></div></div>';
  html += '<div class="seri-bar"><div style="width:' + (doneCount / 3 * 100) + '%;"></div></div>';
  html += '<div class="seri-not' + (doneCount === 3 ? " ok" : "") + '">' + icon(doneCount === 3 ? "party-popper" : "snowflake", 15, "flex-shrink:0;") +
    (doneCount === 3
      ? "<span><b>3 görev tamam, seri +1 gün!</b> Yarın " + (state.streak.count + 1) + " güne çıkar.</span>"
      : (3 - doneCount) + " görev kaldı. " + (freezeAvailable ? "Haftalık <b>Seri Dondurma</b> hakkın hazır (bir gün kaçırırsan seri yanmaz)." : "Bu haftanın dondurma hakkı kullanıldı.")) + "</div>";
  html += '<div class="bento-card" style="background:var(--bg-canvas);box-shadow:none;margin-top:12px;padding:14px;"><b style="font-size:12.5px;">' + icon("info", 13, "vertical-align:-2px;color:var(--brand-blue);") + " Nasıl Çalışır?</b>" +
    '<ol class="nasil-list"><li>Bilgi Bankası\'ndan konu çalış → <b>Ders Çalışma</b> görevi dolar.</li><li>Soru Bankası\'ndan çözüm gir veya deneme kaydet → <b>Soru Çözümü</b>.</li><li>Kitaplık\'tan sayfa ilerlet → <b>Kitap Oku</b>.</li><li>3 görev de dolunca gün işlenir; seri büyür, rozetler açılır.</li></ol></div>';
  html += "</div></div>";

  container.innerHTML = html;
}

// Günün ilk tamamlanan görevi seri sayacını işler (toggle, kitap okuma, soru çözümü, adım tamamlama ortak yoldan geçer)
function ensureDailyStreakCount() {
  const t = state.dailyTasks;
  if (!(t.study || t.read || t.solve)) return;
  const today = todayStr();
  const yest = new Date(); yest.setDate(yest.getDate() - 1); yest.setHours(0, 0, 0, 0);
  if (state.streak.lastCheck === today) {
    if (state.streak.count === 0) state.streak.count = 1;
  } else if (state.streak.lastCheck === toDayStr(yest)) {
    state.streak.count += 1;
  } else {
    state.streak.count = 1;
  }
  state.streak.lastCheck = today;
}
