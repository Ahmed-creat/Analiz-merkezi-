// ============================================================
// ANALİZ MERKEZİ — GELİŞMİŞ ARAYÜZ · ANA SAYFA (Tur-13)
// Selam + tarih → KPI 4'lü → BUGÜNÜN ÖZETİ → grafikler
// (Net Gelişimi + Ders Başarı Oranları) → SON DENEMEN
// ============================================================

function renderDashboard(container) {
  const st = examStats();
  const rs = readingStats();
  const son = state.exams[state.exams.length - 1];
  const rhythm = RHYTHMS.find(r => r.key === state.plan.rhythm) || RHYTHMS[0];
  const saat = new Date().getHours();
  const selam = saat < 12 ? "Günaydın" : saat < 17 ? "İyi günler" : saat < 22 ? "İyi akşamlar" : "İyi geceler";
  const pr = calculatePriority();
  const due = dueReviews();
  const ms = memoryStats();
  const dl = daysLeftToExam();

  let html = '<div class="hello-row"><div>' +
    '<h2 style="font-size:21px;font-weight:800;letter-spacing:-0.01em;">' + selam + (state.user.name ? ", " + esc(state.user.name) : "") + "</h2>" +
    '<div class="text-sm text-muted" style="margin-top:2px;">Bugün ' + new Date().toLocaleDateString("tr-TR", { day: "numeric", month: "long", year: "numeric", weekday: "long" }) + " · " + icon(rhythm.icon, 13, "vertical-align:-2px;") + " " + esc(rhythm.key) + " ritmi</div></div>";
  html += '<button class="btn btn-ghost btn-sm" data-act="openHelp">' + icon("help-circle", 14) + " Kılavuz</button></div>";

  // ---- KPI SATIRI (4 kart yatay) ----
  html += '<div class="stat-grid" style="margin-bottom:18px;">' +
    qkpi("SERİ", state.streak.count + " gün", "flame", "var(--semantic-warning)") +
    qkpi("TOPLAM SORU", totalSolved(), "pen-tool", "var(--brand-blue)") +
    qkpi("ORTALAMA NET", st.count ? st.avg : "—", "trending-up", "var(--memory-indigo)") +
    qkpi("OKUNAN SAYFA", rs.pages, "book-open", "var(--semantic-success)") +
    "</div>";

  // ---- BUGÜNÜN ÖZETİ (önemli olan her şey tek kartta) ----
  html += '<h3 class="sec-head">' + icon("layout-dashboard", 15, "vertical-align:-3px;color:var(--brand-blue);") + " BUGÜNÜN ÖZETİ</h3>";
  html += '<div class="bento-card"><div class="stat-grid">';
  html += ozetKutusu("icon", "calendar-clock", dl !== null ? dl + " gün" : "—", "Sınava Kalan", "var(--semantic-error)");
  html += ozetKutusu("icon", "refresh-cw", due.length, "Tekrar Bekleyen", "var(--memory-indigo)");
  html += ozetKutusu("icon", "alert-circle", pr.length, "Acil Konu", "var(--semantic-warning)");
  html += ozetKutusu("icon", "brain", ms.avg ? "%" + ms.avg : "—", "Ort. Hafıza", "var(--semantic-success)");
  html += "</div>";
  // Bugünün görev şeridi
  const t = state.dailyTasks || {};
  html += '<div class="flex items-center gap-2" style="flex-wrap:wrap;margin-top:4px;padding-top:10px;border-top:1px solid var(--border-card);">' +
    '<span class="text-xs text-muted" style="font-weight:700;letter-spacing:0.05em;">GÜNÜN GÖREVLERİ:</span>' +
    gorevRozeti("Konu Çalış", t.study) + gorevRozeti("Soru Çöz", t.solve) + gorevRozeti("Okuma", t.read) +
    '<button class="btn btn-primary btn-sm" style="margin-left:auto;" data-act="nav" data-page="tasks">' + icon("check-square", 13) + " Görevlere Git</button></div>";
  // En acil 3 konu
  if (pr.length) {
    html += '<div style="margin-top:10px;padding-top:10px;border-top:1px solid var(--border-card);">' +
      '<div class="text-xs text-muted" style="font-weight:700;letter-spacing:0.05em;margin-bottom:6px;">EN ACİL 3 KONU</div>' +
      pr.slice(0, 3).map((p, i) => {
        const s = p[2];
        return '<div class="flex items-center gap-2" style="padding:5px 0;min-width:0;">' +
          '<span class="acil-rank" style="width:22px;height:22px;min-width:22px;display:inline-flex;align-items:center;justify-content:center;border-radius:7px;background:var(--semantic-error-bg);color:var(--on-error-bg);font-size:10.5px;font-weight:800;">#' + (i + 1) + "</span>" +
          '<span style="min-width:0;flex:1;font-size:12.5px;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' + esc(s.topic) + "</span>" +
          '<span class="text-xs text-muted" style="flex-shrink:0;">' + esc(s.lesson) + "</span></div>";
      }).join("") + "</div>";
  }
  html += "</div>";

  // ---- GRAFİKLER (2'li grid: Net Gelişimi + Ders Başarı Oranları) ----
  html += '<h3 class="sec-head" style="margin-top:18px;">' + icon("bar-chart-3", 15, "vertical-align:-3px;color:var(--memory-indigo);") + " PERFORMANS GRAFİKLERİ</h3>";
  html += '<div class="ikili-grid">';
  html += '<div class="bento-card"><h3 style="font-size:14px;font-weight:700;margin-bottom:10px;">' + icon("trending-up", 15, "vertical-align:middle;margin-right:6px;color:var(--brand-blue);") + " Net Gelişimi</h3>";
  html += st.series.length >= 2
    ? '<div class="chart-wrap"><canvas id="dash-net-chart"></canvas></div>'
    : '<div class="empty-state">' + icon("trending-up", 30) + "<div>En az 2 deneme girince net gelişim grafiği burada çizilir.</div></div>";
  html += "</div>";
  html += '<div class="bento-card"><h3 style="font-size:14px;font-weight:700;margin-bottom:10px;">' + icon("bar-chart-3", 15, "vertical-align:middle;margin-right:6px;color:var(--brand-blue);") + " Ders Başarı Oranları</h3>";
  const rates = getLessonSuccessRates();
  const rk = Object.keys(rates).filter(k => rates[k]);
  html += rk.length
    ? '<div class="chart-wrap"><canvas id="dash-lesson-chart"></canvas></div>'
    : '<div class="empty-state">' + icon("bar-chart-3", 30) + "<div>Doğru/yanlış girdikçe ders bazlı başarı grafiği burada çizilir.</div></div>";
  html += "</div></div>";

  // ---- SON DENEMEN ----
  html += '<h3 class="sec-head" style="margin-top:18px;">' + icon("history", 15, "vertical-align:-3px;color:var(--brand-blue);") + " SON DENEMEN</h3>";
  if (son) {
    const logs = (son.errorLogs || []).length;
    html += '<div class="bento-card son-exam"><div style="min-width:0;flex:1;">' +
      '<div style="font-weight:800;font-size:15px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">' + esc(son.name) + "</div>" +
      '<div class="text-xs text-muted tabular" style="margin-top:3px;">' + fmtDate(son.date) + " · " + son.total + " soru · " + logs + " hata kaydı</div></div>" +
      '<div class="son-net"><span class="tabular">' + son.net + "</span><span class='text-xs text-muted'>net</span></div>" +
      '<button class="btn btn-primary btn-sm" data-act="nav" data-page="exams">' + icon("chevron-right", 14) + " Git</button></div>";
  } else {
    html += '<div class="bento-card"><div class="empty-state">' + icon("clipboard-list", 30) + "<div>Henüz deneme yok. <b>Denemelerim → Yeni Deneme Ekle</b> ile başla.</div></div></div>";
  }

  container.innerHTML = html;
  renderDashCharts();
}

// Özet kutusu (BUGÜNÜN ÖZETİ kartındaki 4'lü)
function ozetKutusu(_cls, ic, value, label, color) {
  return '<div class="stat-box" style="border-top:3px solid ' + color + ';">' +
    '<div class="flex items-center justify-between"><span class="text-xs text-muted" style="font-weight:700;letter-spacing:0.05em;">' + label + "</span>" + icon(ic, 15, "color:" + color + ";") + "</div>" +
    '<div class="tabular" style="font-size:21px;font-weight:800;letter-spacing:-0.02em;margin-top:4px;">' + value + "</div></div>";
}
function gorevRozeti(name, done) {
  return '<span class="badge ' + (done ? "badge-ok" : "badge-warn") + '">' + (done ? "✓ " : "") + esc(name) + "</span>";
}

// Ana sayfa grafikleri: Net Gelişimi (çizgi) + Ders Başarı (yatay bar)
function renderDashCharts() {
  if (typeof Chart === "undefined") return;
  const gridCol = cssVar("--border-card", "#E8EEF8");
  const tickCol = cssVar("--text-muted", "#64748B");
  try {
    const cv1 = document.getElementById("dash-net-chart");
    if (cv1) {
      const st = examStats();
      if (window.__dashNet) window.__dashNet.destroy();
      window.__dashNet = new Chart(cv1, {
        type: "line",
        data: { labels: st.series.map(s => s.name), datasets: [{ label: "Net", data: st.series.map(s => s.net), borderColor: cssVar("--brand-blue", "#2563EB"), backgroundColor: "rgba(37,99,235,0.08)", fill: true, tension: 0.35, pointRadius: 4, pointBackgroundColor: cssVar("--brand-blue", "#2563EB") }] },
        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { color: tickCol }, grid: { color: gridCol } }, x: { ticks: { color: tickCol, maxRotation: 30, autoSkip: true }, grid: { color: gridCol } } } }
      });
    }
    const cv2 = document.getElementById("dash-lesson-chart");
    if (cv2) {
      const rates = getLessonSuccessRates();
      const rk = Object.keys(rates).filter(k => rates[k]);
      if (window.__dashLesson) window.__dashLesson.destroy();
      window.__dashLesson = new Chart(cv2, {
        type: "bar",
        data: {
          labels: rk.map(k => k.length > 14 ? k.slice(0, 13) + "…" : k),
          datasets: [{ label: "Başarı %", data: rk.map(k => rates[k].pct), backgroundColor: rk.map(k => lessonChartColor(k)), borderRadius: 6, maxBarThickness: 22 }]
        },
        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { min: 0, max: 100, ticks: { color: tickCol, callback: v => "%" + v }, grid: { color: gridCol } }, x: { ticks: { color: tickCol, font: { size: 10 } }, grid: { display: false } } } }
      });
    }
  } catch (e) { /* grafik çizilemezse sessiz atla */ }
}

// Ders başarı grafiği: her dersin SABİT rengi (trafik ışığı yerine ayrıştırıcı palet)
const LESSON_CHART_COLORS = ["#3B82F6", "#8E4EC6", "#0D9488", "#F59E0B", "#EC4899", "#06B6D4", "#84CC16", "#F43F5E"];
function lessonChartColor(lesson) {
  const keys = Object.keys(LESSON_CONFIG);
  const i = keys.indexOf(lesson);
  return LESSON_CHART_COLORS[(i >= 0 ? i : 0) % LESSON_CHART_COLORS.length];
}

function qkpi(label, value, ic, color) {
  return '<div class="bento-card stat-box" style="border-top:3px solid ' + color + ';">' +
    '<div class="flex items-center justify-between"><span class="text-xs text-muted" style="font-weight:700;letter-spacing:0.05em;">' + label + "</span>" + icon(ic, 15, "color:" + color + ";") + "</div>" +
    '<div class="tabular" style="font-size:23px;font-weight:800;letter-spacing:-0.02em;margin-top:4px;">' + value + "</div></div>";
}

function statBox(label, value) {
  return '<div class="stat-box"><div class="text-xs text-muted">' + label + '</div><div class="text-lg font-bold tabular">' + value + "</div></div>";
}
