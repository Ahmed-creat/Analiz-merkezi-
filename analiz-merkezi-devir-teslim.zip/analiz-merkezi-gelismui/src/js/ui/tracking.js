// ============================================================
// ANALİZ MERKEZİ v5.1 — KONU TAKİBİ / MODÜL B (modül: ui/tracking.js)
// Acil Çalışılacaklar + Hafıza Gücü + Kök Eksik (ders başarı grafiği Ana Sayfa'da)
// ============================================================

let urgentLimit = 10; // Acil Çalışılacaklar: varsayılan 10; buton AÇ/KAPA toggle'ı
function moreUrgentTopics() {
  const toplam = calculatePriority().length;
  // liste tamamen açıksa KAPAT (10'a dön); değilse +10 daha aç
  urgentLimit = (urgentLimit >= toplam && urgentLimit > 10) ? 10 : urgentLimit + 10;
  renderTracking(document.getElementById("main-content"));
  if (window.lucide && lucide.createIcons) lucide.createIcons();
}
let memoryLimit = 10; // Hafıza Gücü satırları: aynı AÇ/KAPA davranışı
function moreMemoryRows() {
  const toplam = memoryStats().rows.length;
  memoryLimit = (memoryLimit >= toplam && memoryLimit > 10) ? 10 : memoryLimit + 10;
  renderTracking(document.getElementById("main-content"));
  if (window.lucide && lucide.createIcons) lucide.createIcons();
}

function renderTracking(container) {
  const pr = calculatePriority();
  const ms = memoryStats();
  const roots = rootDeficitList();

  let html = '<div class="top-bar" style="margin-bottom:14px;"><h2 style="font-size:20px;font-weight:700;">' + icon("radar", 22, "vertical-align:middle;margin-right:6px;color:var(--brand-blue);") + " Konu Takibi</h2>";
  html += '<span class="text-xs text-muted">' + pr.length + " öncelikli konu</span></div>";

  // ===== ACİL ÇALIŞILACAKLAR (tam genişlik — ders başarı grafiği Ana Sayfa'da) =====
  html += '<div class="bento-card"><h3 style="font-size:15px;font-weight:700;margin-bottom:12px;">' + icon("alert-circle", 16, "vertical-align:middle;margin-right:6px;color:var(--semantic-error);") + " Acil Çalışılacaklar <span class='text-xs text-muted' style='font-weight:600;'>(Öncelik Sırası)</span></h3>";
  if (pr.length) {
    html += pr.slice(0, urgentLimit).map((p, i) => {
      const s = p[2];
      const maxScore = pr[0][1] || 1;
      const scorePct = clamp((p[1] / maxScore) * 100, 8, 100);
      return '<div class="acil-row">' +
        '<span class="acil-rank">#' + (i + 1) + "</span>" +
        '<div style="flex:1;min-width:0;">' +
        '<div class="flex items-center gap-2" style="flex-wrap:wrap;">' +
        '<span style="font-weight:700;font-size:13.5px;min-width:0;flex:1;">' + esc(s.topic) + "</span>" +
        (s.kae > 0 ? '<span class="badge badge-kritik">KAE</span>' : "") + "</div>" +
        '<div class="text-xs text-muted" style="margin:3px 0 5px;">' + esc(s.lesson) + " · Toplam hata: " + s.count + (s.anlamadim ? " · ANLAMADIM ×" + s.anlamadim : "") + "</div>" +
        '<div class="progress" style="margin-bottom:6px;"><div style="width:' + scorePct + "%;background:var(--brand-gradient);\"></div></div>" +
        '<div class="flex gap-2" style="flex-wrap:wrap;align-items:center;">' + Object.entries(s.reasons).slice(0, 3).map(([r, c]) => '<span class="badge badge-warn">' + esc(r) + " ×" + c + "</span>").join("") +
        '<button class="btn btn-sm btn-primary" style="margin-left:auto;" data-act="startStudy" data-topic="' + attr(p[0]) + '">' + icon("play", 13) + " Çalış</button></div></div></div>";
    }).join("");
  } else {
    html += '<div class="empty-state">' + icon("radar", 34) + "<div>" +
      (state.exams.length || state.questions.length
        ? "Kayıtlı deneme/soru var ama hata kaydı yok.<br>Denemelerim" + APRX + "nde her yanlış/boş için Konu + Neden girersen öncelik listesi oluşur."
        : "Deneme veya soru hatası girince öncelik listesi burada oluşur.") + "</div></div>";
  }
  if (pr.length > urgentLimit) {
    html += '<button class="btn btn-ghost w-full" data-act="moreUrgent" style="margin-top:8px;">' + icon("chevron-down", 14) + " Daha Fazla Göster (" + (pr.length - urgentLimit) + " konu daha)</button>";
  } else if (urgentLimit > 10) {
    html += '<button class="btn btn-ghost w-full" data-act="moreUrgent" style="margin-top:8px;">' + icon("chevron-up", 14) + " Daha Az Göster</button>";
  }
  html += "</div>";




  // ===== KÖK EKSİK (çapraz ilişkilendirme) =====
  if (roots.length) {
    html += '<div class="bento-card" style="margin-top:16px;border-color:rgba(239,68,68,0.3);"><h3 style="font-size:15px;font-weight:700;margin-bottom:8px;color:var(--semantic-error);">' + icon("git-branch", 16, "vertical-align:middle;margin-right:6px;") + " Kök Eksik Uyarısı (Çapraz İlişkilendirme)</h3>";
    html += roots.slice(0, 5).map(r =>
      '<div class="text-sm" style="padding:8px 0;border-bottom:1px solid var(--border-card);">' + icon("corner-down-right", 13, "vertical-align:middle;") +
      " <b>" + esc(splitKey(r.weak).topic) + "</b> zayıf ama <b>" + esc(splitKey(r.strong).topic) + "</b> güçlü (fark %" + r.diff + "). Kök ders: <b>" + esc(r.root) + "</b> — temel konuyu onarınca ikisi de düzelir.</div>"
    ).join("") + "</div>";
  }

  // ===== HAFIZA GÜCÜ (§5: eğri + KPI + konu barları) =====
  html += '<div class="bento-card" style="margin-top:16px;"><div class="flex items-center justify-between" style="margin-bottom:4px;flex-wrap:wrap;gap:6px;"><h3 style="font-size:15px;font-weight:700;">' + icon("brain", 16, "vertical-align:middle;margin-right:6px;color:var(--memory-indigo);") + " Hafıza Gücü</h3>";
  const iv = idealReviewInterval();
  if (iv !== null) html += '<span class="text-xs text-muted">Sınav yaklaşırken aralıklar Cepeda %15 ile sıklaşır · ideal: <b>' + iv + " gün</b></span>";
  html += "</div>";
  if (ms.rows.length) {
    html += '<div class="stat-grid" style="margin-bottom:14px;">' +
      statBox("Tamamlanan Tekrar", ms.rows.reduce((a, r) => a + r.reviews, 0)) +
      statBox("Tekrar Bekleyen", ms.waiting) +
      statBox("Ort. Hafıza", "%" + ms.avg) +
      statBox("Kritik (<%20)", ms.critical) + "</div>";
    const gosterilen = ms.rows.slice(0, memoryLimit);
    html += gosterilen.map(r => {
      const done = r.pct >= 90;
      const urgent = r.pct < MEMORY_CRITICAL;
      const btn = urgent
        ? '<button class="btn btn-sm btn-danger" data-act="reviewTopic" data-topic="' + attr(r.key) + '">' + icon("flame", 13) + " ACİL TEKRAR ET</button>"
        : r.due
          ? '<button class="btn btn-sm btn-primary" data-act="reviewTopic" data-topic="' + attr(r.key) + '">' + icon("check", 13) + " Tekrar Ettim</button>"
          : done
            ? '<button class="btn btn-sm btn-success" data-act="reviewTopic" data-topic="' + attr(r.key) + '">' + icon("check", 13) + " Tekrar Ettim</button>"
            : '<button class="btn btn-sm btn-primary" data-act="earlyReview" data-topic="' + attr(r.key) + '">' + icon("fast-forward", 13) + " Erken Tekrar Yap</button>";
      return '<div class="hafiza-row">' +
        '<span class="hafiza-ad" style="min-width:0;flex:1;">' +
        (r.pct < MEMORY_WARNING ? '<span class="badge badge-kritik">KRİTİK</span> ' : "") + (r.due ? '<span class="badge badge-warn">BUGÜN</span> ' : "") +
        '<b style="font-size:13px;">' + esc(r.topic) + "</b><br><span class='text-xs text-muted'>" + esc(r.lesson) + " · " + r.reviews + " tekrar" + (r.next ? " · sıradaki: " + fmtDate(r.next.date) + " (" + r.next.day + ". gün)" : "") + "</span></span>" +
        '<span class="hafiza-bar"><span style="width:' + r.pct + "%;background:" + memoryColor(r.pct) + ';"></span><b class="tabular" style="color:' + memoryColor(r.pct) + ';">%' + r.pct + "</b></span>" +
        '<span class="flex gap-2" style="flex-shrink:0;">' + btn +
        '<button class="btn btn-sm btn-ghost" data-act="resetTopic" data-topic="' + attr(r.key) + '" style="color:var(--semantic-error);" title="Baştan Başla">' + icon("rotate-ccw", 13) + "</button></span></div>";
    }).join("");
    if (ms.rows.length > memoryLimit) {
      html += '<button class="btn btn-ghost w-full" data-act="moreMemory" style="margin-top:8px;">' + icon("chevron-down", 14) + " Daha Fazla Göster (" + (ms.rows.length - memoryLimit) + " konu daha)</button>";
    } else if (memoryLimit > 10) {
      html += '<button class="btn btn-ghost w-full" data-act="moreMemory" style="margin-top:8px;">' + icon("chevron-up", 14) + " Daha Az Göster</button>";
    }
  } else {
    html += '<div class="empty-state">' + icon("brain", 34) + "<div>Bilgi Bankası'nda konu tamamlandıkça hafıza barları burada belirir.</div></div>";
  }
  html += "</div>";

  container.innerHTML = html;
}

function startStudy(topicKey) {
  state.topics[topicKey] = state.topics[topicKey] || { step: 0, completedAt: null, preTest: false };
  saveState();
  navigate("knowledge");
  setTimeout(() => selectKnowledgeTopic(topicKey), 50);
}

function reviewTopic(topicKey) { markReviewed(topicKey, false); navigate("tracking"); toast("Tekrar kaydedildi; hafıza barı %100.", "success"); }
function earlyReview(topicKey) { markReviewed(topicKey, true); navigate("tracking"); toast("Erken tekrar kaydedildi.", "success"); }
function resetTopic(topicKey) {
  openConfirm("Konu 'Tamamlandı' statüsünden çıkacak, hafıza sıfırlanacak ve 0. Adım'a döneceksin. Emin misin?", () => {
    resetTopicMemory(topicKey); saveState(); toast("Konu sıfırlandı.", "warning"); navigate("tracking");
  });
}
