// ============================================================
// ANALİZ MERKEZİ v5.1 — KİTAPLIK / MODÜL C (modül: ui/library.js)
// Disiplin Puanı + Okuma Hızı + Bilişsel Kondisyon Eğilimi (N>=5)
// ============================================================

let bookFormOpen = false; // §6: form varsayılan kapalı — "Yeni Kitap Ekle" ile açılır

function renderLibrary(container) {
  const rs = readingStats();
  const trend = cognitiveTrend();
  const anlRate = calculateAnlamadimRate();
  const skya = skyaRate();
  const okunan = state.books.filter(b => !b.done);
  const biten = state.books.filter(b => b.done);
  const bugun = (() => { const t = todayStr(); let pg = 0; state.books.forEach(b => (b.history || []).forEach(h => { if (h.date === t) pg += h.pages; })); return pg; })();

  let html = '<div class="top-bar" style="margin-bottom:14px;"><h2 style="font-size:20px;font-weight:700;">' + icon("library", 22, "vertical-align:middle;margin-right:6px;color:var(--brand-blue);") + " Kitaplık</h2>" +
    '<button class="btn btn-primary btn-sm" data-act="toggleBookForm">' + icon(bookFormOpen ? "x" : "plus", 15) + " " + (bookFormOpen ? "Formu Kapat" : "Yeni Kitap Ekle") + "</button></div>";

  // SKYA önerisi (revize promptlar)
  if (skya > 30) {
    html += '<div class="nudge-card" style="background:var(--memory-indigo-bg);border-color:rgba(99,102,241,0.25);">' + icon("timer", 20, "color:var(--memory-indigo);") +
      '<div style="flex:1;"><div style="font-weight:700;font-size:14px;color:var(--memory-indigo);">Süre/Çözüm Yetersizliği (SKYA) Önerisi</div>' +
      '<div style="font-size:12.5px;color:var(--text-main);">SKYA hata oranın <b>%' + Math.round(skya) + "</b> (süren yetmiyor / çözüm yolunu bulamıyorsun). <b>Kitap okumayı arttırman önerilir</b>: günde " + Math.min(state.plan.readingMinutes || 20, READING_MAX_MINUTES) + " dakika okuma + zamanlı soru pratiği.</div></div></div>";
  }
  if (anlRate > 30) {
    const mins = Math.min(state.plan.readingMinutes || 20, READING_MAX_MINUTES);
    html += '<div class="nudge-card" style="background:var(--semantic-error-bg);border-color:rgba(239,68,68,0.3);">' + icon("brain", 20, "color:var(--semantic-error);") +
      '<div style="flex:1;"><div style="font-weight:700;font-size:14px;color:var(--on-error-bg);">Bilişsel Okuma Uyarısı</div>' +
      '<div style="font-size:12.5px;color:var(--on-error-bg);">"ANLAMADIM" hata oranın %' + Math.round(anlRate) + " (> %30). Bilişsel odak kapasiten netlerini sınırlıyor. Günlük öneri: <b>" + mins + " dakika</b> okuma (tavan 35 dk) + soru kökü kutulama stratejisi.</div></div></div>";
  }

  // Yeni Kitap formu (katlanır)
  html += '<div class="bento-card" style="margin-bottom:16px;' + (bookFormOpen ? "" : "display:none;") + ';" id="book-form-card"><h3 style="font-size:15px;font-weight:700;margin-bottom:12px;">' + icon("book-plus", 16, "vertical-align:middle;margin-right:6px;color:var(--brand-blue);") + " Yeni Kitap</h3>" +
    '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;">' +
    '<input type="text" id="book-title" class="input" placeholder="Kitap Adı">' +
    '<input type="text" id="book-author" class="input" placeholder="Yazar (opsiyonel)">' +
    '<input type="number" inputmode="numeric" id="book-pages" class="input" placeholder="Toplam Sayfa" min="1"></div>' +
    '<button class="btn btn-primary w-full btn-sticky" data-act="addBook" style="margin-top:12px;">' + icon("plus", 15) + " Kitabı Ekle</button></div>";

  // §6: İKİ SÜTUN — İstatistikler (sol) + Kitap listeleri (sağ)
  html += '<div class="ikili-grid" style="--ikili:1fr 1.7fr;">';

  // SOL: İstatistikler paneli
  html += '<div class="bento-card" style="align-self:start;"><h3 style="font-size:15px;font-weight:700;margin-bottom:12px;">' + icon("bar-chart-3", 15, "vertical-align:-3px;margin-right:6px;color:var(--brand-blue);") + " İstatistikler</h3>";
  html += '<div class="kb-kpi"><div><b class="tabular">' + state.books.length + "</b><span>Toplam Kitap</span></div><div><b class=\"tabular\" style=\"color:var(--semantic-success);\">" + biten.length + "</b><span>Tamamlanan</span></div></div>";
  html += '<div class="kb-kpi kb-kpi2"><div><b class="tabular" style="color:var(--brand-blue);">' + rs.pages + "</b><span>Okunan Sayfa</span></div><div><b class=\"tabular\" style=\"color:var(--semantic-warning);\">" + bugun + "</b><span>Bugün</span></div></div>";
  html += '<div class="kb-satir tabular" style="flex-direction:column;align-items:flex-start;gap:4px;"><span>Disiplin Puanı: <b>%' + rs.discipline + "</b></span><span>Okuma Hızı: <b>" + (rs.speed !== null ? rs.speed + " sf/sa" : "-") + "</b></span><span>Toplam Süre: <b>" + rs.minutes + " dk</b></span></div>";
  html += '<div class="bento-card" style="background:var(--bg-canvas);box-shadow:none;margin-top:12px;padding:12px;"><b style="font-size:12.5px;">' + icon("activity", 13, "vertical-align:-2px;color:var(--memory-indigo);") + " Bilişsel Kondisyon Eğilimi</b>";
  if (trend.ready) {
    html += '<p class="text-xs" style="margin-top:6px;">' + esc(trend.message) + '</p><p class="text-xs text-muted tabular" style="margin-top:4px;">İlk yarı ort. ' + trend.firstAvg + " → Son yarı ort. " + trend.lastAvg + " (N=" + trend.n + ")</p>";
  } else {
    html += '<p class="text-xs text-muted" style="margin-top:6px;">Korelasyon için en az <b>' + COGNITIVE_CORR_MIN_EXAMS + "</b> deneme gerekli (şu an " + trend.n + ").</p>";
  }
  html += "</div></div>";

  // SAĞ: Okunan Kitaplar (şu an) + Tamamlanan Kitaplar
  html += '<div><div class="bento-card" style="margin-bottom:14px;"><h3 style="font-size:15px;font-weight:700;margin-bottom:8px;">' + icon("book-open", 15, "vertical-align:-3px;margin-right:6px;color:var(--brand-blue);") + " Okunan Kitaplar (" + okunan.length + ")</h3>";
  if (okunan.length) {
    html += okunan.map(b => {
      const idx = state.books.indexOf(b);
      const pct = clamp(Math.round((b.read / b.pages) * 100), 0, 100);
      return '<div style="padding:12px 0;border-bottom:1px solid var(--border-card);">' +
        '<div class="flex items-center gap-2" style="flex-wrap:wrap;margin-bottom:6px;">' +
        '<div style="flex:1;min-width:0;"><div style="font-weight:700;font-size:14px;">' + esc(b.title) + (b.author ? ' <span class="text-xs text-muted">— ' + esc(b.author) + "</span>" : "") + "</div>" +
        '<div class="text-xs text-muted tabular">' + b.read + " / " + b.pages + " sayfa · " + (b.pages - b.read) + " kaldı</div></div>" +
        '<span class="tabular font-bold" style="color:var(--brand-blue);">%' + pct + "</span></div>" +
        '<div class="progress" style="margin-bottom:8px;"><div style="width:' + pct + "%;background:" + pctBarColor(pct) + ';"></div></div>' +
        '<div style="display:flex;gap:8px;flex-wrap:wrap;"><input type="number" inputmode="numeric" class="input" placeholder="Bugün kaç sayfa?" style="flex:1;min-width:120px;min-height:40px;" data-book-pages="' + idx + '">' +
        '<input type="number" inputmode="numeric" class="input" placeholder="Dk (opsiyonel)" style="width:110px;min-height:40px;" data-book-minutes="' + idx + '">' +
        '<button class="btn btn-sm btn-primary" data-act="updateBookRead" data-idx="' + idx + '">' + icon("save", 13) + " Aç/Kaydet</button>" +
        '<button class="icon-btn" data-act="deleteBook" data-idx="' + idx + '" style="min-width:44px;min-height:44px;">' + icon("trash-2", 15, "color:var(--semantic-error);") + "</button></div>" +
        ((b.history && b.history.length)
          ? '<details style="margin-top:8px;"><summary class="text-xs text-muted" style="cursor:pointer;">Okuma Geçmişi (' + b.history.length + ")</summary><div class=\"text-xs text-muted\" style=\"margin-top:6px;display:flex;flex-direction:column;gap:3px;\">" +
            b.history.slice().reverse().map(h => "<span class=\"tabular\">" + fmtDate(h.date) + ": +" + h.pages + " sayfa" + (h.minutes ? " · " + h.minutes + " dk" : "") + "</span>").join("") + "</div></details>"
          : "") +
        "</div>";
    }).join("");
  } else {
    html += '<div class="empty-state">' + icon("library", 30) + "<div>Şu an okuduğun kitap yok. <b>Yeni Kitap Ekle</b> ile başla.</div></div>";
  }
  html += "</div>";

  html += '<div class="bento-card"><h3 style="font-size:15px;font-weight:700;margin-bottom:8px;">' + icon("check-circle", 15, "vertical-align:-3px;margin-right:6px;color:var(--semantic-success);") + " Tamamlanan Kitaplar (" + biten.length + ")</h3>";
  if (biten.length) {
    html += biten.map(b => {
      const idx = state.books.indexOf(b);
      return '<div class="flex items-center gap-2" style="padding:10px 0;border-bottom:1px solid var(--border-card);">' +
        icon("book", 16, "color:var(--semantic-success);flex-shrink:0;") +
        '<div style="flex:1;min-width:0;"><div style="font-weight:600;font-size:13.5px;">' + esc(b.title) + (b.author ? ' <span class="text-xs text-muted">— ' + esc(b.author) + "</span>" : "") + '</div><div class="text-xs text-muted tabular">' + b.pages + " sayfa · tamamlandı</div></div>" +
        '<span class="badge badge-success">' + icon("check", 10) + " TAMAMLANDI</span>" +
        '<button class="icon-btn" data-act="deleteBook" data-idx="' + idx + '" style="min-width:44px;min-height:44px;">' + icon("trash-2", 15, "color:var(--semantic-error);") + "</button></div>";
    }).join("");
  } else {
    html += '<div class="empty-state" style="padding:16px;">' + icon("check-circle", 26) + "<div>Bitirdiğin kitaplar burada listelenir.</div></div>";
  }
  html += "</div></div></div>";

  container.innerHTML = html;
}

function addBook() {
  const title = document.getElementById("book-title").value.trim();
  const author = document.getElementById("book-author").value.trim();
  const pages = Number(document.getElementById("book-pages").value);
  if (!title) return toast("Kitap adı gerekli.", "error");
  if (!pages || pages < 1) return toast("Geçerli bir sayfa sayısı gir.", "error");
  state.books.push({ id: uid(), title: title, author: author, pages: pages, read: 0, done: false, history: [] });
  saveState();
  toast("Kitap eklendi.", "success"); bookFormOpen = false;
  renderLibrary(document.getElementById("main-content"));
  if (window.lucide && lucide.createIcons) lucide.createIcons();
}

function deleteBook(idx) {
  const b = state.books[Number(idx)];
  if (!b) return;
  openConfirm('"' + b.title + '" silinecek. Emin misin?', () => { state.books.splice(Number(idx), 1); saveState(); toast("Kitap silindi.", "success"); navigate("library"); });
}

function updateBookRead(idx) {
  const b = state.books[Number(idx)];
  if (!b) return;
  const pagesEl = document.querySelector('[data-book-pages="' + sel(String(idx)) + '"]');
  const minEl = document.querySelector('[data-book-minutes="' + sel(String(idx)) + '"]');
  const pages = Number(pagesEl && pagesEl.value) || 0;
  const minutes = Number(minEl && minEl.value) || 0;
  if (pages <= 0) return toast("Bugün okuduğun sayfa sayısını gir.", "error");
  b.read = Math.min(b.pages, b.read + pages);
  b.history.push({ date: todayStr(), pages: pages, minutes: minutes });
  if (b.read >= b.pages) { b.done = true; fireConfetti(); toast("Kitap tamamlandı! Tebrikler.", "success"); }
  else toast("Kaydedildi: +" + pages + " sayfa.", "success");
  saveState();
  state.dailyTasks.read = true;
  ensureDailyStreakCount();
  evaluateBadges();
  renderLibrary(document.getElementById("main-content"));
  if (window.lucide && lucide.createIcons) lucide.createIcons();
}
