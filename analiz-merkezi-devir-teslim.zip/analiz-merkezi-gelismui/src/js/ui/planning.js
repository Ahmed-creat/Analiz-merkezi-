// ============================================================
// ANALİZ MERKEZİ v5.1 — PLANLAMA / MODÜL D (modül: ui/planning.js)
// Tersine planlama + Haftalık İvme + Altın Saat + Rejim tablosu
// ============================================================

function renderPlanning(container) {
  const p = state.plan;
  const mom = weeklyMomentum();
  const dl = daysLeftToExam();
  const anlRate = calculateAnlamadimRate();
  const golden = goldenHourTopics(5);

  // §7: başlık solda + kompakt geri sayım sağ üst
  let html = '<div class="top-bar" style="margin-bottom:14px;"><h2 style="font-size:20px;font-weight:700;">' + icon("calendar-clock", 22, "vertical-align:middle;margin-right:6px;color:var(--brand-blue);") + " Planlama</h2>";
  if (p.targetDate && dl !== null) {
    html += '<div class="mini-count" data-countdown="' + attr(p.targetDate) + '"><span class="text-xs text-muted" style="letter-spacing:0.05em;">SINAVA KALAN</span><span class="mc-box"><b class="val days">0</b><i>GÜN</i></span><span class="mc-box"><b class="val hours">00</b><i>SAAT</i></span><span class="mc-box"><b class="val minutes">00</b><i>DAK</i></span><span class="mc-box"><b class="val seconds">00</b><i>SN</i></span></div>';
  }
  html += "</div>";

  html += '<div class="ikili-grid" style="--ikili:1.2fr 1fr;">';

  // ---- SOL: Hedef Belirleme + Okuma (§7 sol form grubu) ----
  html += '<div class="bento-card"><h3 style="font-size:15px;font-weight:700;margin-bottom:12px;">' + icon("target", 16, "vertical-align:middle;margin-right:6px;color:var(--brand-blue);") + " Deneme Hedefi</h3>";
  html += '<p class="text-xs text-muted" style="margin:-6px 0 10px;">TYT denemelerin için hedef tarih, saat ve net — deneme tüm dersleri kapsar.</p>';
  html += '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;">' +
    '<div><label class="text-xs text-muted">Sınav Tarihi</label><input type="date" id="plan-date" class="input" value="' + attr(p.targetDate || "") + '"></div>' +
    '<div><label class="text-xs text-muted">Sınav Saati</label><input type="time" id="plan-time" class="input" value="' + attr(p.examTime || "") + '"></div>' +
    '<div><label class="text-xs text-muted">Hedef TYT Net</label><input type="number" inputmode="decimal" id="plan-net" class="input" min="0" max="120" step="0.5" value="' + (p.targetNet || "") + '"></div>' +
    '<div><label class="text-xs text-muted">Günlük Verimli Çalışma (saat)</label><input type="number" inputmode="decimal" id="plan-hours" class="input" min="0" max="16" step="0.5" value="' + (p.dailyHours || "") + '"></div></div>';
  html += '<div class="mini-ayrac"></div><div class="text-xs font-bold" style="letter-spacing:0.05em;color:var(--text-muted);margin-bottom:8px;">GÜNLÜK OKUMA</div>';
  html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">' +
    '<div><label class="text-xs text-muted">Süre (dk, tavan ' + READING_MAX_MINUTES + ')</label><input type="number" inputmode="numeric" id="plan-reading-min" class="input" min="0" max="' + READING_MAX_MINUTES + '" value="' + (p.readingMinutes || "") + '"></div>' +
    '<div><label class="text-xs text-muted">Hedef (sayfa)</label><input type="number" inputmode="numeric" id="plan-reading" class="input" min="0" value="' + (p.dailyReading || "") + '"></div></div>';
  html += '<button class="btn btn-primary w-full btn-sticky" data-act="savePlan" style="margin-top:14px;">' + icon("save", 15) + " Planı Kaydet</button></div>";

  // ---- OKUL SINAVLARI: tek ders + seçilen konular (sınav kapsamı yalnızca burada) ----
  html += renderSchoolExamsHTML();

  // ---- SAĞ: İvme Ölçer + Sirkadiyen Ritim ----
  html += '<div><div class="bento-card" style="margin-bottom:14px;"><h3 style="font-size:15px;font-weight:700;margin-bottom:4px;">' + icon("rocket", 16, "vertical-align:middle;margin-right:6px;color:var(--semantic-warning);") + " İvme Ölçer</h3>";
  if (mom) {
    const tempo = mom.weekly <= 1 ? "Rahat tempo — istikrar yeterli." : mom.weekly <= 3 ? "Orta tempoda ivme gerekli." : "Yüksek tempo — her hafta net artışı ŞART.";
    html += '<p class="text-xs text-muted">' + esc(tempo) + "</p>" +
      '<div class="flex items-center gap-2"><span class="text-2xl font-bold tabular" style="color:var(--brand-blue);">+' + mom.weekly + '</span><span class="text-xs text-muted">haftalık net artışı hedefi</span></div>' +
      '<div class="stat-grid" style="margin-top:10px;">' + statBox("Mevcut Ort.", mom.current) + statBox("Hedef Net", mom.target) + statBox("Kalan Hafta", mom.weeks) + "</div>";
  } else {
    html += '<p class="text-sm text-muted">Hedef net ve en az 1 deneme gerekli. Formül: (HedefNet − MevcutOrt) / KalanHafta.</p>';
  }
  html += "</div>";

  html += '<div class="bento-card"><h3 style="font-size:15px;font-weight:700;margin-bottom:10px;">' + icon("sunrise", 16, "vertical-align:middle;margin-right:6px;color:var(--semantic-warning);") + " Sirkadiyen Ritim</h3>";
  html += '<div class="text-xs text-muted" style="margin-bottom:8px;">En verimli dilimini seç — kritik konular bu saate atanır.</div><div class="rhythm-grid">';
  html += RHYTHMS.map(r =>
    '<button class="rhythm-card ' + (p.rhythm === r.key ? "active" : "") + '" data-act="setRhythm" data-rhythm="' + attr(r.key) + '">' +
    icon(r.icon, 20) + '<div style="font-weight:700;font-size:13px;">' + r.key + '</div><div class="text-xs text-muted tabular">' + r.hours + "</div></button>"
  ).join("");
  html += "</div></div></div></div>";

  // ---- ÇALIŞMA TAKVİMİ (Google Takvim tarzı aylık ızgara) ----
  html += renderCalendarHTML();

  // ---- §7 alt: Altın Saat Önerisi + KRİTİK konular ----
  html += '<div class="bento-card" style="margin-top:16px;"><h3 style="font-size:15px;font-weight:700;margin-bottom:4px;">' + icon("sun", 16, "vertical-align:middle;margin-right:6px;color:var(--semantic-warning);") + " Altın Saat Önerisi</h3>" +
    '<p class="text-xs text-muted" style="margin-bottom:10px;">En zor (en yüksek öncelik) konular, seçtiğin verimli dilime otomatik atanır: <b>KRİTİK ODAK: ALTIN SAAT</b></p>';
  if (golden.length) {
    html += golden.map(g =>
      '<div class="topic-row"><span class="topic-rank">' + icon("zap", 14) + '</span><div class="topic-info"><span style="font-weight:600;font-size:13.5px;">' + esc(splitKey(g.key).topic) + '</span><span class="text-xs text-muted">' + esc(splitKey(g.key).lesson) + " · Puan " + g.score + '</span></div><span class="golden-hour-tag">KRİTİK ODAK · ' + esc(g.window.key).toUpperCase() + " (" + g.window.hours + ")</span></div>"
    ).join("");
  } else {
    html += '<div class="empty-state">' + icon("sun", 30) + "<div>Hata verisi girince en kritik konular burada altın saat etiketiyle listelenir.</div></div>";
  }
  html += "</div>";

  if (anlRate > 30) {
    html += '<div class="bento-card" style="margin-top:16px;background:var(--memory-indigo-bg);border:none;"><h3 style="font-size:14px;font-weight:700;margin-bottom:6px;">' + icon("lightbulb", 15, "vertical-align:middle;margin-right:6px;") + " Bilişsel Okuma Önerisi</h3>" +
      '<p class="text-sm">"ANLAMADIM" oranın %' + Math.round(anlRate) + ". Odak kapasiteni artırmak için günde en fazla <b>" + READING_MAX_MINUTES + " dakika</b> yoğun okuma yap; daha fazlası önerilmez (tavan sınırı). Soru köklerini kutulara ayırarak oku.</p></div>";
  }

  container.innerHTML = html;
  const sl = document.getElementById("school-lesson");
  if (sl && !sl.dataset.bound) {
    sl.dataset.bound = "1";
    sl.addEventListener("change", onSchoolLessonChange);
  }
}

// ===== ÇALIŞMA TAKVİMİ =====
// Olaylar: 3/7/14/21/28. gün tekrarları (T), sınav hazırlık tekrarları
// (sınav − 7 / − 3 / − 1) ve sınav günü — aylık ızgarada rozet olarak gösterilir.
let calCursor = null; // null = içinde bulunulan ay

// ===== OKUL SINAVLARI (tek ders + seçilen konular) =====
// Okul sınavı TEK derstendir; istenen konular seçilir. Sınava hazırlık
// tekrarları (1 hafta / 3 gün / 1 gün önce) bu konulara çalışır.
let schoolFormLesson = "";

function renderSchoolExamsHTML() {
  const exams = state.plan.schoolExams || [];
  let h = '<div class="bento-card" style="margin-top:16px;"><h3 style="font-size:15px;font-weight:700;margin-bottom:4px;">' + icon("graduation-cap", 16, "vertical-align:middle;margin-right:6px;color:var(--brand-blue);") + " Okul Sınavları</h3>" +
    '<p class="text-xs text-muted" style="margin:0 0 10px;">Her okul sınavı tek derstendir; sınavda çıkacakını düşündüğün konuları seç — hazırlık tekrarları ve hatırlatmalar bunlara göre çalışır.</p>';
  if (exams.length) {
    h += exams.map(se => {
      const gun = gunFarki(se.date);
      const kalan = gun === null ? "" : gun === 0 ? "BUGÜN" : gun === 1 ? "YARIN" : gun + " gün kaldı";
      return '<div class="list-row" style="align-items:center;"><div style="flex:1;min-width:0;">' +
        '<div style="font-weight:700;font-size:13px;">' + esc(se.lesson) + ' Sınavı</div>' +
        '<div class="text-xs text-muted tabular">' + fmtDate(se.date) + (se.time ? " · " + se.time : "") + " · " + (se.topics ? se.topics.length : 0) + " konu" + (kalan ? " · <b>" + kalan + "</b>" : "") + "</div>" +
        (se.topics && se.topics.length ? '<div class="text-xs text-muted" style="margin-top:2px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' + se.topics.map(t => esc(splitKey(t).topic)).join(", ") + "</div>" : "") +
        "</div>" +
        '<button class="icon-btn" data-act="delSchoolExam" data-id="' + attr(se.id) + '" style="min-width:48px;min-height:48px;">' + icon("trash-2", 15, "color:var(--semantic-error);") + "</button></div>";
    }).join("");
  } else {
    h += '<div class="empty-state" style="padding:12px;">' + icon("calendar-plus", 24) + "<div>Henüz okul sınavı eklenmedi.</div></div>";
  }
  h += '<div class="mini-ayrac"></div><div class="text-xs font-bold" style="letter-spacing:0.05em;color:var(--text-muted);margin-bottom:8px;">YENİ OKUL SINAVI</div>';
  h += '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px;margin-bottom:8px;">' +
    '<div><label class="text-xs text-muted">Ders</label><select id="school-lesson" class="select"><option value="">Ders Seç…</option>' + Object.keys(LESSON_CONFIG).map(l => '<option value="' + attr(l) + '"' + (schoolFormLesson === l ? " selected" : "") + ">" + esc(l) + "</option>").join("") + "</select></div>" +
    '<div><label class="text-xs text-muted">Tarih</label><input type="date" id="school-date" class="input"></div>' +
    '<div><label class="text-xs text-muted">Saat</label><input type="time" id="school-time" class="input"></div></div>';
  if (schoolFormLesson) {
    h += '<div class="text-xs text-muted" style="margin-bottom:6px;">Sınav konularını seç:</div><div class="scope-topics">' +
      topicsOfLesson(schoolFormLesson).map(tp => {
        const key = schoolFormLesson + " > " + tp;
        return '<label class="chk"><input type="checkbox" class="school-topic" value="' + attr(key) + '"><span>' + esc(tp) + "</span></label>";
      }).join("") + "</div>";
  } else {
    h += '<div class="err-hint">' + icon("mouse-pointer-click", 14, "flex-shrink:0;") + "Önce <b>&nbsp;Ders&nbsp;</b> seç — o dersin konuları burada açılır.</div>";
  }
  h += '<button class="btn btn-primary w-full" data-act="addSchoolExam" style="margin-top:10px;">' + icon("plus", 15) + " Sınavı Ekle</button></div>";
  return h;
}

function gunFarki(dateStr) {
  const d = parseDay(dateStr);
  if (!d) return null;
  const t = parseDay(todayStr());
  return Math.round((d - t) / 86400000);
}

function onSchoolLessonChange() {
  const sel = document.getElementById("school-lesson");
  if (!sel) return;
  schoolFormLesson = sel.value;
  renderPlanning(document.getElementById("main-content"));
  if (window.lucide && lucide.createIcons) lucide.createIcons();
}


// Okul sınavı hazırlık günleri: SINAVA KALAN SÜREYE ORANLA hesaplanır.
// kalan >= 8 gün → [%50, %25, 1] · kalan >= 4 gün → [%50, 1] · kısaysa → [1]
// (örn. 10 gün kaldıysa: 5 gün önce, 3 gün önce, 1 gün önce)
function schoolPrepDaysFor(kalanGun) {
  const d = Math.max(1, Math.round(Number(kalanGun) || 1));
  const out = new Set([1]);
  if (d >= 4) out.add(Math.max(2, Math.round(d * 0.5)));
  if (d >= 8) out.add(Math.max(3, Math.round(d * 0.25)));
  return Array.from(out).sort((a, b) => b - a);
}
function schoolPrepAd(gun, preps) {
  if (gun === 1) return "Formül turu";
  if (preps.indexOf(gun) === 0 && preps.length > 2) return "Genel tekrar";
  return "Eksik kapatma";
}

function addSchoolExam() {
  const lesson = document.getElementById("school-lesson").value;
  const date = document.getElementById("school-date").value;
  const time = document.getElementById("school-time").value;
  const topics = Array.from(document.querySelectorAll(".school-topic:checked")).map(c => c.value);
  if (!lesson || !date) { toast("Okul sınavı için ders ve tarih seç.", "error"); return; }
  if (!topics.length) { toast("En az bir konu seç — hazırlık tekrarları bu konulara çalışır.", "error"); return; }
  state.plan.schoolExams = state.plan.schoolExams || [];
  const kalan = Math.round((parseDay(date) - parseDay(todayStr())) / 86400000);
  state.plan.schoolExams.push({ id: uid(), lesson: lesson, date: date, time: time || "", topics: topics, prepDays: schoolPrepDaysFor(kalan) });
  saveState();
  schoolFormLesson = "";
  toast(lesson + " sınavı eklendi (" + topics.length + " konu) — hazırlık günleri takvime işlendi.", "success");
  renderPlanning(document.getElementById("main-content"));
  if (window.lucide && lucide.createIcons) lucide.createIcons();
}

function delSchoolExam(id) {
  state.plan.schoolExams = (state.plan.schoolExams || []).filter(se => se.id !== id);
  saveState();
  renderPlanning(document.getElementById("main-content"));
  if (window.lucide && lucide.createIcons) lucide.createIcons();
}



function calMonthLabel(d) { return d.toLocaleDateString("tr-TR", { month: "long", year: "numeric" }); }

function calendarEventMap() {
  const map = {}; // "YYYY-MM-DD" -> [{tip, etiket}]
  const put = (dateStr, obj) => {
    if (!dateStr) return;
    (map[dateStr] = map[dateStr] || []).push(obj);
  };
  // 1) Konu tekrar günleri (3/7/14/21/28)
  Object.keys(state.memory).forEach(key => {
    const mem = state.memory[key];
    if (!mem || !mem.schedule) return;
    Object.entries(mem.schedule).forEach(([day, date]) => {
      if (date) put(date, { tip: "tek", etiket: day + ". gün tekrar" });
    });
  });
  // Aynı gün tekrarları tek rozette birleştir ("tekrar ×3" gibi)
  Object.keys(map).forEach(d => {
    const teks = map[d].filter(x => x.tip === "tek");
    if (teks.length > 1) {
      map[d] = map[d].filter(x => x.tip !== "tek");
      map[d].unshift({ tip: "tek", etiket: "tekrar ×" + teks.length });
    }
  });
  // 2) DENEME sınavı + hazırlık tekrarları
  const tgt = state.plan.targetDate ? parseDay(state.plan.targetDate) : null;
  if (tgt && !isNaN(tgt)) {
    put(toDayStr(tgt), { tip: "sinav", etiket: "DENEME", kaynak: "deneme" });
    [[7, "Genel tekrar"], [3, "Eksik kapatma"], [1, "Formül turu"]].forEach(([gun, ad]) => {
      const d = new Date(tgt.getTime());
      d.setDate(d.getDate() - gun);
      put(toDayStr(d), { tip: "hazirlik", etiket: "Deneme · " + ad, kaynak: "deneme", prepAd: ad });
    });
  }
  // 3) OKUL SINAVLARI (tek ders): sınav günü + hazırlık tekrarları
  (state.plan.schoolExams || []).forEach(se => {
    const d0 = parseDay(se.date);
    if (!d0 || isNaN(d0)) return;
    put(se.date, { tip: "sinav", etiket: se.lesson, kaynak: "okul", examId: se.id });
    const preps = (se.prepDays && se.prepDays.length ? se.prepDays : [3, 1]).slice().sort((a, b) => b - a);
    preps.forEach(gun => {
      const d = new Date(d0.getTime());
      d.setDate(d.getDate() - gun);
      const ad = schoolPrepAd(gun, preps);
      put(toDayStr(d), { tip: "hazirlik", etiket: se.lesson + " · " + ad, kaynak: "okul", examId: se.id, prepAd: ad });
    });
  });
  return map;
}

function renderCalendarHTML() {
  const now = new Date();
  if (!calCursor) calCursor = new Date(now.getFullYear(), now.getMonth(), 1);
  const y = calCursor.getFullYear(), m = calCursor.getMonth();
  const events = calendarEventMap();
  const ilk = new Date(y, m, 1);
  const son = new Date(y, m + 1, 0);
  // Türkçe hafta başlangıcı Pazartesi
  const startOffset = (ilk.getDay() + 6) % 7;
  const todayStrNow = todayStr();
  const aylar = ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"];

  let h = '<div class="bento-card cal-card"><div class="cal-head">' +
    '<h3 style="font-size:15px;font-weight:700;">' + icon("calendar-days", 16, "vertical-align:middle;margin-right:6px;color:var(--brand-blue);") + " Çalışma Takvimi</h3>" +
    '<div class="cal-nav">' +
    '<button class="btn btn-ghost btn-sm" data-act="calPrev" style="min-width:36px;min-height:36px;padding:4px;">' + icon("chevron-left", 15) + "</button>" +
    '<span class="cal-title" style="min-width:118px;text-align:center;">' + aylar[m] + " " + y + "</span>" +
    '<button class="btn btn-ghost btn-sm" data-act="calNext" style="min-width:36px;min-height:36px;padding:4px;">' + icon("chevron-right", 15) + "</button>" +
    "</div></div>";
  h += '<div class="cal-legend">' +
    '<span><i class="cal-dot" style="background:var(--memory-indigo);"></i> Konu tekrarı (3/7/14/21/28. gün)</span>' +
    '<span><i class="cal-dot" style="background:var(--semantic-warning);"></i> Sınava hazırlık tekrarı</span>' +
    '<span><i class="cal-dot" style="background:var(--semantic-error);"></i> Sınav günü</span>' +
    "</div>";
  h += '<div class="cal-grid">';
  ["Pzt", "Sal", "Çar", "Per", "Cum", "Cmt", "Paz"].forEach(d => { h += '<div class="cal-dow">' + d + "</div>"; });
  // Ay başı boşlukları
  for (let i = 0; i < startOffset; i++) h += "<div></div>";
  for (let gun = 1; gun <= son.getDate(); gun++) {
    const ds = toDayStr(new Date(y, m, gun));
    const evs = events[ds] || [];
    const isToday = ds === todayStrNow;
    h += '<button type="button" class="cal-day' + (isToday ? " today" : "") + (calSelected === ds ? " sel" : "") + '" data-act="calDay" data-date="' + ds + '"><span class="cal-dnum">' + gun + "</span>";
    if (evs.length) {
      h += '<span class="cal-pills">' + evs.map(e => '<span class="cal-pill ' + e.tip + '">' + esc(e.etiket) + "</span>").join("") + "</span>";
    }
    h += "</button>";
  }
  h += "</div>";
  // Ait olmayan günler yerine ay özeti
  const ayEvs = Object.keys(events).filter(d => d.slice(0, 7) === toDayStr(new Date(y, m, 1)).slice(0, 7));
  const tekSay = ayEvs.reduce((a, d) => a + events[d].filter(e => e.tip === "tek").length, 0);
  const hazSay = ayEvs.reduce((a, d) => a + events[d].filter(e => e.tip === "hazirlik").length, 0);
  const sinSay = ayEvs.reduce((a, d) => a + events[d].filter(e => e.tip === "sinav").length, 0);
  h += renderCalDetailHTML(events);
  h += '<p class="text-xs text-muted" style="margin-top:10px;">Güne dokun: o günün sınavı, tekrarları ve konuları burada görünür.</p>';
  h += '<p class="text-xs text-muted" style="margin-top:6px;">Bu ay: <b>' + tekSay + "</b> tekrar günü" + (hazSay ? " · <b>" + hazSay + "</b> hazırlık tekrarı" : "") + (sinSay ? " · <b>" + sinSay + "</b> sınav günü" : "") + ".</p>";
  h += "</div>";
  return h;
}

// ===== GÜN DETAYI: takvimde bir güne dokununca o günün planı =====
let calSelected = null;

function renderCalDetailHTML(events) {
  if (!calSelected) {
    return '<div class="cal-detail" id="cal-detail"><div class="text-xs text-muted" style="display:flex;align-items:center;gap:8px;padding:10px 12px;">' +
      icon("calendar-search", 15, "flex-shrink:0;") + "Bir güne dokun — o günün sınavları, tekrarları ve çalışacağın konular burada görünür.</div></div>";
  }
  const ds = calSelected;
  const evs = events[ds] || [];
  const dt = parseDay(ds);
  const baslik = dt ? dt.toLocaleDateString("tr-TR", { day: "numeric", month: "long", year: "numeric", weekday: "long" }) : ds;
  let h = '<div class="cal-detail" id="cal-detail"><div style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:8px;">' +
    '<span style="font-weight:700;font-size:13.5px;">' + icon("calendar-search", 15, "vertical-align:-2px;margin-right:4px;color:var(--brand-blue);") + esc(baslik) + "</span>" +
    '<button class="btn btn-ghost btn-sm" data-act="calDayClose" style="min-height:30px;padding:2px 10px;">Kapat</button></div>';

  const okulById = {};
  (state.plan.schoolExams || []).forEach(se => { okulById[se.id] = se; });
  const konuListesi = (baslik2, topics) =>
    '<div class="text-xs text-muted" style="margin-top:2px;">' + baslik2 + "</div>" +
    '<div style="margin-top:4px;">' + topics.map(k => '<div class="cd-row">' + icon("book-open", 12, "flex-shrink:0;color:var(--brand-blue);") + "<span>" + esc(splitKey(k).topic) + "</span></div>").join("") + "</div>";

  evs.forEach(e => {
    if (e.tip === "sinav" && e.kaynak === "deneme") {
      h += '<div class="cd-box" style="border-color:rgba(239,68,68,0.35);"><div style="font-weight:800;font-size:13px;color:var(--on-error-bg);">' + icon("alert-triangle", 14, "vertical-align:-2px;") + " Deneme Sınavı Günü</div>" +
        (state.plan.examTime ? '<div class="text-xs text-muted" style="margin-top:2px;">Sınav saati: <b class="tabular">' + esc(state.plan.examTime) + "</b></div>" : "") +
        '<div class="text-xs text-muted" style="margin-top:2px;">Deneme tüm TYT derslerini (8 ders, 120 soru) kapsar.</div></div>';
    }
    if (e.tip === "sinav" && e.kaynak === "okul") {
      const se = okulById[e.examId] || { lesson: e.etiket, topics: [] };
      h += '<div class="cd-box" style="border-color:rgba(239,68,68,0.35);"><div style="font-weight:800;font-size:13px;color:var(--on-error-bg);">' + icon("alert-triangle", 14, "vertical-align:-2px;") + " Okul Sınavı: " + esc(se.lesson) + "</div>" +
        (se.time ? '<div class="text-xs text-muted" style="margin-top:2px;">Sınav saati: <b class="tabular">' + esc(se.time) + "</b></div>" : "") +
        konuListesi("Sınav konuları (" + (se.topics || []).length + "):", se.topics || []) + "</div>";
    }
    if (e.tip === "hazirlik") {
      const okul = e.kaynak === "okul" ? (okulById[e.examId] || null) : null;
      const gunBilgi = e.prepAd === "Genel tekrar" ? "sınavdan 1 hafta önce" : e.prepAd === "Eksik kapatma" ? "sınavdan 3 gün önce" : "sınavdan 1 gün önce";
      const aciklama = e.prepAd === "Genel tekrar" ? "Tüm konuları hızlı tur ile tarama günü." :
        e.prepAd === "Eksik kapatma" ? "En zayıf konuları seçip eksik noktaları kapatma günü." : "Formüller + yanlış soru defterini son kez tekrar etme günü.";
      h += '<div class="cd-box" style="border-color:rgba(245,166,35,0.4);"><div style="font-weight:800;font-size:13px;color:var(--on-warning-bg);">' + icon("shield-check", 14, "vertical-align:-2px;") + " Sınava Hazırlık: " + esc(e.etiket) + ' <span class="text-xs text-muted font-normal">(' + gunBilgi + ")</span></div>" +
        '<div class="text-xs text-muted" style="margin-top:2px;">' + aciklama + "</div>" +
        (okul && okul.topics && okul.topics.length ? konuListesi("Çalışılacak konular (" + okul.topics.length + "):", okul.topics) : "") + "</div>";
    }
  });

  // O günün konu tekrarları (3/7/14/21/28. gün)
  const tekrarlar = [];
  Object.keys(state.memory).forEach(key => {
    const mem = state.memory[key];
    if (mem && mem.schedule) Object.entries(mem.schedule).forEach(([gun, tarih]) => { if (tarih === ds) tekrarlar.push({ key: key, gun: Number(gun) }); });
  });
  tekrarlar.sort((a, b2) => splitKey(a.key).lesson.localeCompare(splitKey(b2.key).lesson, "tr"));
  if (tekrarlar.length) {
    h += '<div class="cd-box"><div style="font-weight:800;font-size:13px;color:var(--memory-indigo);">' + icon("refresh-cw", 14, "vertical-align:-2px;") + " Konu Tekrarları (" + tekrarlar.length + ')</div><div style="margin-top:6px;">' +
      tekrarlar.map(t2 => {
        const p = splitKey(t2.key);
        return '<div class="cd-row">' + icon("rotate-cw", 12, "flex-shrink:0;color:var(--memory-indigo);") + "<span><b>" + esc(p.lesson) + ":</b> " + esc(p.topic) + ' <span class="text-xs text-muted">— ' + t2.gun + ". gün tekrarı</span></span></div>";
      }).join("") + "</div></div>";
  }
  if (!evs.length && !tekrarlar.length) {
    h += '<div class="text-xs text-muted">' + icon("calendar-x", 13, "vertical-align:-2px;") + " Bu gün için kayıtlı sınav ya da tekrar yok.</div>";
  }
  h += "</div>";
  return h;
}

function selectCalDay(ds) {
  calSelected = (calSelected === ds) ? null : ds;
  renderPlanning(document.getElementById("main-content"));
  if (window.lucide && lucide.createIcons) lucide.createIcons();
}

function calShift(delta) {
  if (!calCursor) calCursor = new Date();
  calCursor = new Date(calCursor.getFullYear(), calCursor.getMonth() + delta, 1);
  renderPlanning(document.getElementById("main-content"));
  if (window.lucide && lucide.createIcons) lucide.createIcons();
}

function setRhythm(key) {
  state.plan.rhythm = key; saveState();
  renderPlanning(document.getElementById("main-content"));
  if (window.lucide && lucide.createIcons) lucide.createIcons();
}

function savePlan() {
  const date = document.getElementById("plan-date").value;
  const examTimeEl = document.getElementById("plan-time");
  const examTime = examTimeEl ? examTimeEl.value : "";
  const net = Number(document.getElementById("plan-net").value);
  const hours = Number(document.getElementById("plan-hours").value);
  const rmin = Number(document.getElementById("plan-reading-min").value);
  const rpages = Number(document.getElementById("plan-reading").value);
  state.plan = {
    targetDate: date || null,
    examTime: examTime || "",
    schoolExams: state.plan.schoolExams || [],
    targetNet: net || 0,
    dailyHours: hours || 0,
    readingMinutes: rmin || 0,
    dailyReading: rpages || 0,
    rhythm: state.plan.rhythm || "Sabah"
  };
  saveState();
  toast("Plan kaydedildi.", "success");
  renderPlanning(document.getElementById("main-content"));
  renderCoachPanel();
  if (window.lucide && lucide.createIcons) lucide.createIcons();
}
