// ============================================================
// ANALİZ MERKEZİ v5.1 — KADEMELİ BAŞARI SİSTEMİ (modül: core/badges.js)
// Bronz (Başlangıç) → Gümüş (İstikrar) → Altın (Ustalık) → Elmas (Efsane)
// ============================================================

function badgeMetricValue(key) {
  if (key === "streak") return state.streak.count;
  if (key === "reading") return readingStats().minutes;
  if (key === "solved") return totalSolved();
  if (key === "memory") {
    // 28 gün döngüsüne kadar getirilen (tamamlanmış + en az 1 tekrar) konu sayısı
    return Object.keys(state.memory).filter(k => {
      const m = state.memory[k];
      return m && m.completedAt && (m.reviewCount || 0) >= 1;
    }).length;
  }
  return 0;
}

function tierOf(def, value) {
  let t = -1;
  def.tiers.forEach((th, i) => { if (value >= th) t = i; });
  return t;
}

function evaluateBadges() {
  let upgraded = false;
  BADGE_DEFS.forEach(def => {
    const value = badgeMetricValue(def.key);
    const tier = tierOf(def, value);
    const prev = state.badges[def.key] != null ? state.badges[def.key] : -1;
    if (tier > prev) {
      state.badges[def.key] = tier;
      upgraded = true;
      if (tier >= 0) {
        addNotification({
          title: "Yeni Rozet: " + def.name + " — " + def.tierNames[tier] + " (" + TIER_TITLES[tier] + ")",
          body: "Gelişim Seviyesi: " + SCHOLAR_TITLES[tier] + ". Durmak yok, devam!",
          kind: "badge"
        });
      }
    }
  });
  if (upgraded) {
    saveState();
    fireConfetti();
    toast("Rozet seviyesi atladı! Gelişim Seviyeni Ana Sayfa'da gör.", "success");
  }
}

function renderBadgesCard() {
  const rows = BADGE_DEFS.map(def => {
    const value = badgeMetricValue(def.key);
    const tier = tierOf(def, value);
    const next = tier < def.tiers.length - 1 ? def.tiers[tier + 1] : null;
    const pct = tier >= 0 ? 100 : (next ? Math.round((value / next) * 100) : 0);
    const color = tier >= 0 ? TIER_COLORS[tier] : "var(--text-muted)";
    return '<div style="display:flex;align-items:center;gap:10px;padding:10px 0;border-bottom:1px solid var(--border-card);">' +
      '<span style="width:34px;height:34px;border-radius:12px;background:var(--bg-canvas);display:flex;align-items:center;justify-content:center;flex-shrink:0;">' + icon(def.icon, 17, "color:" + color + ";") + '</span>' +
      '<div style="flex:1;min-width:0;"><div style="font-weight:600;font-size:13px;">' + def.name + '</div>' +
      '<div class="text-xs text-muted tabular">' + value.toLocaleString("tr-TR") + " " + def.unit +
      (tier >= 0 ? ' — <b style="color:' + color + ';">' + def.tierNames[tier] + "</b>" : "") +
      (next ? " · sonraki: " + next.toLocaleString("tr-TR") : "") + '</div></div>' +
      '<div class="progress" style="width:64px;"><div style="width:' + pct + "%;background:" + (tier >= 0 ? color : "var(--brand-blue)") + ';"></div></div>' +
    '</div>';
  }).join("");
  return '<div class="bento-card" style="margin-top:20px;"><h3 style="font-size:16px;font-weight:700;margin-bottom:6px;">' + icon("award", 18, "vertical-align:middle;margin-right:6px;color:var(--semantic-warning);") + ' Kademeli Başarı Sistemi</h3>' +
    '<p class="text-xs text-muted" style="margin-bottom:8px;">Bronz → Gümüş → Altın → Elmas. Her seviye yeni bir unvan getirir.</p>' + rows + "</div>";
}

// ===== KONFETİ =====
function fireConfetti() {
  const colors = ["#2563EB", "#3B82F6", "#10B981", "#F59E0B", "#6366F1", "#EF4444"];
  const n = 36;
  for (let i = 0; i < n; i++) {
    const el = document.createElement("div");
    el.style.cssText = "position:fixed;z-index:120;top:-12px;left:" + (Math.random() * 100) + "vw;width:9px;height:14px;background:" +
      colors[i % colors.length] + ";border-radius:3px;pointer-events:none;transition:transform 1.6s cubic-bezier(0.3,0.8,0.4,1),opacity 1.6s;";
    document.body.appendChild(el);
    requestAnimationFrame(() => {
      el.style.transform = "translateY(" + (window.innerHeight + 40) + "px) rotate(" + (Math.random() * 720 - 360) + "deg)";
      el.style.opacity = "0";
    });
    setTimeout(() => el.remove(), 1800);
  }
}
