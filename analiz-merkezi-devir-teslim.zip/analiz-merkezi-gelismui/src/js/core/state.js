// ============================================================
// ANALİZ MERKEZİ v5.1 — DURUM YÖNETİMİ (modül: core/state.js)
// Mock/örnek veri YOKTUR: tüm listeler boş başlar.
// ============================================================

const STORAGE_KEY = "analizmerkezi_v6";
const LEGACY_KEY = "analizmerkezi_v5";

let state = freshState();

function freshState() {
  return {
    user: { name: "", grade: "9", joined: null },
    streak: { count: 0, lastCheck: null, freezeWeek: null, freezeUsed: false },
    exams: [],        // {id, name, date, lessons:{Ders:{d,w,e}}, errorLogs:[{qno,lesson,topic,type}], total, net}
    questions: [],    // {id, lesson, date, total, d, w, e, errorLogs:[{qno,lesson,topic,type}]}
    books: [],        // {id, title, author, pages, read, done, history:[{date,pages,minutes}]}
    topics: {},       // "Ders > Konu" -> {step:0-4, completedAt, preTest}
    memory: {},       // "Ders > Konu" -> {lastReview, reviewCount, completedAt, schedule:{3:date,...}}
    notifications: [],// {id, title, body, date, read, kind, topicKey}
    badges: {},       // metricKey -> tier index (0-3)
    plan: { targetDate: null, examTime: "", schoolExams: [], targetNet: 0, dailyHours: 0, dailyReading: 0, readingMinutes: 0, rhythm: "Sabah" },
    settings: { notifPermission: "default", lastCoachDay: null, greetedToday: null },
    dailyTasks: { study: false, read: false, solve: false, date: null }
  };
}

function loadState() {
  try {
    let saved = localStorage.getItem(STORAGE_KEY);
    if (!saved) saved = localStorage.getItem(LEGACY_KEY); // v5 verisini taşı
    if (saved) {
      const parsed = JSON.parse(saved);
      state = mergeDeep(freshState(), parsed);
    }
  } catch (e) { console.warn("Veri okunamadı, temiz başlanıyor.", e); }
}

function mergeDeep(base, extra) {
  const out = Array.isArray(base) ? [] : {};
  Object.keys(base).forEach(k => { out[k] = base[k]; });
  Object.keys(extra || {}).forEach(k => {
    if (extra[k] && typeof extra[k] === "object" && !Array.isArray(extra[k]) && base[k] && typeof base[k] === "object" && !Array.isArray(base[k]))
      out[k] = mergeDeep(base[k], extra[k]);
    else out[k] = extra[k];
  });
  return out;
}

function saveState() {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }
  catch (e) { toast("Veri kaydedilemedi: depolama dolu olabilir.", "error"); }
}

function confirmReset(type) {
  const messages = {
    exams: "Tüm denemeler ve hata kayıtları silinecek. Emin misin?",
    questions: "Soru Bankası'ndaki tüm çözümler silinecek. Emin misin?",
    books: "Kitaplığın tamamı silinecek. Emin misin?",
    all: "TÜM VERİLER (denemeler, sorular, kitaplar, hafıza, bildirimler, rozetler) kalıcı olarak sıfırlanacak. Emin misin?"
  };
  openConfirm(messages[type] || " Emin misin?", () => executeReset(type));
}

function executeReset(type) {
  if (type === "exams") state.exams = [];
  else if (type === "questions") state.questions = [];
  else if (type === "books") state.books = [];
  else if (type === "all") {
    const user = state.user;
    state = freshState(); state.user = user;
    localStorage.removeItem(LEGACY_KEY);
  }
  saveState(); closeConfirm();
  toast("İşlem tamamlandı.", "success");
  navigate(currentPage);
}

function exportData() {
  const blob = new Blob([JSON.stringify(state, null, 2)], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "analiz-merkezi-yedek-" + todayStr() + ".json";
  a.click(); URL.revokeObjectURL(a.href);
  toast("Yedek dosyası indirildi.", "success");
}

function importData(input) {
  const file = input.files && input.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const parsed = JSON.parse(reader.result);
      // İki format desteklenir: doğrudan state (Dışa Aktar çıktısı) VEYA { _okumaNotu, state } sarmalayıcısı (mock/veri dosyaları)
      const data = parsed && typeof parsed === "object"
        ? (parsed.user ? parsed : (parsed.state && parsed.state.user ? parsed.state : null))
        : null;
      if (!data) throw new Error("geçersiz");
      state = mergeDeep(freshState(), data);
      saveState(); updateUserUI(); navigate(currentPage);
      toast("Veriler içe aktarıldı.", "success");
    } catch (e) { toast("Dosya okunamadı: geçerli bir yedek değil.", "error"); }
    input.value = "";
  };
  reader.readAsText(file);
}
