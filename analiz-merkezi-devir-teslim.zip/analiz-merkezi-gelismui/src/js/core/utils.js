// ============================================================
// ANALİZ MERKEZİ v5.1 — YARDIMCILAR (modül: core/utils.js)
// Teknik Zırlama: tüm tarih hesapları setHours(0,0,0,0) ile milimetrik hassas
// ============================================================

function todayStr() {
  const d = new Date(); d.setHours(0, 0, 0, 0);
  const p = n => String(n).padStart(2, "0");
  return d.getFullYear() + "-" + p(d.getMonth() + 1) + "-" + p(d.getDate());
}

function parseDay(str) {
  if (!str) return null;
  const d = new Date(str); d.setHours(0, 0, 0, 0);
  return isNaN(d.getTime()) ? null : d;
}

function daysBetween(a, b) {
  return Math.round((b - a) / 86400000);
}

function daysSince(dateStr) {
  const d = parseDay(dateStr); if (!d) return 0;
  return Math.max(0, Math.floor((new Date() - d) / 86400000)); // kısmi gün sayılmaz
}

function fmtDate(str) {
  const d = parseDay(str); if (!d) return "-";
  return String(d.getDate()).padStart(2, "0") + "." + String(d.getMonth() + 1).padStart(2, "0") + "." + d.getFullYear();
}

function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }

// HTML kaçışları — olay delegasyonu ile data-* öznitelikleri güvenli olur
function esc(s) {
  return String(s == null ? "" : s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}
function attr(s) { return esc(s); }

// attribute-selector için güvenli kaçış (CSS.escape yerine — her ortamda çalışır)
function sel(v) {
  return String(v).replace(/(["\\\\])/g, "\\$1");
}

function netOf(d, w) { return (Number(d) || 0) - (Number(w) || 0) / NET_RULE.wrongDivisor; }

const APRX = "'";

// Aktif temanın CSS değişkenini oku (grafikler koyu/açık temaya uyar)
function cssVar(name, fallback) {
  try {
    const v = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
    return v || fallback;
  } catch (e) { return fallback; }
} // okunabilirlik: ek içeren adlarda güvenli kesme işareti

function icon(name, size, style) {
  size = size || 16;
  return '<i data-lucide="' + name + '" style="width:' + size + 'px;height:' + size + 'px;' + (style || "") + '"></i>';
}

function memoryColor(pct) {
  if (pct < MEMORY_CRITICAL) return "var(--semantic-error)";
  if (pct < MEMORY_WARNING) return "var(--semantic-warning)";
  if (pct < 75) return "var(--semantic-warning)";
  return "var(--semantic-success)";
}

function pctBarColor(pct) {
  if (pct >= 75) return "var(--semantic-success)";
  if (pct >= 50) return "var(--semantic-warning)";
  return "var(--semantic-error)";
}

// Belirli bir dersin müfredat konularını döndürür
function topicsOfLesson(lesson) {
  const g = state.user.grade || "9";
  const tree = CURRICULUM[g] || {};
  return tree[lesson] || [];
}

// "Ders > Konu" anahtarından parçalar
function splitKey(key) {
  const i = key.indexOf(" > ");
  if (i < 0) return { lesson: "", topic: key };
  return { lesson: key.slice(0, i), topic: key.slice(i + 3) };
}
