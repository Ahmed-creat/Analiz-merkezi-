// ============================================================
// ANALİZ MERKEZİ v5.1 — ANALİTİK MOTOR (modül: core/engine-analytics.js)
// Net istatistikleri, Haftalık İvme, okuma analizi, koç mesajları
// ============================================================

function examStats() {
  const exams = state.exams;
  if (!exams.length) return { count: 0, avg: 0, best: 0, last: 0, series: [] };
  const nets = exams.map(e => e.net || 0);
  const series = exams.slice().sort((a, b) => (parseDay(a.date) || 0) - (parseDay(b.date) || 0)).map(e => ({ name: e.name, net: e.net || 0, date: e.date }));
  return {
    count: exams.length,
    avg: Math.round((nets.reduce((s, n) => s + n, 0) / nets.length) * 100) / 100,
    best: Math.max.apply(null, nets),
    last: nets[nets.length - 1],
    series
  };
}

// Haftalık İvme Hedefi (Momentum): (HedefNet - MevcutOrt) / SınavaKalanHafta
function weeklyMomentum() {
  const st = examStats();
  if (!state.plan.targetDate || !state.plan.targetNet || st.count === 0) return null;
  const dl = daysLeftToExam();
  if (dl === null) return null;
  const weeks = Math.max(1, dl / 7);
  return {
    weekly: Math.round(((state.plan.targetNet - st.avg) / weeks) * 100) / 100,
    current: st.avg, target: state.plan.targetNet, weeks: Math.ceil(weeks), daysLeft: dl
  };
}

// Toplam çözülen soru (rozet metriği)
function totalSolved() {
  let n = 0;
  state.exams.forEach(e => { n += e.total || 0; });
  state.questions.forEach(q => { n += q.total || 0; });
  return n;
}

// Okuma istatistikleri (Modül C): disiplin, hız, toplam dakika
function readingStats() {
  let minutes = 0, pages = 0, activeDays = new Set();
  state.books.forEach(b => (b.history || []).forEach(h => {
    minutes += Number(h.minutes) || 0;
    pages += Number(h.pages) || 0;
    if (h.pages > 0) activeDays.add(h.date);
  }));
  const doneCount = state.books.filter(b => b.done).length;
  return {
    minutes, pages, activeDays: activeDays.size, doneCount,
    speed: minutes > 0 && pages > 0 ? Math.round((pages / (minutes / 60)) * 10) / 10 : null,
    discipline: state.books.length ? Math.round((activeDays.size / Math.max(1, daysSince(state.user.joined) || 1)) * 100) : 0
  };
}

// Bilişsel Kondisyon Eğilimi: N>=5 deneme olmadan korelasyon üretilmez (spec)
function cognitiveTrend() {
  const exams = state.exams.slice().sort((a, b) => (parseDay(a.date) || 0) - (parseDay(b.date) || 0));
  if (exams.length < COGNITIVE_CORR_MIN_EXAMS) return { ready: false, n: exams.length };
  const half = Math.floor(exams.length / 2);
  const firstAvg = avg(exams.slice(0, half).map(e => e.net || 0));
  const lastAvg = avg(exams.slice(half).map(e => e.net || 0));
  const readingUp = readingStats().pages > 0;
  return {
    ready: true, n: exams.length,
    trend: Math.round((lastAvg - firstAvg) * 100) / 100,
    firstAvg: Math.round(firstAvg * 100) / 100, lastAvg: Math.round(lastAvg * 100) / 100,
    readingUp,
    message: readingUp && lastAvg > firstAvg
      ? "Okuma disiplinin artarken net ortalaman yükselişe geçti: Bilişsel Kondisyon Eğilimi POZİTİF."
      : "Net ortalaman " + (lastAvg >= firstAvg ? "yatay/seferde" : "düşüşte") + ". Günlük okuma ritmini koru; SKYA hataları izleniyor."
  };
}
function avg(arr) { return arr.length ? arr.reduce((s, v) => s + v, 0) / arr.length : 0; }

// Altın Saat: öncelik sıralamasının tepesindeki konular -> seçilen verimli dilime atanır
function goldenHourTopics(limit) {
  const pr = calculatePriority().slice(0, limit || 5);
  const rhythm = RHYTHMS.find(r => r.key === state.plan.rhythm) || RHYTHMS[0];
  return pr.map(p => ({ key: p[0], score: p[1], stats: p[2], window: rhythm }));
}

// Koçluk Hattı mesajları (dinamik analiz)
function coachMessages() {
  const msgs = [];
  const st = examStats();
  const rs = readingStats();
  if (state.user.name) {
    const r = RHYTHMS.find(x => x.key === state.plan.rhythm);
    msgs.push("<b>" + (r ? r.coach : "Merhaba") + ", " + esc(state.user.name) + "!</b> Sistem mesajları hazır.");
  }
  if (st.count >= 3) {
    const last3 = state.exams.slice(-3).map(e => e.net || 0);
    const trend = last3[last3.length - 1] - last3[0];
    const mathNets = state.exams.slice(-3).map(e => e.lessons && e.lessons["Matematik"] ? netOf(e.lessons["Matematik"].d, e.lessons["Matematik"].w) : null).filter(v => v !== null);
    if (mathNets.length === 3) {
      const mAvg = Math.round(avg(mathNets) * 100) / 100;
      msgs.push("Son 3 denemede Matematik netlerin <b>" + mAvg + "</b> seviyesinde. " + (mAvg >= 10 ? "Gümüş seviyeye yükseldin, böyle devam!" : "Temel eksikleri Modül B'den önceliklendiriyorum."));
    }
    msgs.push("Net eğilimin: <b>" + (trend >= 0 ? "+" : "") + Math.round(trend * 100) / 100 + "</b> puán. " + (trend >= 0 ? "İvme pozitif." : "Küçük bir tekrar planı gerekiyor."));
  } else if (st.count > 0) {
    msgs.push("En az 3 deneme girince trend analizini açarım. Şu an " + st.count + " kayıt var.");
  }
  const skya = skyaRate();
  if (skya > 30) msgs.push("SKYA oranın <b>%" + Math.round(skya) + "</b>. Süre yönetimi için kitap okumayı arttır ve zamanlı test çöz (Kitaplık önerisine bak).");
  const ms = memoryStats();
  if (ms.critical > 0) msgs.push("<b>" + ms.critical + " konu</b> kritik hafıza eşiğinin (%20) altında. ACİL TEKRAR butonları Konu Takibi'nde seni bekliyor.");
  if (rs.pages === 0 && daysSince(state.user.joined) > 3) msgs.push("Kitap okumadığın için %100 odak potansiyeline ulaşamıyorsun. Günde 15 dakikayla başla.");
  const dl = daysLeftToExam();
  if (dl !== null) {
    const mom = weeklyMomentum();
    msgs.push("Sınava <b>" + dl + " gün</b> kaldı." + (mom ? " Haftalık ivme hedefi: <b>+" + mom.weekly + "</b> net." : ""));
  }
  return msgs.slice(0, 5);
}
