// ============================================================
// ANALİZ MERKEZİ v5.1 — HAFIZA MOTORU (modül: core/engine-memory.js)
// Ebbinghaus unutma eğrisi + Bilimsel İvme + sınava oranlı dinamik tekrar
// ============================================================

// Günlük unutma hızı: her başarılı tekrarda %10 yavaşlar (kalıcı hafıza simülasyonu)
function memoryDecayRate(mem) {
  const n = (mem && mem.reviewCount) || 0;
  return Math.max(MEMORY_DECAY_FLOOR, MEMORY_BASE_DECAY * Math.pow(MEMORY_DECAY_SLOWDOWN, n));
}

// Hafıza gücü %0-100 (üstel sönüm; deterministik, günlük yazım gerektirmez)
function getMemoryStrength(topicKey) {
  const mem = state.memory[topicKey];
  if (!mem || !mem.lastReview) return 0;
  const d = daysSince(mem.lastReview);
  return clamp(Math.round(100 * Math.exp(-memoryDecayRate(mem) * d)), 0, 100);
}

// Sınava kalan gün
function daysLeftToExam() {
  if (!state.plan.targetDate) return null;
  const target = parseDay(state.plan.targetDate);
  if (!target) return null;
  return Math.max(0, daysBetween(new Date(), target));
}

// Cepeda vd. (2008) %10-20 kuralı: İdeal aralık = max(1, round(KalanGün × 0.15))
function idealReviewInterval() {
  const dl = daysLeftToExam();
  if (dl === null) return null;
  return Math.max(1, Math.round(dl * 0.15));
}

// Kalan süreye göre çalışma rejimi (4 kademe tablo)
function currentRegime() {
  const dl = daysLeftToExam();
  if (dl === null) return null;
  return EXAM_REGIMES.find(r => dl <= r.maxDays) || EXAM_REGIMES[EXAM_REGIMES.length - 1];
}

// Konu tamamlandığında 3-7-14-21-28 gün sonrası için hatırlatıcı kur
function scheduleReviews(topicKey) {
  const mem = state.memory[topicKey];
  if (!mem) return;
  const base = new Date(); base.setHours(0, 0, 0, 0);
  const dl = daysLeftToExam();
  const iv = idealReviewInterval();
  mem.schedule = {};
  REVIEW_DAYS.forEach(day => {
    // Sınav yakınsa Cepeda oranıyla aralıklar otomatik sıklaşır
    let effDay = day;
    if (dl !== null && iv !== null && day > iv * 2) effDay = Math.max(1, Math.round(day * (iv / 14)));
    const dt = new Date(base); dt.setDate(dt.getDate() + effDay);
    mem.schedule[day] = toDayStr(dt);
  });
  saveState();
}

function toDayStr(d) {
  const p = n => String(n).padStart(2, "0");
  return d.getFullYear() + "-" + p(d.getMonth() + 1) + "-" + p(d.getDate());
}

// Bir konunun sıradaki tekrar bilgisi
function nextReviewInfo(topicKey) {
  const mem = state.memory[topicKey];
  if (!mem || !mem.schedule) return null;
  const today = parseDay(todayStr());
  const entries = Object.entries(mem.schedule)
    .map(([day, date]) => ({ day: Number(day), date, dt: parseDay(date) }))
    .filter(e => e.dt && e.dt >= today)
    .sort((a, b) => a.dt - b.dt);
  return entries[0] || null;
}

// Zamanı gelmiş tekrarlar (bugün dahil)
function dueReviews() {
  const today = parseDay(todayStr());
  const list = [];
  Object.keys(state.memory).forEach(key => {
    const mem = state.memory[key];
    if (!mem || !mem.schedule) return;
    Object.entries(mem.schedule).forEach(([day, date]) => {
      const dt = parseDay(date);
      if (dt && dt <= today) list.push({ topicKey: key, day: Number(day), date });
    });
  });
  return list;
}

// Tekrar Ettim -> bar %100, ivme yavaşlar, sonraki periyot Cepeda oranına göre yeniden kurulur
function markReviewed(topicKey, early) {
  const mem = state.memory[topicKey];
  if (!mem) return;
  mem.lastReview = new Date().toISOString();
  mem.reviewCount = (mem.reviewCount || 0) + 1;
  // Yeniden program: temel döngü + sınav yakınsa sıklaştırılmış
  scheduleReviews(topicKey);
  saveState();
  evaluateBadges();
  addNotification({
    title: early ? "Erken Tekrar Kaydedildi" : "Tekrar Tamamlandı",
    body: splitKey(topicKey).topic + " hafıza barı %100'e yükseldi. Unutma hızın %" +
          Math.round((1 - memoryDecayRate(mem) / MEMORY_BASE_DECAY) * 100) + " yavaşladı.",
    kind: "review", topicKey
  });
}

// Konuyu sıfırla (Anlamadım, Baştan Başla)
function resetTopicMemory(topicKey) {
  state.memory[topicKey] = { lastReview: null, reviewCount: 0, completedAt: null, schedule: {} };
  state.topics[topicKey] = { step: 0, completedAt: null, preTest: false };
  saveState();
}

// Hafıza istatistikleri (Modül B / Ana Sayfa)
function memoryStats() {
  const keys = Object.keys(state.memory).filter(k => state.memory[k].completedAt);
  let sum = 0, waiting = 0, critical = 0;
  const rows = keys.map(key => {
    const pct = getMemoryStrength(key);
    const nr = nextReviewInfo(key);
    const due = dueReviews().some(r => r.topicKey === key);
    if (due) waiting++;
    if (pct < MEMORY_CRITICAL) critical++;
    sum += pct;
    return { key, lesson: splitKey(key).lesson, topic: splitKey(key).topic, pct, reviews: state.memory[key].reviewCount || 0, due, next: nr };
  }).sort((a, b) => a.pct - b.pct);
  return {
    rows, waiting, critical,
    completed: keys.length,
    avg: keys.length ? Math.round(sum / keys.length) : 0
  };
}
