// ============================================================
// ANALİZ MERKEZİ v5.1 — ÖNCELİK VE ANALİTİK MOTOR (modül: core/engine-priority.js)
// Laplace düzeltmeli Priorite formülü + zorluk önerisi + kök eksik tespiti
// ============================================================

function getAllTopicKeys() {
  const keys = [];
  const tree = CURRICULUM[state.user.grade || "9"] || {};
  Object.keys(tree).forEach(lesson => tree[lesson].forEach(topic => keys.push(lesson + " > " + topic)));
  return keys;
}

// Hata kayıtlarını konu bazında toplar (denemeler 1.5x, test 1.0x ağırlıklı)
// Kural (master metin): "Konuyu öğrendim" işaretlenen konu Priorite Listesi'nden DÜŞER;
// yalnızca tamamlama tarihinden SONRA yapılan yeni hatalar konuyu geri getirir.
function topicLearnedAfter(key, logDate) {
  const mem = state.memory[key];
  if (!mem || !mem.completedAt) return false;
  const done = parseDay(mem.completedAt.split("T")[0]);
  const ld = logDate ? parseDay(logDate) : null;
  // Konu "öğrenildi" kabul edilir ve tamamlama gününden ÖNCEKİ hatalar listeden düşer.
  // Tamamlama günü ve sonrasındaki yeni hatalar konuyu listeye GERİ GETİRİR.
  return !ld ? true : ld < done;
}

function collectErrorStats() {
  const stats = {};
  const push = (log, sourceWeight) => {
    if (!log || !log.topic || !log.lesson) return;
    const key = log.lesson + " > " + log.topic;
    if (topicLearnedAfter(key, log.date)) return; // öğrenilen konunun eski hataları listelenmez
    if (!stats[key]) stats[key] = { lesson: log.lesson, topic: log.topic, count: 0, kae: 0, anlamadim: 0, reasons: {}, sources: { exam: 0, test: 0 } };
    const s = stats[key];
    const w = REASON_WEIGHTS[log.type] != null ? REASON_WEIGHTS[log.type] : 0.5;
    s.count++;
    if (log.type === "Konuyu Bilmiyordum" || log.type === "KONU EKSİKLİĞİ") s.kae++;
    if (log.type === "ANLAMADIM") s.anlamadim++;
    s.reasons[log.type] = (s.reasons[log.type] || 0) + 1;
    if (sourceWeight === 1.5) s.sources.exam++; else s.sources.test++;
    s.weighted = (s.weighted || 0) + w * sourceWeight;
  };
  state.exams.forEach(ex => (ex.errorLogs || []).forEach(l => push(l, 1.5)));
  state.questions.forEach(q => (q.errorLogs || []).forEach(l => push(l, 1.0)));
  return stats;
}

// Laplace düzeltmeli priorite: [1.5·Deneme + 1.0·Test + 0.5·(İşlem+Anlama)] × (1 + AYT)
// AYT ağırlığı ÖSYM puan türü tablosundan: kullanıcının alanına (SAY/EA/SÖZ) göre
// o dersin puana etkisi (AYT_WEIGHTS — constants.js)
function calculatePriority() {
  const stats = collectErrorStats();
  const result = [];
  Object.entries(stats).forEach(([key, s]) => {
    const laplace = s.kae / (s.count + 1); // Laplace düzeltmesi
    const score = (s.weighted || 0) * (1 + laplace) * (1 + aytWeightOf(s.lesson));
    if (score > 0) result.push([key, Math.round(score * 10) / 10, s]);
  });
  return result.sort((a, b) => b[1] - a[1]);
}

// Konu başarı yüzdesi: (Toplam Doğru / Toplam Soru) × 100 — son kayıtlardan
function topicSuccessRate(topicKey) {
  const p = splitKey(topicKey);
  let d = 0, total = 0;
  state.exams.forEach(ex => {
    const l = ex.lessons && ex.lessons[p.lesson];
    if (l) { d += Number(l.d) || 0; total += (Number(l.d) || 0) + (Number(l.w) || 0) + (Number(l.e) || 0); }
  });
  state.questions.forEach(q => {
    const hit = (q.errorLogs || []).some(e => e.topic === p.topic && e.lesson === p.lesson);
    if (q.lesson === p.lesson || hit) {
      d += Number(q.d) || 0;
      total += (Number(q.d) || 0) + (Number(q.w) || 0) + (Number(q.e) || 0);
    }
  });
  return total > 0 ? Math.round((d / total) * 100) : null;
}

// Zorluk derecesi önerisi (Modül F): ≤40 TEMEL, ≤75 ORTA, >75 ZOR/YENİ NESİL
function difficultyFor(topicKey) {
  const rate = topicSuccessRate(topicKey);
  if (rate === null) return { level: "TEMEL", color: "var(--semantic-success)", rate };
  if (rate <= 40) return { level: "TEMEL", color: "var(--semantic-success)", rate };
  if (rate <= 75) return { level: "ORTA", color: "var(--semantic-warning)", rate };
  return { level: "ZOR / YENİ NESİL", color: "var(--semantic-error)", rate };
}

// Ders başarı oranları (Deneme + Soru Bankası birleşik)
function getLessonSuccessRates() {
  const rates = {};
  Object.keys(LESSON_CONFIG).forEach(lesson => {
    let d = 0, w = 0, e = 0;
    state.exams.forEach(ex => { const l = ex.lessons && ex.lessons[lesson]; if (l) { d += Number(l.d) || 0; w += Number(l.w) || 0; e += Number(l.e) || 0; } });
    state.questions.forEach(q => { if (q.lesson === lesson) { d += Number(q.d) || 0; w += Number(q.w) || 0; e += Number(q.e) || 0; } });
    const total = d + w + e;
    rates[lesson] = total > 0 ? { pct: Math.round((d / total) * 100), d, w, e, total } : null;
  });
  return rates;
}

// ANLAMADIM oranı (%) — bilişsel odak analizi (ders-geneli hızlı tip + detaylı satırlar dahil)
function calculateAnlamadimRate() {
  let total = 0, anlama = 0;
  const tally = (type) => {
    if (!type) return;
    total++;
    if (type === "ANLAMADIM") anlama++;
  };
  state.exams.forEach(ex => (ex.errorLogs || []).forEach(x => tally(x.type)));
  state.questions.forEach(q => (q.errorLogs || []).forEach(x => tally(x.type)));
  return total > 0 ? (anlama / total) * 100 : 0;
}

// Unutma İndeksi: başarı >%80 iken 20+ gündür dokunulmayan konular (Modül B)
function forgettingIndexList() {
  const list = [];
  Object.keys(state.memory).forEach(key => {
    const mem = state.memory[key];
    if (!mem || !mem.completedAt) return;
    const rate = topicSuccessRate(key);
    const idle = mem.lastReview ? daysSince(mem.lastReview) : daysSince(mem.completedAt);
    if (rate !== null && rate > 80 && idle >= 20) list.push({ key, idle, rate });
  });
  return list;
}

// Çapraz ilişkilendirme -> Kök Eksik Uyarısı (fark > %30)
function rootDeficitList() {
  const rates = {};
  getAllTopicKeys().forEach(key => { const r = topicSuccessRate(key); if (r !== null) rates[key] = r; });
  const out = [];
  CROSS_LINKS.forEach(link => {
    const aKeys = Object.keys(rates).filter(k => k.startsWith(link.a.lesson + " > ") && k.includes(link.a.match));
    const bKeys = Object.keys(rates).filter(k => k.startsWith(link.b.lesson + " > ") && k.includes(link.b.match));
    aKeys.forEach(ak => bKeys.forEach(bk => {
      const diff = rates[ak] - rates[bk];
      if (Math.abs(diff) > 30) {
        const weak = diff > 0 ? bk : ak;
        const strong = diff > 0 ? ak : bk;
        out.push({ weak, strong, diff: Math.round(Math.abs(diff)), root: link.root });
      }
    }));
  });
  return out;
}

// Hata Tipi Dağılımı (Modül A çıktısı): KAE / İH / SKYA / KH yüzdesel dağılım
function errorTypeDistribution() {
  const counts = {};
  let total = 0;
  const tally = (type) => {
    if (!type) return;
    const g = REASON_GROUP[type] || "İH";
    counts[g] = (counts[g] || 0) + 1;
    total++;
  };
  state.exams.forEach(ex => (ex.errorLogs || []).forEach(x => tally(x.type)));
  state.questions.forEach(q => (q.errorLogs || []).forEach(x => tally(x.type)));
  return Object.keys(GROUP_META).map(g => ({
    group: g, meta: GROUP_META[g],
    count: counts[g] || 0,
    pct: total ? Math.round(((counts[g] || 0) / total) * 100) : 0
  }));
}

// SKYA oranı (%) — "SKYA fazlaysa kitap okumayı arttırması önerilir" (revize promptlar)
function skyaRate() {
  let total = 0, skya = 0;
  const t = (type) => { if (!type) return; total++; if (REASON_GROUP[type] === "SKYA") skya++; };
  state.exams.forEach(ex => (ex.errorLogs || []).forEach(x => t(x.type)));
  state.questions.forEach(q => (q.errorLogs || []).forEach(x => t(x.type)));
  return total ? (skya / total) * 100 : 0;
}
