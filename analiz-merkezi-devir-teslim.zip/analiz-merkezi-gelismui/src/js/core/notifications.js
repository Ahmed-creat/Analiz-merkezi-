// ============================================================
// ANALİZ MERKEZİ v5.1 — BİLDİRİM MOTORU (modül: core/notifications.js)
// Tekrar bildirimleri + kritik hafıza alarmı + günlük koç mesajları
// Not: Uygulama kapalıyken OS seviyesi push için FCM/OneSignal + barındırma
// gerekir (plan.pdf FAZ 4). Bu motor uygulama açıkken ve açılışta çalışır.
// ============================================================

function addNotification(n) {
  // Aynı bildirimi tekrar üretme
  const dup = state.notifications.some(x => x.kind === n.kind && x.topicKey === n.topicKey && x.body === n.body);
  if (dup) return;
  state.notifications.unshift({
    id: uid(), title: n.title, body: n.body, kind: n.kind || "info",
    topicKey: n.topicKey || null, date: new Date().toISOString(), read: false
  });
  if (state.notifications.length > 200) state.notifications.length = 200;
  saveState();
  updateBellBadges();
}

function unreadCount() { return state.notifications.filter(n => !n.read).length; }

function updateBellBadges() {
  const c = unreadCount();
  ["bell-badge-top", "bell-badge-side"].forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;
    el.textContent = c > 99 ? "99+" : c;
    el.classList.toggle("hidden", c === 0);
  });
}

function renderNotifList() {
  const box = document.getElementById("notif-list");
  if (!box) return;
  if (!state.notifications.length) {
    box.innerHTML = '<div class="empty-state">' + icon("bell-off", 34) + '<div>Bildirim yok. Konu tamamladıkça tekrar hatırlatmaları buraya düşer.</div></div>';
    return;
  }
  const icons = { review: "refresh-cw", critical: "alert-triangle", coach: "message-circle", badge: "award", memory: "brain", exam: "calendar-clock", prep: "shield-check", daily: "calendar-check", info: "info" };
  box.innerHTML = state.notifications.map(n =>
    '<div class="notif-card ' + (n.read ? "" : "unread") + " " + (n.kind === "critical" ? "critical" : "") + '" data-id="' + n.id + '">' +
      icon(icons[n.kind] || "info", 16, "flex-shrink:0;") +
      '<div style="min-width:0;flex:1;"><div style="font-weight:600;font-size:13px;">' + esc(n.title) + '</div>' +
      '<div style="font-size:12px;color:var(--text-muted);">' + esc(n.body) + '</div>' +
      '<div class="text-xs text-muted tabular" style="margin-top:3px;">' + fmtDate(n.date) + '</div></div>' +
      (n.read ? "" : '<span class="badge badge-info">YENİ</span>') +
    '</div>'
  ).join("");
}

// Uygulama açılışında ve dakikalık tiktte: zamanı gelen bildirimleri üret
function processDueNotifications() {
  const today = todayStr();
  const greeted = state.settings.greetedToday === today;
  const hour = new Date().getHours();
  const rhythm = RHYTHMS.find(r => r.key === state.plan.rhythm) || RHYTHMS[0];

  // 1) Günlük koç selamı (kullanıcının ritim penceresine göre; sabit saat zorlanmaz)
  if (!greeted) {
    const inWindow =
      (rhythm.key === "Sabah" && hour >= 5 && hour < 12) ||
      (rhythm.key === "Öğle" && hour >= 12 && hour < 17) ||
      (rhythm.key === "Akşam" && (hour >= 17 || hour < 2));
    if (inWindow || hour >= 20) {
      const dl = daysLeftToExam();
      addNotification({
        title: rhythm.coach + (state.user.name ? ", " + state.user.name : "") + "!",
        body: dl !== null ? "Sınava " + dl + " gün kaldı. Hazırsan bugünün öncelikli görevine başlayalım!" : "Bugünün öncelikli görevine hazırsan başlayalım!",
        kind: "coach"
      });
      state.settings.greetedToday = today; saveState();
    }
  }

  // 2) Sistematik tekrar hatırlatıcıları (3-7-14-21-28. gün)
  dueReviews().forEach(r => {
    addNotification({
      title: "Tekrar Zamanı Geldi!",
      body: splitKey(r.topicKey).topic + " — " + r.day + ". gün tekrarı bugün. 10 dakikalık müdahale yeter.",
      kind: "review", topicKey: r.topicKey + "@" + r.day
    });
  });

  // 3) Kritik hafıza alarmı (< %20): anlık dürtme
  memoryStats().rows.forEach(r => {
    if (r.pct < MEMORY_CRITICAL) {
      addNotification({
        title: "ACİL: " + r.topic + " unutulmak üzere!",
        body: "Hafıza gücü %" + r.pct + "'e düştü. 10 dakikalık acil müdahale tekrarı yap!",
        kind: "critical", topicKey: r.key + "@critical"
      });
      notifyBrowser("Analiz Merkezi: " + r.topic + " unutulmak üzere!", "Hafıza gücü %" + r.pct + " — 10 dk acil tekrar yap.");
    }
  });

  // 4) Unutma İndeksi bildirimi (başarı >%80 + 20 gün temasa yok)
  forgettingIndexList().forEach(f => {
    addNotification({
      title: "Unutma İndeksi Yükseldi",
      body: splitKey(f.key).topic + " başarı yüzdesin yüksekti ama " + f.idle + " gündür dokunmadın. Tekrar et.",
      kind: "memory", topicKey: f.key + "@forget"
    });
  });

  // 5) TAKVİM BİLDİRİMLERİ: sınav geri sayımı + sınava hazırlık tekrarları
  const dl2 = daysLeftToExam();
  if (dl2 !== null && state.plan.targetDate) {
    // Geri sayım kilometre taşları (30 / 7 / 1 gün)
    if (dl2 === 30) {
      addNotification({
        title: "Sınava 30 Gün Kaldı",
        body: "Son 1 ay — takvimde sınava hazırlık tekrar günleri (1 hafta / 3 gün / 1 gün önce) otomatik işaretlendi.",
        kind: "exam", topicKey: "exam@30"
      });
      notifyBrowser("Analiz Merkezi: Sınava 30 gün", "Son ay planı hazırlanıyor — hazırlık tekrarlarını takvime işledik.");
    }
    if (dl2 === 7) {
      addNotification({
        title: "Sınava 1 Hafta!",
        body: "Bu hafta genel tekrar haftası: eksik konuları kapat, yeni konu açma.",
        kind: "exam", topicKey: "exam@7"
      });
      notifyBrowser("Analiz Merkezi: Sınava 7 gün", "Genel tekrar haftası başladı.");
    }
    if (dl2 === 1) {
      addNotification({
        title: "YARIN SINAV!",
        body: "Bugün sadece formül hatırlama + yanlış soru defteri. Erken uyu, iyi şanslar!",
        kind: "critical", topicKey: "exam@1"
      });
      notifyBrowser("Analiz Merkezi: Yarın sınav!", "Bugün hafif tut — formüller ve yanlış defteri.");
    }
    // Sınava hazırlık tekrarı günleri (sınav − 7 / − 3 / − 1)
    const kapsamN = (state.plan.examTopics || []).length;
    const preps = [
      { gun: 7, ad: "Genel tekrar haftası", not: "Sınava 1 hafta kaldı" + (kapsamN ? " — sınav kapsamındaki " + kapsamN + " konuyu hızlı tur ile tarama" : "") + ". Konu başına 10 dakika ayır." },
      { gun: 3, ad: "Eksik kapatma günü", not: "Sınava 3 gün kaldı — sınav kapsamından en zayıf konularını seçip sadece eksik noktalara odaklan." },
      { gun: 1, ad: "Formül turu günü", not: "Sınav yarın! Formül kartları + yanlış soru defterindeki son hataları son kez tekrar et. Erken uyu." }
    ];
    preps.forEach(p => {
      if (dl2 === p.gun) {
        addNotification({
          title: "Sınava Hazırlık: " + p.ad + (kapsamN ? " (" + kapsamN + " konu)" : ""),
          body: p.not + " Ayrıntılar: Planlama → Çalışma Takvimi.",
          kind: "prep", topicKey: "prep@" + p.gun
        });
        notifyBrowser("Analiz Merkezi: " + p.ad, p.not);
      }
    });
  }

  // 6) GÜNLÜK TAKVİM ÖZETİ: "Bugün şunlar var" — takvimdeki önemli günler
  const bugun = todayStr();
  const bugunOlaylar = [];
  const dueSayi = dueReviews().length;
  if (dueSayi > 0) bugunOlaylar.push(dueSayi + " konu tekrarı");
  if (state.plan.targetDate === bugun) bugunOlaylar.push("DENEME SINAVI" + (state.plan.examTime ? " (" + state.plan.examTime + ")" : ""));
  (state.plan.schoolExams || []).forEach(se => {
    if (se.date === bugun) bugunOlaylar.push(se.lesson + " sınavı" + (se.time ? " (" + se.time + ")" : ""));
  });
  const hazirlıkBugun = [];
  if (state.plan.targetDate) {
    const dl3 = daysLeftToExam();
    if (dl3 === 7) hazirlıkBugun.push("denemeye hazırlık: genel tekrar");
    if (dl3 === 3) hazirlıkBugun.push("denemeye hazırlık: eksik kapatma");
    if (dl3 === 1) hazirlıkBugun.push("denemeye hazırlık: formül turu");
  }
  (state.plan.schoolExams || []).forEach(se => {
    const f = se.date ? Math.round((parseDay(se.date) - parseDay(bugun)) / 86400000) : null;
    (se.prepDays && se.prepDays.length ? se.prepDays : [3, 1]).forEach(g => {
      if (f === g) hazirlıkBugun.push(se.lesson + " sınavına hazırlık" + (g === 1 ? ": formül turu" : ""));
    });
  });
  if (bugunOlaylar.length || hazirlıkBugun.length) {
    const parcalar = bugunOlaylar.concat(hazirlıkBugun);
    addNotification({
      title: "Bugünün Planı",
      body: "Bugün: " + parcalar.join(" · ") + ". Ayrıntı: Planlama → Çalışma Takvimi.",
      kind: "daily", topicKey: "daily@" + bugun
    });
  }

  // 7) OKUL SINAVI hatırlatmaları: arifesi ("yarın") + günü
  (state.plan.schoolExams || []).forEach(se => {
    const f = se.date ? Math.round((parseDay(se.date) - parseDay(bugun)) / 86400000) : null;
    if (f === 1) {
      const konuSay = (se.topics || []).length;
      addNotification({
        title: "Yarın " + se.lesson + " Sınavın!",
        body: "Sınav yarın" + (se.time ? ", saat " + se.time : "") + (konuSay > 0 ? ". Bu akşam şurada çalış: " + konuSay + " seçili konu." : ". Konularını Planlama → Okul Sınavları'ndan seçebilirsin.") + " (Planlama → Çalışma Takvimi)",
        kind: "critical", topicKey: "schooleve@" + se.id
      });
      notifyBrowser("Analiz Merkezi: Yarın " + se.lesson + " sınavı", "Bu akşam seçili konulara son tekrar.");
    }
    if (f === 0) {
      addNotification({
        title: "BUGÜN " + se.lesson + " Sınavı",
        body: "Sınav bugün" + (se.time ? ", saat " + se.time : "") + ". Bol şans!",
        kind: "exam", topicKey: "schooltoday@" + se.id
      });
    }
  });

  updateBellBadges();
}

// Tarayıcı bildirimi (uygulama açıkken; izin verilirse)
function notifyBrowser(title, body) {
  try {
    if (typeof Notification !== "undefined" && Notification.permission === "granted") {
      new Notification(title, { body: body, icon: undefined });
    }
  } catch (e) { /* file:// veya izin yoksa sessizce atla */ }
}

function requestNotifPermission() {
  if (typeof Notification === "undefined") { toast("Bu tarayıcı bildirimleri desteklemiyor.", "warning"); return; }
  Notification.requestPermission().then(p => {
    state.settings.notifPermission = p; saveState();
    updateNotifPermLabel();
    toast(p === "granted" ? "Bildirim izni verildi. Tekrar saatlerinde haber vereceğim." : "Bildirim izni verilmedi; uygulama içi bildirimler devam edecek.", p === "granted" ? "success" : "warning");
    if (p === "granted") notifyBrowser("Analiz Merkezi", "Bildirimler açıldı. Tekrar döngün artık takipte!");
  });
}

function updateNotifPermLabel() {
  const el = document.getElementById("notif-perm-label");
  if (!el) return;
  const p = (typeof Notification !== "undefined" && Notification.permission) || state.settings.notifPermission || "default";
  el.textContent = p === "granted" ? "Bildirimler Açık ✓" : "Bildirim İzni İste";
}
