// ============================================================
// ANALİZ MERKEZİ v5.1 — SABİTLER (modül: data/constants.js)
// Kaynak: revize promptlar (29 sayfa master metin) + plan.pdf
// ============================================================

// 8 TYT dersi ve maksimum soru sayıları (toplam 120) + AYT ağırlık katsayısı
const LESSON_CONFIG = {
  "Türk Dili ve Edebiyatı": { max: 30, group: "Sözel", ayt: 0.2 },
  "Matematik":             { max: 30, group: "Sayısal", ayt: 1.0 },
  "Fizik":                 { max: 10, group: "Sayısal", ayt: 0.8 },
  "Kimya":                 { max: 10, group: "Sayısal", ayt: 0.7 },
  "Biyoloji":              { max: 10, group: "Sayısal", ayt: 0.7 },
  "Tarih":                 { max: 12, group: "Sözel", ayt: 0.3 },
  "Coğrafya":              { max: 12, group: "Sözel", ayt: 0.3 },
  "Din Kültürü":           { max: 6,  group: "Sözel", ayt: 0.1 }
};

// 4 Yalın Yanlış + 3 Yalın Boş taksonomisi (v5 şartnamesi)
const WRONG_REASONS = ["Konuyu Bilmiyordum", "ANLAMADIM", "İşlem Hatası/Dikkatsizlik", "Kodlama/Kitapçık Hatası"];
const EMPTY_REASONS = ["KONU EKSİKLİĞİ", "SÜRE YETMEDİ", "ÇÖZÜM YOLUNU BULAMADIM"];

// Hata tipi -> ağırlık (Laplace düzeltmeli Priorite formülü, v5)
// Priorite = [1.5·DenemeBilgi + 1.0·TestBilgi + 0.5·(İşlem+Anlama)] × (1 + AYT Ağırlığı)
const REASON_WEIGHTS = {
  "Konuyu Bilmiyordum": 1.5,
  "KONU EKSİKLİĞİ": 1.5,
  "ANLAMADIM": 0.5,
  "İşlem Hatası/Dikkatsizlik": 0.5,
  "Kodlama/Kitapçık Hatası": 0.1,
  "SÜRE YETMEDİ": 0.3,
  "ÇÖZÜM YOLUNU BULAMADIM": 0.8
};

// Ebbinghaus sistematik tekrar döngüsü (gün)
const REVIEW_DAYS = [3, 7, 14, 21, 28];

// Temel günlük unutma oranı; her başarılı tekrarda %10 yavaşlar (Bilimsel İvme)
const MEMORY_BASE_DECAY = 0.16;
const MEMORY_DECAY_SLOWDOWN = 0.90;   // 0.9^tekrarSayisi
const MEMORY_DECAY_FLOOR = 0.03;
const MEMORY_CRITICAL = 20;           // < %20 -> ACİL müdahale bildirimi
const MEMORY_WARNING = 40;            // < %40 -> Kritik uyarı rozeti

// Sınava kalan süreye oranlı rejim tablosu (Cepeda vd. 2008, %10-20 kuralı)
const EXAM_REGIMES = [
  { maxDays: Infinity, label: "> 120 Gün (4+ Ay)",  interval: "21 - 30 günde bir", focus: "%70 Yeni Konu / %30 Tekrar",  action: "Geniş aralıklı Ebbinghaus (1, 3, 7, 14, 28 gün). Şema inşası." },
  { maxDays: 120,      label: "30 - 120 Gün (1-4 Ay)", interval: "7 - 14 günde bir", focus: "%40 Yeni / %60 Test",         action: "Sıklaştırılmış tekrar. Karıştırarak çalışma (Interleaving) + Branş denemeleri." },
  { maxDays: 30,       label: "7 - 30 Gün (Son Ay)",  interval: "3 - 6 günde bir",  focus: "%15 Yeni / %85 Pratik",      action: "Sadece kırmızı hatalara odaklan (Deliberate Practice) + Genel deneme." },
  { maxDays: 7,        label: "< 7 Gün (Son Hafta)",  interval: "1 - 2 günde bir",  focus: "%0 Yeni / %100 Hata Taraması", action: "Yeni konu kilitli. Formül hatırlama + yanlış soru defteri." }
];

// Hata Tipi Dağılımı grupları (KAE / İH / SKYA / KH) — Modül A çıktısı
const REASON_GROUP = {
  "Konuyu Bilmiyordum": "KAE",
  "KONU EKSİKLİĞİ": "KAE",
  "ANLAMADIM": "İH",
  "İşlem Hatası/Dikkatsizlik": "İH",
  "Kodlama/Kitapçık Hatası": "KH",
  "SÜRE YETMEDİ": "SKYA",
  "ÇÖZÜM YOLUNU BULAMADIM": "SKYA"
};
const GROUP_META = {
  "KAE":  { label: "KAE — Konu Bilgisi Eksiği", color: "var(--semantic-error)", bg: "var(--semantic-error-bg)" },
  "İH":   { label: "İH — İşlem/Anlama Hatası", color: "var(--semantic-warning)", bg: "var(--semantic-warning-bg)" },
  "SKYA": { label: "SKYA — Süre/Çözüm Yetersizliği", color: "var(--memory-indigo)", bg: "var(--memory-indigo-bg)" },
  "KH":   { label: "KH — Kitapçık/Kodlama Hatası", color: "var(--text-muted)", bg: "var(--bg-canvas)" }
};

// Çapraz ilişkilendirme eşleşmeleri (kök eksik tespiti; fark > %30 -> uyarı)
const CROSS_LINKS = [
  { a: { lesson: "Matematik", match: "Trigonometri" }, b: { lesson: "Fizik", match: "Dalgalar" }, root: "Matematik" },
  { a: { lesson: "Matematik", match: "Üslü" }, b: { lesson: "Kimya", match: "Mol" }, root: "Matematik" },
  { a: { lesson: "Matematik", match: "Olasılık" }, b: { lesson: "Biyoloji", match: "Genetik" }, root: "Matematik" },
  { a: { lesson: "Matematik", match: "Oran" }, b: { lesson: "Fizik", match: "Kuvvet" }, root: "Matematik" },
  { a: { lesson: "Matematik", match: "Türev" }, b: { lesson: "Fizik", match: "Hareket" }, root: "Matematik" },
  { a: { lesson: "Kimya", match: "Mol" }, b: { lesson: "Biyoloji", match: "Fotosentez" }, root: "Kimya" },
  { a: { lesson: "Kimya", match: "Asit" }, b: { lesson: "Biyoloji", match: "Solunum" }, root: "Kimya" }
];

// Sirkadiyen ritim pencereleri
const RHYTHMS = [
  { key: "Sabah", icon: "sunrise", hours: "06:00 - 12:00", coach: "Günaydın" },
  { key: "Öğle",  icon: "sun",     hours: "12:00 - 17:00", coach: "İyi günler" },
  { key: "Akşam", icon: "moon",    hours: "17:00 - 23:00", coach: "İyi akşamlar" }
];

// Kademeli Başarı Sistemi — 4 katman × 4 metrik (plan.pdf FAZ 5)
const BADGE_DEFS = [
  { key: "streak",  name: "Disiplin Ateşi", icon: "flame",       unit: "gün seri",   tiers: [7, 30, 90, 200],       tierNames: ["Bronz", "Gümüş", "Altın", "Elmas"] },
  { key: "reading", name: "Okuma Üstadı",   icon: "book-open",   unit: "dk okuma",   tiers: [100, 500, 1500, 5000], tierNames: ["Bronz", "Gümüş", "Altın", "Elmas"] },
  { key: "solved",  name: "Soru Fabrikası", icon: "pen-tool",    unit: "soru",       tiers: [1000, 10000, 25000, 50000], tierNames: ["Bronz", "Gümüş", "Altın", "Elmas"] },
  { key: "memory",  name: "Hafıza Bekçisi", icon: "shield-check", unit: "konu",      tiers: [5, 20, 50, 100],       tierNames: ["Bronz", "Gümüş", "Altın", "Elmas"] }
];

const TIER_COLORS = { 0: "var(--on-warning-bg-soft)", 1: "#64748B", 2: "var(--semantic-warning)", 3: "#0E7490" }; // Bronz Gümüş Altın Elmas
const TIER_TITLES = ["Başlangıç", "İstikrar", "Ustalık", "Efsane"];
const SCHOLAR_TITLES = ["Bronze Scholar", "Silver Scholar", "Gold Scholar", "Diamond Scholar"];

const NET_RULE = { wrongDivisor: 4 }; // TYT net = Doğru - Yanlış/4
const READING_MAX_MINUTES = 35;      // Okuma süresi tavan sınırı (dk)
const COGNITIVE_CORR_MIN_EXAMS = 5;  // N >= 5 olmadan korelasyon üretilmez

// ===== AYT DERS AĞIRLIK TABLOSU (ÖSYM/YKS resmi puan tablolarından) =====
// 9-10. sınıf düzeyinde alan (puan türü) ayrımı YOK; her ders için AYT'deki
// EN YÜKSEK puan etkisi tek ağırlık olarak kullanılır:
//   Matematik %30 · TDE %18 · Tarih %15 · Coğrafya %13 (Sözel)
//   Fizik %10.5 · Kimya %9.75 · Biyoloji %9.75 (Sayısal) · Din %5
const AYT_WEIGHT = {
  "Türk Dili ve Edebiyatı": 0.18,
  "Matematik": 0.30,
  "Fizik": 0.105,
  "Kimya": 0.0975,
  "Biyoloji": 0.0975,
  "Tarih": 0.15,
  "Coğrafya": 0.13,
  "Din Kültürü": 0.05
};
function aytWeightOf(lesson) { return AYT_WEIGHT[lesson] || 0; }
