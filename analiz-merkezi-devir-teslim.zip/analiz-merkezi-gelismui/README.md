# Analiz Merkezi v5.1 — Infinite Engine

Ahmed İbrahim'in "Analiz Merkezi" projesinin modüler yeniden yapımı.
Drive'daki 5 resmi belgeye (tema, UI/UX kılavuzu, ekran yapısı, geliştirme planı, 29 sayfalık revize promptlar) göre sıfırdan inşa edildi.

## Kullanım

- **Tek dosya (kullanıcı)**: `Analiz_Merkezi_v5_1.html` — çift tıkla açılır, kurulum gerekmez.
- **Geliştirme (modüler)**: `src/` altındaki modülleri düzenle, sonra birleştir:
  ```bash
  python3 merge.py          # Analiz_Merkezi_v5_1.html üretir
  python3 merge.py --dev    # dev_index.html üretir (yerel sunucuda: python3 -m http.server)
  ```

## Modüler Yapı

```
analiz-merkezi/
├── merge.py                    # birleştirici (build)
├── Analiz_Merkezi_v5_1.html    # TEK DOSYA çıktı (bunu kullan)
└── src/
    ├── index.template.html     # sayğa iskeleti (data-act delegasyonu, inline onclick YOK)
    ├── css/
    │   ├── tokens.css          # tema.pdf renk/yarıçap/gölge tokenleri + koyu mod
    │   ├── base.css            # yerleşim + yatay mod (landscape) + beyaz alan yaması
    │   └── components.css      # bento, buton, form, modal, toast, ağaç, yol haritası…
    └── js/
        ├── data/curriculum.js  # 9-10. sınıf müfredat ağaçları
        ├── data/constants.js   # dersler, hata taksonomisi, rejim tablosu, rozetler
        ├── core/utils.js       # tarih (setHours(0,0,0,0)), kaçış, yardımcılar
        ├── core/state.js       # durum + localStorage + v5→v6 göç + yedekle/geri yükle
        ├── core/engine-memory.js    # Ebbinghaus + Cepeda %15 + 3-7-14-21-28 takvim
        ├── core/engine-priority.js  # Laplace priorite + zorluk + kök eksik
        ├── core/engine-analytics.js # netler, ivme, okuma, koç
        ├── core/notifications.js    # bildirim merkezi + tarayıcı bildirimi
        ├── core/badges.js           # Bronz→Gümüş→Altın→Elmas + konfeti
        ├── ui/*.js                  # 8 ekran + kabuk (chrome)
        └── app.js                   # önyükleme + olay delegasyonu
```

## Belgelerdeki özellik karşılıkları

| Özellik | Durum |
|---|---|
| Calm Soft-Bento tema (#F5F8FF, 20px kart, koyu mod) | ✅ |
| 7 modül (A-G) + Panel, alt nav 6 buton, bildirim zili/modalı | ✅ |
| Deneme formu: 8 TYT dersi, D/Y/B, otomatik Boş, dinamik hata satırları | ✅ |
| Laplace düzeltmeli Priorite formülü (1.5·D + 1.0·T + 0.5·İşlem) × (1+AYT) | ✅ |
| Ebbinghaus: %100 başlangıç, üstel sönüm, tekrarda %100 + %10 yavaşlama | ✅ |
| Sistematik tekrar döngüsü 3-7-14-21-28 gün + bildirimler | ✅ |
| Sınava kalan süreye oranlı tekrar (Cepeda %10-20: max(1, round(gün×0.15))) | ✅ |
| Rejim tablosu (>120 / 30-120 / 7-30 / <7 gün) + son hafta yeni konu kilidi | ✅ |
| Tekrar bildirimleri (zil merkezi + tarayıcı bildirimi + kritik <%20 alarmı) | ✅ |
| Unutma İndeksi (başarı >%80 + 20 gün temassız) | ✅ |
| Çapraz ilişkilendirme + Kök Eksik Uyarısı (fark >%30) | ✅ |
| Tersine planlama: Haftalık İvme = (Hedef-Mevcut)/KalanHafta | ✅ |
| Sirkadiyen ritim + Altın Saat konuları (KRİTİK ODAK) | ✅ |
| 4 adımlı kanıta dayalı motor (Ön Test → Aktif → Örnek → Pratik), sıralı kilit | ✅ |
| Kitaplık: disiplin, hız, okuma geçmişi, bilişsel uyarı, N≥5 kondisyon eğilimi | ✅ |
| Zorluk önerisi (≤%40 TEMEL, ≤%75 ORTA, >%75 ZOR/YENİ NESİL) | ✅ |
| Streak + haftalık Freeze, Nudge kartı, Özerklik butonları | ✅ |
| Kademeli rozetler (4×4) + unvan + konfeti | ✅ |
| Koçluk Hattı (yüzen panel, dinamik mesajlar) | ✅ |
| JSON yedekle/geri yükle, 4 veri silme butonu, kılavuz, "Developed by Ahmed İbrahim" | ✅ |
| **PWA (manifest + service worker) ve FCM/OneSignal arka plan push** | ⚠️ Tek dosyada teknik olarak mümkün değil: HTTPS barındırma + Firebase/OneSignal projesi gerektirir (plan.pdf FAZ 0/4). Uygulama içi bildirim motoru ve tarayıcı bildirimi (uygulama açıkken) hazırdır; barındırılınca OneSignal SDK'sı eklenebilir. |

## Mühendislik notları

- **Olay delegasyonu**: dinamik `onclick` üretimi tamamen kaldırıldı (`data-act` + `addEventListener`). Eskiden dosyayı bozan tırnak/kesme işareti hataları (Kur'an, İslam'da…) bu sınıf tamamen ortadan kalktı.
- **CDN dayanıklılığı**: lucide/Chart yüklenmezse uygulama yine çalışır (stub koruması).
- **Mock veri yok**: tüm listeler boş başlar; v5 kullanıcı verisi ilk açılışta otomatik taşınır.
- **Beyaz alan yaması**: `html`, `body`, `.main-content` ve `.app-footer` aynı zemin rengini paylaşır; `100dvh` + `100vh` çift tanım ve `orientation: landscape` kuralları yatay modda kaydırma altındaki beyaz boşluğu önler.
