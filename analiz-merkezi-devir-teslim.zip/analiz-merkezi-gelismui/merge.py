#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ANALİZ MERKEZİ v5.1 — Birleştirici (Build)
Modüler kaynak dosyaları (src/) tek bir HTML dosyasına gömer.
Kullanım:
  python3 merge.py            -> Analiz_Merkezi_v5_1.html (tek dosya, çift tıkla açılır)
  python3 merge.py --dev      -> dev_index.html (ayrı dosyalar, yerel sunucuda geliştirme için)
"""
import os, sys

ROOT = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(ROOT, "src")

CSS_ORDER = ["tokens.css", "base.css", "components.css"]
JS_ORDER = [
    "js/data/curriculum.js",
    "js/data/constants.js",
    "js/core/utils.js",
    "js/core/state.js",
    "js/core/engine-memory.js",
    "js/core/engine-priority.js",
    "js/core/engine-analytics.js",
    "js/core/notifications.js",
    "js/core/badges.js",
    "js/ui/chrome.js",
    "js/ui/dashboard.js",
    "js/ui/tasks.js",
    "js/ui/exams.js",
    "js/ui/tracking.js",
    "js/ui/library.js",
    "js/ui/planning.js",
    "js/ui/knowledge.js",
    "js/ui/questionbank.js",
    "js/app.js",
]

def read(p):
    with open(os.path.join(SRC, p), encoding="utf-8") as f:
        return f.read()

def build():
    tpl = read("index.template.html")
    css = "\n".join(read(os.path.join("css", f)) for f in CSS_ORDER)
    js = "\n".join(read(p) for p in JS_ORDER)
    import base64
    ikon = base64.b64encode(open(os.path.join(SRC, "assets", "ikon.webp"), "rb").read()).decode()
    out = tpl.replace("/*__INLINE_CSS__*/", css).replace("//__INLINE_JS__", js)
    out = out.replace("__IKON_B64__", "data:image/webp;base64," + ikon)
    dest = "/home/user/gelişmişuianalizmerkezi.html"
    with open(dest, "w", encoding="utf-8") as f:
        f.write(out)
    print(f"✅ Tek dosya üretildi: {dest} ({len(out):,} bayt)")

def build_dev():
    tpl = read("index.template.html")
    css_tags = "\n".join(f'<link rel="stylesheet" href="css/{f}">' for f in CSS_ORDER)
    js_tags = "\n".join(f'<script src="{p}"></script>' for p in JS_ORDER)
    out = tpl.replace('<style>/*__INLINE_CSS__*/</style>', css_tags)
    out = out.replace("<script>//__INLINE_JS__</script>", js_tags)
    dest = os.path.join(ROOT, "dev_index.html")
    with open(dest, "w", encoding="utf-8") as f:
        f.write(out)
    print(f"✅ Geliştirici sürümü: {dest} (yerel sunucu gerekir: python3 -m http.server)")

if __name__ == "__main__":
    build()
    if "--dev" in sys.argv:
        build_dev()
