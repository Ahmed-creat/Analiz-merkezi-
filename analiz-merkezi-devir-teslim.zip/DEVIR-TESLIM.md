# ANALİZ MERKEZİ — DEVİR TESLİM PAKETİ
**Tarih:** 19 Eylül 2026 · **Sürüm:** v33 · **Hazırlayan:** Arena.ai Agent Mode (önceki geliştirici)

Bu paket, projeyi GitHub erişimi olan bir agent'a devretmek için hazırlandı.
`Rapor.md` dosyasında EK-1'den EK-35'e kadar tüm geliştirme geçmişi satır satır vardır —
bu dosya yalnızca **mevcut durumu, eksikleri ve yapılacakları** özetler.

---

## 0) İLK 5 DAKİKA (sonraki agent için)
1. **Canlı siteyi aç:** `https://analizmerkezii.netlify.app/` → Profil (avatar) → Okulizyon → başlıkta sürüm damgası.
   **v33 görmüyorsan** bu paketteki `site-yayin.zip` henüz yüklenmemiş demektir (içeriği v33 olarak doğrulandı).
2. **GitHub repo:** private `analiz-merkezi`. Kullanıcı 3 dosyayı elle güncellediğini söyledi
   (`functions/bildirim-gonder.js`, `functions/okulizyon-cek.js`, `.github/workflows/bildirim.yml`) —
   **`github-kurulum/` klasöründekilerle birebir olduğunu doğrula** (diff at).
3. **Acil kullanıcı sorunu:** bildirim gelmiyor → §4.1'deki teşhis yolunu izle.

---

## 1) PROJE ÖZETİ
9-10. sınıf öğrencisi (Ahmed İbrahim, Gaziantep) için tek dosyalık HTML5 PWA:
deneme/soru analizi, kazanım→konu eşlemeli hata takibi, öncelik motoru (Laplace düzeltmeli +
AYT ağırlıklı), Ebbinghaus tekrar takvimi, kitaplık, planlama, soru bankası.
Otomasyonlar GitHub Actions'ta: Okulizyon.com'dan sınav sonuçlarının çekilmesi (şifresiz,
Playwright), okul sitesi duyuru takibi (Tesseract OCR), FCM push bildirimler (07:30 tam set /
19:30 kritikler, İstanbul saati). Yedekleme: localStorage + Firestore (girişliyse).

---

## 2) CANLI DURUM TABLOSU
| Bileşen | Durum | Not |
|---|---|---|
| Site (Netlify) | 🟡 SÜRÜM BELİRSİZ | Son doğrulanan canlı: **v30.1**. v31/v32/v33 zip olarak teslim edildi; v33 yükleme **doğrulanmadı** |
| Eski site | ❌ TERK | `effortless-banoffee-00a8dd.netlify.app` — 401, PWA kurulamaz (özel site tuzağı) |
| GitHub Actions | 🟡 DOĞRULANMADI | 3 dosya kullanıcı tarafından güncellendi (beyan); koşu logu hiç incelenmedi |
| Firebase | ✅ ÇALIŞIYOR | Proje `analiz-merkezi-87338`; e-posta/şifre girişi + Firestore canlı test edildi |
| Push zinciri (kod) | ✅ KANITLI | Sandbox'tan GERÇEK FCM token'ı Firestore'a yazıldı (push testi 6/6) |
| Push telefona | ❌ Teyit YOK | Yeni domainde kullanıcının bildirim aldığı hiç doğrulanmadı → §4.1 |
| PWA kurulabilirlik | ✅ 12/12 | pwa-audit.js: manifest, ikonlar, SW, güvenli bağlam hepsi geçti; kullanıcı yükledi |

---

## 3) TAMAMLANANLAR (v33 itibarıyla)
- **Uygulama:** 8 sayfa (Ana Sayfa, Görevler, Denemelerim, Konu Takibi, Kitaplık, Planlama,
  Bilgi Bankası, Soru Bankası), koyu/açık tema, mobil alt navbar + masaüstü sidebar.
- **Açılış akışı:** 5 slaytlı tanıtım (koyu gradyan, cam efektli ikonlar, animasyonlu geçiş,
  segment göstergе, swipe) → sınıf seçimi → isim. **Yalnız ilk kez**; tanıtımı gören veya isim
  giren kullanıcıda sınıf ekranı bir daha gelmez. Sınıf değiştirme: Ayarlar → SINIF (ayrı hesap:
  `analizmerkezi_v6_g9` / `_g10`).
- **Profil merkezi:** avatar (masaüstü) + mobil üst barda baş-harfler avatarı ve isim → HESAP
  (giriş durumu + Giriş Yap/Çıkış) + OKULIZYON bağlantı formu + "Analiz Bekliyor (N soru)".
  DAHA sayfası sade (giriş/Okulizyon maddeleri kaldırıldı).
- **Okulizyon:** Actions 07:30'da okulizyon.com/app2'den sonuçları çeker (şifresiz giriş:
  AD SOYAD büyük harf + okul no + il/ilçe/okul), kazanım→konu deterministik eşleme, yanlış/boşlar
  "Analiz Bekliyor" kuyruğuna düşer, kullanıcı nedenini seçer → deneme olarak işlenir.
  **İlk çekimde 15 denemeye kadar** (sonrakiler 5).
- **Okul sitesi:** akkentanadolulisesi.meb.k12.tr duyuruları + OCR'lı ders programı → takvime
  otomatik sınav + orana göre hazırlık günleri.
- **Bildirim motoru:** sabah tam set / akşam kritikler; **workflow_dispatch "test"** checkbox →
  TEST=1 → tüm tokenlı kullanıcılara anında push (unregistered token otomatik silinir+loglanır).
- **Bulut:** e-posta/şifre + Google girişi, Firestore yedek, debounced yazma, çakışmada sorma;
  bulut yüklerken yerel isim korunur (v33 düzeltmesi — splash dönüş bug'ının kökü buydu).
- **Gerçek veri:** `ahmed-ibrahim-9-sinif-denemeleri.json` — 7 gerçek deneme, 272 hata kaydı,
  Genel Netler PDF ile birebir (85,5 → 78,5 → 65,25 → 77,75 → 82,25 → 67,5 → 78,5), tüm
  kazanımlar curriculum.js konu ağacına eşlenmiş (73 özgün konu).
- **Test paketi:** **104/104** geçti (tur32 28 · okz 14 · pwa 13 · g1 27 · g2 13 · dark 3 ·
  push 6) + verify-json 18/18 + pwa-audit 12/12.

---

## 4) YAPILMAYANLAR / ÇÖZÜLMEYENLER
### 4.1) BİLDİRİM TELEFONA GELMİYOR (en kritik açık)
- **En olası neden:** site domain'i değişti (eski → analizmerkezii) → **FCM token'lar domaine
  bağlı olduğu için hepsi öldü**. Telefonda yeni sitede bir kez: Profil → Giriş Yap + bildirim
  izni Ver gerekiyor. Kullanıcıya defalarca anlatıldı; yapıp yapmadığı bilinmiyor.
- **Teşhis yolu (GitHub erişimli agent ilk işi):** Actions → Bildirim Motoru → Run workflow →
  "test" ✓ → koşuya tıkla → **"Bildirimleri gönder"** adımının logu. Satırlar:
  - `token YOK` → telefonda giriş/izin yapılmamış (yukarıdaki adım).
  - `✓ gönderildi` → kod tarafı tamam; telefon tarafı (bildirim kanalı, pil optimizasyonu) sorunlu.
  - `unregistered` → token ölü; silinir, yeni giriş gerekir.
- **"test" butonu iş akışı adımlarında neden görünmüyor:** bilinçli tasarım — checkbox TEST
  env'i "Bildirimleri gönder" adımı İÇİNDEKİ `bildirim-gonder.js`'i TEST moduna sokar; ayrı adım yok.

### 4.2) Doğrulanmayan diğer şeyler
- **Actions'ta gerçek Okulizyon çekimi:** 07:30 koşusunun logu hiç incelenmedi (kaç deneme
  çekildi, Playwright chromium sorunsuz mu). Kullanıcı yalnız "Okulizyon açılıyor" (modal) doğruladı.
- **v33'ün Netlify'a yüklenmesi:** zip teslim edildi; yükleme kullanıcı tarafında, teyit yok.
- **GitHub'daki 3 dosyanın içeriği:** kullanıcı yapıştırdı; birebirlik doğrulanamadı (bu ortamın
  GitHub erişimi YOK — Connections açık görünse de erişim verilmiyor).
- **APK yerel alarm:** kullanıcı kuralıydı (q); PWA + FCM yolu seçildiği için hiç yapılmadı.
- **10. sınıf:** müfredat verisi var, uygulama destekliyor; ama tüm test/içerik 9. sınıfa odaklı.

---

## 5) BİLİNEN TUZAKLAR (tekrar düşmeyin)
1. **FCM token domaine bağlı** — domain değişirse tüm token'lar ölür, yeniden giriş+izin şart.
2. **Netlify site PUBLIC olmalı** — 401 dönerse Chrome manifest'i okuyamaz, PWA kurulmaz.
3. **sw.js sürüm damgası:** `build_pwa.py` her derlemede `analiz-merkezi-v-<zaman>` damgasını
   regex ile yeniler (eski damga donunca güncelleme gitmiyordu — düzeltildi).
4. **Python çoklu-yama:** replace metinlerinde `\\"` çift kaçış SyntaxError verir → `\u` kaçışları
   kullan + yazdıktan sonra grep ile doğrula. `node --check` değişmemiş dosyada geçer, yalnız güvenilmez.
5. **JS test:** non-async arrow içinde `await` (`every(k => await ...)`) SyntaxError → for-of kullan.
6. **Headless Chrome push servise bağlanmaz** → push testi: `HEADED=1 xvfb-run -a node push.js`.
7. **Sandbox kalıcılığı:** node_modules ve tarayıcı önbelleği silinir → her oturumda
   `npm i playwright@1.49.1 && npx playwright install chromium` + `sudo apt-get update &&
   sudo apt-get install -y libnss3 libnspr4 libatk1.0-0 libatk-bridge2.0-0 libatspi2.0-0
   libxdamage1 libxkbcommon0 libasound2 libcups2 libgbm1 xvfb`.
8. **GitHub mobil upload package.json'ı bozar** → workflow kendi package.json'unu kendisi yazar
   (KENDİNE YETERLİ tasarım), depodakine güvenmez.
9. **cron UTC'dir:** `30 4 * * *` = İstanbul 07:30, `30 16 * * *` = 19:30.
10. **Overlay/modal açıkken arkadaki öğeler tıklanamaz** — testlerde önce kapat.
11. **Animasyonlu overlay tıklamaları yutabilir** — fade-out sırasında `pointer-events:none` şart
    (v33'te onboarding'de düzeltildi; benzer UI eklerken unutma).

---

## 6) PAKET İÇERİĞİ (dosya haritası)
```
DEVIR-TESLIM.md                          ← bu rapor
Rapor.md                                 ← TAM geliştirme geçmişi (EK-1..35)
ahmed-ibrahim-9-sinif-denemeleri.json    ← gerçek deneme verisi (içe aktarılmaya hazır)
site-yayin.zip                           ← NETLIFY'A YÜKLENECEK tam paket (v33, 9 dosya) ✅doğrulandı
guncelleme.zip                           ← hızlı güncelleme (app-pwa.js + index.html + sw.js)
gelişmişuianalizmerkezi.html             ← merge.py çıktısı (tek dosyalık sürüm, bağımsız çalışır)
github-kurulum/                          ← GitHub'A YÜKLENECEKLER (Actions) + kurulum kılavuzu
  ├─ bildirim.yml                        ← .github/workflows/bildirim.yml olarak
  ├─ bildirim-gonder.js                  ← functions/bildirim-gonder.js olarak (TEST modlu)
  ├─ okulizyon-cek.js                    ← functions/okulizyon-cek.js olarak (ilk çekim 15)
  └─ KURULUM-ADIMLARI.md                 ← sıfırdan kurulum + güncelleme + test modu kılavuzu
analiz-merkezi-pwa/                      ← CANONİK SÜRÜM (v33): index.html, app-pwa.js, sw.js,
                                           manifest.json, firebase-*, icons/, functions/ (6 js),
                                           build_pwa.py, firebase.json, README-PWA.md
analiz-merkezi-gelismui/                 ← KAYNAK KOD: src/js (core/data/ui), src/css,
                                           src/index.template.html, merge.py
pw-tests/                                ← test paketi (node_modules HARİÇ — kur: §5.7)
  tur32.js okz.js pwa.js push.js g1.js g2.js dark.js  ← ana testler
  pwa-audit.js verify-json.js pdf-deneme-json.py      ← denetim/üretici
```

---

## 7) BUILD ZİNCİRİ (kod değişikliği yapacaksan)
```
analiz-merkezi-gelismui/src/**  →  merge.py  →  gelişmişuianalizmerkezi.html
                                                     ↓
                                          analiz-merkezi-pwa/build_pwa.py
                                            (manifest+meta etiketleri ekler, firebase-config'i
                                             messaging-sw'ye basar, sw.js damgasını yeniler)
                                                     ↓
                                        analiz-merkezi-pwa/index.html  → zip'le → Netlify
```
- Sürüm damgası: `app-pwa.js` → `const PWA_SURUM = "v33"` (Okulizyon modal başlığında görünür —
  telefon tarafındaki sürümü böyle kontrol et).
- JS API anahtarları dosyalarda gömülü (client-side Firebase normaldir); tek secret
  `FIREBASE_SERVICE_ACCOUNT` GitHub'dadır.

## 8) TEST KOŞUMU
```bash
cd pw-tests && npm i playwright@1.49.1 && npx playwright install chromium
cd ../analiz-merkezi-pwa && python3 -m http.server 8123 &
cd ../pw-tests
node tur32.js   # onboarding+profil+mobil (28 test)
node okz.js     # Okulizyon profil akışı (14)
node pwa.js     # PWA + canlı Firebase girişi (13)
node g1.js      # masaüstü işlevler (27)
node g2.js      # mobil/yatay işlevler (13)
node dark.js    # tema (3)
HEADED=1 xvfb-run -a node push.js   # canlı FCM token (6)
node verify-json.js                 # deneme JSON'u içe aktarma (18)
node pwa-audit.js                   # kurulabilirlik (12)
```

## 9) ACİL GÖREV SIRASI (önerilen)
1. Netlify: `site-yayin.zip` yükle/doğrula → Okulizyon başlığında **v33** görülmeli.
2. GitHub: 3 dosyayı `github-kurulum/` ile diff'le; farklıysa güncelle + commit.
3. Telefonda: yeni sitede **Profil → Giriş Yap + bildirim izni Ver** (kullanıcıya yaptır).
4. Actions → Run workflow → **test ✓** → "Bildirimleri gönder" adım logunu oku (§4.1 anahtarları).
5. Sabah 07:30 koşusunun logunu incele: Okulizyon çekimi kaç deneme getirdi, hata var mı.
6. Sorun kalmazsa: 10. sınıf içeriği / APK yerel alarm gibi bekleyen talepler.

## 10) KULLANICININ DEĞİŞMEZ KURALLARI
Ücretsiz altyapı only · tek iş akışı (bildirim.yml) · telefon dışı araç yok · Okulizyon şifresiz ·
görsel okuma Tesseract ile (API yok) · kazanım→konu deterministik (AI yasak) · **istenmedikçe UI'ye
buton/banner ekleme** (kullanıcı "Uygulamayı Yükle" butonunu açıkça reddetti) · GitHub'a yüklemeler
telefonda tek tek yapılır · değişiklik anında fark edilmeli (network-first SW).

---

## 11) PR DÜZELTMESİ — v33.1 (19 Eylül 2026)
GitHub deposu ve Actions koşuları incelenince bildirim zincirindeki istemci tarafı açık bulundu:
`app-pwa.js` FCM token'ı `navigator.serviceWorker.ready` ile **sw.js kaydına** bağlı alıyor; fakat v33 `sw.js` yalnız cache/fetch yapıyordu. Bu durumda `firebase-messaging-sw.js` dosyası bu token için devreye girmediği için uygulama kapalıyken gelen Web Push'u gösterecek `push`/`notificationclick` işleyicisi yoktu.

Düzeltme: `sw.js` içine FCM/Web Push payload'ını okuyup sistem bildirimi gösteren arka plan `push` işleyicisi ve tıklanınca uygulamayı açan `notificationclick` işleyicisi eklendi; cache damgası yenilendi. Sunucu tarafında `bildirim-gonder.js`, `degisiklik-kontrol.js` ve opsiyonel `index.js` WebPush link/icon verisini mutlak URL ile gönderir. `site-yayin.zip` ve `guncelleme.zip` v33.1 olarak güncellendi.
