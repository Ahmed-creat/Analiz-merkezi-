# Analiz Merkezi v5.1 — Yeniden Yapılandırma Raporu

## İstekler ve yapılanlar

### 1) Mock veriler silindi ✅
Uygulama artık **tamamen boş** başlıyor: deneme, soru, kitap, bildirim, hafıza ve rozet listeleri sıfır. (Eski v5'teki gerçek kullanıcı verin varsa ilk açılışta otomatik taşınıyor.)

### 2) "Ekran yapısı" belgesine göre yeniden yapıldı ✅
Drive'daki `ekran yapısı.pdf` satır satır okundu ve tüm ekranlar birebir uygulandı:
- Ortak: açılır yan menü (logo, kullanıcı, seri, zil, ayarlar, 7 modül, tarih) • mobil üst bar • 6 butonlu alt navigasyon
- **Modül G** Görevler: büyük seri kartı, 3 görev satırı, tebrik mesajı, seri istatistikleri
- **Modül A** Denemeler: sol panel form (ad, tarih, 0/120 progress, 8 ders kartı, D/Y/B, dinamik hata satırları: Soru No + Konu + Neden), 4 özet kutusu, Net Gelişimi grafiği, son denemeler + silme
- **Modül B** Konu Takibi: Acil Çalışılacaklar (sıra, KAE, renkli puan, anlamadım sayısı, bar, neden listesi), Ders Başarı Oranları, Hafıza Gücü (KRİTİK rozeti, %, tekrar sayısı, ✓Tekrar Ettim / Erken Tekrar / ACİL TEKRAR ET, "Anlamadım, Baştan Başla"), Hafıza İstatistikleri
- **Modül C** Kitaplık: form, kartlar (tamamlandı rozeti, %, silme, bar, "Bugün kaç sayfa okudun?"), Okuma Geçmişi (details), Bilişsel Uyarı Banner'ı
- **Modül D** Planlama: hedef formu, 3 ritim kartı, Bilişsel Okuma Önerisi, Geri Sayım (4 kutu), **Haftalık İvme (Momentum)** kartı, **Altın Saat Konuları**
- **Modül E** Bilgi Bankası: müfredat ağacı + yol haritası (sıralı kilitli adımlar, tamamlanınca yeşil onay kartı)
- **Modül F** Soru Bankası: form (renkli D/Y/B, kırmızı validation kutusu, dinamik hata satırları), yığılmış D/Y grafiği, son çözümler + "hata kaydı girilmedi" uyarısı
- Özel: Hoş Geldin modalı, Kullanım Kılavuzu (modül modül + Bilimsel Algoritmalar + Pro İpuçları), Ayarlar çekmecesi (4 silme + yedekle/geri yükle), Onay modalları, **Bildirim modalı (zil, okundu/okunmadu)**, Toast'lar, "Developed by Ahmed İbrahim"

### 3) Yatay moddaki beyaz alan giderildi ✅
Kök neden: `body` sadece `min-height:100vh` ile zemin taşıyordu; içerik uzayınca kaydırma altında stil'siz bölge kalıyordu.
Çözüm: `html + body + .main-content + footer` aynı `var(--bg-canvas)` zeminini paylaşıyor, `100dvh` desteklendi, `@media (orientation: landscape)` için kompakt kurallar (dar üst bar, sıkışık kartlar, ikon-only alt nav) eklendi.

### 4) Modüler yapı + tek HTML ile açılma ✅
```
analiz-merkezi/  (kaynak: 19 modül dosyası)
├── merge.py                  ← python3 merge.py komutu
├── Analiz_Merkezi_v5_1.html  ← TEK DOSYA çıktı (çift tıkla açılır)
└── src/ (css: tokens/base/components, js: data/core/ui)
```
Ayrıca mühendislik sağlamlaştırması: dinamik `onclick` tamamen kaldırılıp **olay delegasyonu**na geçildi → geçmişte dosyayı çökerten tırnak hatları (Kur'an'dan, İslam'da…) yapısal olarak imkânsızlaştı. CDN erişilemezse (İnternet yok) uygulama yine çalışıyor.

### 5) "Dosyalardaki her şey" — eksikler tamamlandı ✅
Bu sürümde YENİ eklenen motorlar:
| Motor | Belge |
|---|---|
| **Ebbinghaus**: %100 başlangıç → üstel sönüm; "Tekrar Ettim" → %100 + her tekrarda unutma hızı %10 yavaşlar | revize promptlar §1 |
| **Tekrar bildirimleri**: 3-7-14-21-28. gün hatırlatıcıları zil merkezine düşer + okunmadı sayacı + tarayıcı bildirimi (uygulama açıkken) | §3. Gün Master Prompt |
| **Sınava kalan süreye oranla tekrar**: Cepeda %10-20 kuralı — max(1, round(KalanGün×0.15)); 4 kademeli rejim tablosu; son hafta yeni konu kilidi uyarısı | "Sınava Kalan Süreye Oranlı Dinamik Motor" |
| **Kritik hafıza <%20 anlık alarmı** + <%40 KRİTİK rozeti | plan.pdf FAZ 4 |
| **Unutma İndeksi** (başarı >%80 + 20 gün temassız → bildirim) | revize promptlar Modül B |
| **Kademeli rozetler**: Disiplin Ateşi / Okuma Üstadı / Soru Fabrikası / Hafıza Bekçisi × Bronz-Gümüş-Altın-Elmas + unvan + konfeti | plan.pdf FAZ 5 |
| **Koçluk Hattı**: yüzen dinamik analiz paneli | "Analiz Koçu Paneli" |
| **Nudge günlük check-in kartı** (ekran kilitlemez) | Davranışsal Oyunlaştırma |
| **Streak Freeze** (haftalık 1 dondurma) | v5 şartnamesi |
| **Kök Eksik Uyarısı** (çapraz ilişkilendirme, fark >%30) | revize promptlar Modül B |
| **Zorluk önerisi** (≤%40 TEMEL / ≤%75 ORTA / >%75 ZOR-YENİ NESİL) | Modül F |
| **Haftalık İvme** = (HedefNet−MevcutOrt)/KalanHafta + **Altın Saat** ataması | v5 motorları |
| **Bilişsel okuma**: ANLAMADIM >%30 uyarısı, 35 dk tavan, N≥5 Kondisyon Eğilimi | Modül C/D |
| **4 adımlı kanıta dayalı motor** (0. Ön Test → 1. Aktif Çalışma → 2. Çözümlü Örnek → 3. Karışık Pratik) sıralı kilitli | v5 Modül E |
| Laplace düzeltmeli Priorite formülü, net= D−Y/4, JSON yedek, setHours(0,0,0,0) hassasiyeti | Modül A + Teknik Zırlama |

**Tek istisna — PWA ve FCM/OneSignal arka plan push**: tek HTML dosyasından (file:// ile açılan) teknik olarak yapılamaz; HTTPS barındırma + Firebase/OneSignal projesi gerekir. Uygulama içi bildirim merkezi, ritim bazlı günlük koç mesajı ve tarayıcı bildirimi (uygulama açıkken) hazır; barındırma kararını verirsen OneSignal SDK'sı (ID elinde mevcut) eklenebilir.

## Test sonuçları (simüle tarayıcı — jsdom)
Giriş akışı, 8 modül, Kur'an gibi kesme işaretli konularla tüm tıklama zincirleri, Ebbinghaus sönümü ve ivme yavaşlatması, tekrar bildirimi üretimi, Cepeda takvim sıkıştırması (20 gün kala max 5 güne indi), kritik alarm, v5→v6 veri göçü, seri sayacı, yedekleme butonları: **hepsi ✅, 0 çalışma hatası.**


---

# EK: Satır Satır Denetim (3. Tur) — 5 Belgedeki Tüm Detaylar

Bu turda 5 PDF tek tek, madde madde okundu; her maddenin kodda karşılığı grep + otomatik testle doğrulandı.

## Bu turda BULUNUP DÜZELTİLEN 11 detay

| # | Belgedeki ifade | Düzeltme |
|---|---|---|
| 1 | ekran yapısı §1: "Açılıp kapanan **Masaüstü** Sol Menü" | Masaüstünde de küçültülebilen sidebar + sol üstte "menüyü aç" butonu + tercih hatırlanır |
| 2 | Kullanıcı notu: görevler tıklayınca değil, **eylem yapılınca** tamamlanmalı | Elle tik kaldırıldı: study→Bilgi Bankası'nda adım/konu bitirme, read→Kitaplık'tan sayfa girme, solve→Soru Bankası'na çözüm **veya deneme kaydetme** otomatik işaretler; seri sayacı da eylemle artar |
| 3 | UI/UX §5B: Ayarlar çekmecesi "ekranın tam %30'u" | 340px sabit → %30 (min 300 / max 460px) |
| 4 | UI/UX §5A: Alt navigasyon "64px yükseklik" | Sabit 64px + safe-area |
| 5 | tema §6: Lucide "Çizgi Kalınlığı: 1.75px" | CSS stroke-width: 1.75px eklendi |
| 6 | UI/UX §5B: Sol panel 240px sabit / sağ panel 340px sabit | 260px→240px; sağ kolon `minmax(0,1fr) 340px` |
| 7 | tema §1: masaüstünde 24px güvenli boşluk | 28/32px → 24px |
| 8 | master metin Modül A: "Hata Tipi Dağılım Grafiği (KAE/İH/SKYA/KH yüzdesel)" | Konu Takibi'ne Hata Tipi Dağılım kartı eklendi (renkli barlar + yüzde + adet) |
| 9 | master metin: "'Konuyu öğrendim' → konu Priorite Listesi'nden düşer" | Tamamlanan konunun eski hataları filtrelenir; tamamlamadan SONRA yapılan yeni hata konuyu listeye geri getirir |
| 10 | ekran yapısı Modül B: "duruma göre değişen ✓Tekrar Ettim / Erken Tekrar / ACİL TEKRAR ET" | Buton mantığı düzeltildi: kritik<%20→ACİL, zamanı gelmiş→✓Tekrar Ettim, yüksek bar→✓Tekrar Ettim, aksi→Erken Tekrar |
| 11 | ekran yapısı Modül B: "'Anlamadım, Baştan Başla' **veya** 'Baştan Başla'" | Konunun hata profiline göre ikisi arasında otomatik geçen etiket |

## Doğrulanan ve zaten mevcut olan detaylar (özet)

- **ekran yapısı**: sidebar'da logo+başlık+kullanıcı+alev seri+zil(rozetli)+dişli+tarih · 6 butonlu alt nav · Modül G'de büyük alev+seri, 3 görev, tebrik+ yeni seri, "Mevcut Seri/Toplam Gün" kutuları · Modül A: 8 ders, D/Y/B, dinamik hata satırı (No+Konu+Neden), 0/120 progress, 4 özet kutusu, Net Gelişimi çizgisi, son denemeler+çöp · Modül B: #sıra, KAE, renkli puan, anlamadım sayısı, neden listesi, KRİTİK rozeti, %+tekrar sayısı · Modül C: ✓Tamamlandı, okuma geçmişi (details), bilişsel uyarı bannerı · Modül D: 3 ritim kartı(ikon+metin+saat), bilişsel öneri, 4'lü geri sayım, Momentum (tempo+ büyük +X.XX + 3'lü kutu), Altın Saat (KRİTİK ODAK etiketi) · Modül E: ağaç+üstbilgi kartı+kilitli adımlar+tamamla butonu+yeşil onay kartı · Modül F: renkli D/Y/B, kırmızı validation, yığılmış D/Y grafiği, "hata kaydı girilmedi" uyarısı · modallar (hoş geldin, onay-sarı ikon, bildirim-okundu/okunmadı, kılavuz, ayarlar-4 sil+yedek), toast sağ üst
- **tema.pdf**: #F5F8FF/#FFFFFF/#E8EEF8, 20/14/24px radius, mavi gölge, koyu mod #0F172A, tabular-nums, tipografi ölçeği
- **UI/UX kılavuzu**: 7±2 gruplama, 4 yalın buton, 48px hedefler, inputmode+Auto-Advance, spring'li hafıza barı, alert yasağı, doğrulama mesajları
- **plan.pdf**: FAZ1-3 ve FAZ5 tam; FAZ0 (PWA) + FAZ4 (FCM) tek dosyada teknik olarak imkânsız (belgelendi)
- **revize promptlar**: Ebbinghaus+ivme %10, 3-7-14-21-28+notifications dizisi, Cepeda %15+4 kademeli rejim+son hafta kilidi, kritik <%20 dürtme, unutma indeksi, Laplace priorite, çapraz ilişkilendirme+kök eksik, zorluk önerisi, tersine planlama+sirkadiyen+altın saat, 4 adımlı motor+sıralı kilit, N≥5 eşiği, 35dk tavan, freeze, nudge, özerklik butonları, 4×4 rozet+unvan+konfeti, koçluk hattı, JSON yedek, setHours(0,0,0,0), footer imzası, console imzası

## Test sonuçları (3. tur)
15/15 senaryo ✅ · 0 çalışma hatası (jsdom): göç, 8 modül, planlama motorları, unutma eğrisi, ivme, tekrar bildirimi, Cepeda sıkıştırma, 4 adım kilidi, görev otomasyonu, deneme→görev, acil liste+dağılım, öğrenildi→düşme, masaüstü sidebar aç/kapa.


---

# EK: 4. Tur — Renk Paleti, 2 Tema, Form Sınırları, Thumb Kuralı

## Bulunup düzeltilenler

| # | Konu | Düzeltme |
|---|---|---|
| 1 | **Toplam 2 tema yoktu** (sadece sistem otomatiği) | Ayarlar'a TEMA bölümü (Açık ☀ / Koyu ☾) + sidebar'da hızlı anahtar + tercih `localStorage`'da + sayfa açılırken **FOUC önleyen erken script** + `meta theme-color` canlı güncellenir. İlk açılış sistem tercihi, sonra kullanıcı seçimi geçerli |
| 2 | **Koyu tema paleti eksikti** | tema.pdf Soft-Dark sütunu birebir uygulandı: hata #F87171 (bg #450A0A), uyarı #FBBF24 (bg #451A03), başarı #34D399 (bg #064E3B), hafıza #818CF8 (bg #1E1B4B), zemin #0F172A/#1E293B/#334155 + `color-scheme: dark` (date picker vb. uyum) |
| 3 | **Açık palet doğrulandı** | tema.pdf Açık sütunu birebir: #F5F8FF/#FFFFFF/#E8EEF8/#0F172A/#64748B/#2563EB/#EF4444 (bg #FEF2F2)/#F59E0B (bg #FFFBEB)/#10B981 (bg #ECFDF5)/#6366F1 (bg #EEF2FF) — otomatik testle hex hex doğrulandı |
| 4 | **Koyu temada okunamayan metinler** | 11 dosyadaki sabit açık-tema metin renkleri (#991B1B, #065F46, #92400E…) tema değişkenlerine çevrildi (--on-error-bg, --on-success-bg, --on-warning-bg…) — koyu temada otomatik açık tona döner |
| 5 | **Deneme girişinde sınır yoktu** | Canlı kırpma: negatif → 0, ders max'ı üstü → anında kırpılır (Matematik D=40 → 30), D+Y > max → son girilen sığdırılır, Boş (OTO) otomatik + kırpılırsa **ders kartında kırmızı uyarı kutusu** çıkar |
| 6 | **Soru bankasında ders değişince konu satırları açılmıyordu ("yanlış konusu seçilemiyor")** | Ders select'ine change dinleyicisi eklendi: D/Y/B girildikten sonra ders seçilirse konu satırları anında açılır. Ayrıca ders seçilmeden yanlış girilirse canlı kırmızı validasyon: "önce Ders seçmelisin" |
| 7 | **QB canlı sınır/validasyon** | D/Y/B 0–999 kırpılır, toplam < D+Y+B olamaz, >200 soruda kırmızı uyarı, DOM koruması: en fazla 30 hata satırı |
| 8 | **Thumb kuralı (Fitts/UI-UX §4)** | Birincil Kaydet butonları (Deneme, Soru Bankası, Kitap, Plan) mobilde ekran alt bölgesine **sticky**; silme ikonları 40px → **48px** minimum hedef |
| 9 | **Pastel ikon yuvası (tema.pdf §6)** | Bölüm başlığı ikonları %10 opaklıkta kendi rengiyle yuvalanır (color-mix) |
| 10 | **Grafikler temaya uyum** | Çizgi/bar renkleri CSS değişkenlerinden okunur (koyu temada uyumlu ton) |

## Test sonuçları (4. tur)
28 yeni kontrol ✅ + 12 eski regresyon ✅ = **40/40, 0 hata** (jsdom).
Kapsanan: erken tema ataması, her iki paletin hex hex doğrulaması, tema seçimi/kalıcılığı/meta rengi, hızlı anahtar, canlı kırpma (5 senaryo), uyarı kutuları, ders değişiminde konu satırları, QB konu kaydı, 4 sticky buton, 48px hedefler, 1.75px ikon, pastel yuva + önceki turların tüm akışları.


---

# EK: 5. Tur — "Hata verisi girince diyor" Sorunu Üzerine İlk Müdahale (sonradan revize edildi)

Bu turda eklenen "ders geneli hızlı Hata Tipi" yaklaşımı KULLANICI TALEBİYLE 6. turda tamamen kaldırıldı: resmi tasarım her yanlış ve boş soru için AYRI konu + neden girişi gerektirir.



---

# EK: 6. Tur — Gerçek Kök Neden: Hata Kayıtları Sessizce Düşüyordu

## Kullanıcının bildirdiği sorun
"Hata verilerini girdiğim halde öncelik listesi / konu takibi oluşmuyordu."

## Bulunan 2 sessiz veri kaybı hatası (kök nedenler)
| # | Hata | Etki |
|---|---|---|
| 1 | `collectErrorLogs` satırı yalnız **Soru No + Konu + Neden üçlüsü tamken** sayıyordu. Soru No'sunu boş bırakan (veya yalnız konu+neden seçen) kullanıcının TÜM satırları sessizce düşüyor, liste boş kalıyordu — hiçbir uyarı yoktu | Ana suçlu |
| 2 | `topicLearnedAfter` filtresi tamamlama GÜNÜNDEKİ hataları da siliyordu (`ld <= done`) | Aynı gün konu bitiren kullanıcının o günkü hataları kaybolurdu |

## Yapılanlar
1. **Hızlı mod tamamen kaldırıldı** (ders geneli Hata Tipi, lessonErrors motoru, DERS GENELİ rozeti, QB hızlı seçici — 0 kalıntı)
2. **Soru No opsiyonel**: boş bırakılırsa otomatik sıra numarası atanır; **Konu + Neden zorunlu**
3. **Zorunluluk garanti altında**: eksik satır varsa kayıt ENGELLENİR + kırmızı kutu "Matematik (2 eksik)" diye ders ders listeler — sessiz kayıp imkânsız
4. **"İşlenen hata: 3/5" ilerleme sayacı** her ders kartında (canlı güncellenir; tümü dolunca yeşil ✓)
5. **Aynı-gün düzeltmesi**: tamamlama günündeki hatalar sayılır; yalnız daha eski hatalar düşer (`ld < done`)
6. Kayıt sonrası onay: "8 hata kaydı işlendi — Konu Takibi listesi hazır"
7. QB aynı zorunluluk + sayaç; yanlış satırlarına yanlış nedeni, boş satırlarına boş nedeni zorunlu (KONU EKSİKLİĞİ / SÜRE YETMEDİ / ÇÖZÜM YOLUNU BULAMADIM)

## Test (16/16 ✅ + 12/12 regresyon ✅, 0 hata)
- 5 yanlış → 5 satır açılır, sayaç 0/5 → 3/5
- Kısmi dolduruşta kayıt ENGELİ + mesaj
- **Soru No boş** bırakılıp tüm konu+neden seçilince: kayıt + 8 hata kaydı + öncelik listesi + Panel görevi + Acil liste + dağılım kartı (eski bug senaryosu artık çalışıyor)
- Aynı gün tamamlanan konunun bugünkü hataları listede kalıyor
- QB engel/kayıt + boş sorusuna boş nedeni zorunluluğu


---

# EK: 7. Tur — Soru Bankası Neden Seçimi, Soru No, Temalı Listeler, Mock Data

| # | İstek | Yapılan |
|---|---|---|
| 1 | **Soru Bankası'nda yanlış/boş için neden seçilemiyor** | Kök neden: satırlar her D/Y/B değişiminde sıfırdan çiziliyor ve **seçimler siliniyordu** (deneme formundaki değer koruması QB'ye konulmamıştı). Çözüm: QB'ye de değer koruma (prev haritası) + ders seçilmeden girilen D/Y için yönlendirme hint kutusu + ders seçilince satırların anında açılması |
| 2 | **Soru No kaldır** | Deneme ve QB hata satırlarından Soru No girişi tamamen kaldırıldı; kayıtta otomatik sıra numarası atanıyor (qno 1,2,3…) |
| 3 | **Listeler fazla basit / bembeyaz tarayıcı teması** | Yeni temalı hata satırı kartı: sol renk şeridi + **YANLIŞ (kırmızı) / BOŞ (indigo) rozeti + #sıra**, KONU SEÇ / NEDEN SEÇ etiketleri, iki kolonlu düzen, doldukça **yeşil onay** durumuna geçen kart. Tüm select/input'lar native beyaz görünümünden kurtarıldı: `appearance:none` + temalı ok ikonu + odak halkası + **koyu temada option'lar dahil** tema renginde |
| 4 | **Mock data JSON** | `analiz-merkezi/mock-data.json`: 4 deneme (40 hata kaydı, Kur'an'dan/İslam'da gibi apostroflu konular dahil), 3 soru bankası kaydı (13 hata), 3 kitap (okuma geçmeli, biri bitmiş), 4 tamamlanmış konu + 3 Ebbinghaus takvimi (biri %9 kritik → ACİL TEKRAR), 4 bildirim (rozet/tekrar/acil/koç), rozetler, plan (sınav 2026-10-17, hedef 95 net), 12 günlük seri. Ayarlar → İçe Aktar ile yüklenebilir |

## Test: 26/26 ✅ + 6/6 regresyon ✅ (0 hata)
Mock'la açılışta Panel/Takip/Kitaplık/Planlama/Bildirimlerin tümü dolu çıkıyor; QB'de neden seçilebiliyor, değerler korunuyor, boş satırlarına boş nedenleri listeleniyor; Soru No hiçbir yerde yok; koyu tema select'lerine kadar tutuyor.


---

# EK: 8. Tur — JSON İçe Aktarma, "Ana Sayfa" Adı, Koyu Tema ve Select Görünümü

| # | Bildirilen | Kök Neden | Düzeltme |
|---|---|---|---|
| 1 | **JSON aktarılmıyor** | importData yalnız `parsed.user` (Dışa Aktar çıktısı) kabul ediyordu; mock-data.json `{_okumaNotu, state}` sarmalayıcısı kullanıyor → "geçerli bir yedek değil" hatası | İçe aktarma artık **iki formatı da** kabul ediyor: sarmalayıcılı mock dosyası VE Dışa Aktar çıktısı. Gerçek tarayıcıda Ayarlar → İçe Aktar akışı uçtan uca test edildi (toast + 4 deneme/3 QB/3 kitap yüklendi) |
| 2 | **"Panel diye modül yok, Ana Sayfa var"** | Nav ve sayfa başlığı "Panel" yazıyordu | Tüm ürün metinlerinde **Ana Sayfa** (nav, sayfa başlığı, rozet toastı). "Koç Paneli" ayrı bir özellik olarak korundu |
| 3 | **Konu seçme listesi hâlâ bembeyaz** | Select zemini `--bg-card` = saf beyaz; popup listesi de beyaz | Select/input zeminleri artık buz mavisi `--bg-canvas` (koyu temada koyu slate); **açılır liste (option) ve seçili/hover öğesi de tema renklerinde**; placeholder rengi tema uyumlu |
| 4 | **Dark tema çok kötü** | (a) Ana Sayfa'da 4 adet `background:#fff` sabit buton → koyu temada parlayan beyaz kutular; (b) grafik ekseni/legend Chart.js varsayılan gri (#666) → koyu kartta okunmuyor; (c) Net Gelişimi grafiği **navigate ile girilince hiç çizilmiyordu** (yalnız kayıt sonrası çiziliyordu → boş kutu); (d) geri sayım kutusu sistem tercihine bakıyordu, uygulama temasına değil | (a) 4 buton da temalı (var(--bg-card)); (b) eksen/legend/ızgara renkleri temadan okunuyor (açılışta koyu temada #94A3B8); (c) renderExams sonunda grafik her durumda çiziliyor; (d) `data-theme="dark"` kuralı eklendi |

## Test: 19/19 uçtan uca (gerçek Chromium) + 10/11 regresyon ✅
Koyu temada 8 sayfa taranarak **sıfır beyaz kutu** doğrulandı; select zeminleri açık temada rgb(245,248,255) / koyuda rgb(15,23,42); içe aktarma geçerli/Geçersiz dosya ayrımını doğru yapıyor.


---

# EK: 9. Tur — Özel Açılır Listeler, Mobil Navigasyon, Açılış Sayfası, Ekrana Tam Sığma

| # | Bildirilen | Kök Neden | Düzeltme |
|---|---|---|---|
| 1 | **Neden/Konu listesi hâlâ bembeyaz** | Android'de native select popup'ını İŞLETİM SİSTEMİ çizer — CSS'in option kuralları oraya işlemez; tur-8'deki `select option {}` stilinin mobilde etkisi yoktu | Native select'ler tamamen emekli edildi: artık TÜM açılır listeler (Konu, Neden, Ders, Sınıf) **özel temalı bileşen** (.dd): temalı buton + yüzen temalı menü, seçili öğe indigo, uzun listelerde **ARA kutusu** (Matematik 40+ konu filtreleniyor), yukarı/aşağı akıllı açılma. Native select yalnız gizli değer deposu olarak kalıyor (eski validasyon aynen çalışıyor) |
| 2 | **Denemede neden seçiliyor ama konu seçilemiyor** | Aynı native-popup sorunu + Matematik gibi uzun listeler mobilde erişilemez oluyordu | ARA kutusu + kaydırılabilir temalı menü ile konu seçimi mobilde doğrulandı (test: "üslü" filtresi → 1.1 Üslü ve Köklü… seçildi) |
| 3 | **Listeler tüm ekranı kaplıyor** | Deneme formu 10 ders kartıyla her zaman açık | Deneme ve Soru Bankası formları **varsayılan KAPALI**: özet/grafik/son kayıtlar hep görünür; "+ Yeni Deneme Ekle" / "+ Yeni Çözüm Ekle" düğmesi formu açar, kayıt sonrası otomatik kapanır |
| 4 | **Mobilde sol sidebar olmayacak + yatayda 2 panel düğmesi** | Mobilde hem hamburger hem sb-reopen görünüyor, sidebar kaydırılıyordu | 1024px altında sidebar/hamburger/sb-reopen TAMAMEN kaldırıldı → **alt navigasyon** (Ana Sayfa, Deneme, Takip, Soru, Daha) + "Daha" alt sayfası (Görevler, Kitaplık, Planlama, Bilgi Bankası, Ayarlar). Masaüstünde sidebar eskisi gibi |
| 5 | **Uygulama ekrana tam sığmalı (mobil + yatay), kaydırarak detay görmemek** | (a) Masaüstünde 240px yatay taşma vardı (main-content width:100% + margin-left); (b) kartlar tüm genişliğe uzuyordu; (c) yoğunluk mobilde fazla | (a) width:auto düzeltmesi — 8 sayfa × 3 görünümde yatay taşma **0**; (b) kart ızgaraları auto-fit minmax(320px) → kartlar **kareye yakın** (yatayda 346px); (c) grafik clamp(170px,32vh,260px), yatay modda sıkışık üst bar/alt nav |
| 6 | **Açılış sayfası + ikon fotoğrafı + arka plan rengi** | — | Görselden ikon **foto olarak** kırpıldı ve uygulamaya gömüldü (11 KB WebP, ağ bağlantısı gerekmez). Açılış sayfası: ikon + ad + Başla. Uygulama zemin rengi giriş sayfasının rengine (**#F3F7FE**) çevrildi; ikon üst barda, yan menüde ve karşılama modalında da foto olarak duruyor |

## Test: 3 görünüm (mobil 390×844 dikey / 740×360 yatay / 1280 masaüstü) — tümü ✅, 0 sayfa hatası
Açılış sayfası → Başla → karşılama (sınıf dd ile); mobil sidebar yok, alt nav 5 öğe; Daha sayfası açılıp yönleniyor; formlar kapalı başlıyor, açılıyor, kayıt sonrası kapanıyor; dd ile konu+neden seçimi mobil/masaüstü/koyu tema; 8 sayfada yatay taşma yok; JSON içe aktarma ve QB kaydı regresyon ✅. Build: 263.883 bayt (gömülü ikon dahil).


---

# EK: 10. Tur — FARKLI VERSİYON (Bilgi Mimarisi & Ekran Sığdırma Kılavuzu)

Kullanıcının verdiği PDF ("Analiz Merkezi / Bilge — Bilgi Mimarisi & Ekran Sığdırma Kılavuzu v1.0") uygulanarak
**ayrı dosya** üretildi: `/home/user/analizmerkezifarkliversiyon.html` (274.745 bayt, tek HTML).
Orijinal `Analiz_Merkezi_v5_1.html` olduğu gibi durur; kaynaklar `/home/user/analiz-merkezi-farkli/` klasöründe.
Tema (renk paleti, 20px kart, Bento gölge, Lucide, tabular-nums, 2 tema) kılavuz gereği aynen korundu.

## Uygulanan mimari (kılavuz bölüm bölüm)
| Kılavuz | Uygulama |
|---|---|
| §2 Alt gezinme + FAB | Mobil: **4 sekme** (Ana · Denemeler · Konular · Analiz) + her sekmede görünen **FAB (+ Deneme Ekle)**; sekmeler doğrudan hedef ekrana gider, menü açmaz |
| §3 Adımlı form (bottom sheet) | FAB → **4 adımlı stepper** aynı panelde (●●○○ göstergesi, Geri/İleri): 1) Deneme bilgileri (OTO boş, Auto-Advance, canlı 120 sınırı) 2) Konu seçme (temalı açılır liste + ARA kutusu, dersler katlanır bölüm) 3) Neden seçme (YANLIŞ/BOŞ ayrı) 4) Özet & kaydet (Net = D − Y×0,25) |
| §4.1 Ana | Üst tek satır (verimli saat + sınav sayacı) + **KPI 2×2** + TEK içerik bloğu **Acil Çalışılacaklar** (max 5: ACİL tekrarlar + KAE konular) + "Tümünü Gör" + seyrek modüller şeridi |
| §4.2 Denemeler | Filtre **çipleri** (Tümü/Bu Hafta/Eksik Giriş) + **ay grup başlıkları** + dar satır (durum rozeti) → dokun: detay (mini tablo + hata/neden listesi) |
| §4.3 Konular | Ders çipleri + ACİL çip + konu kartı (hâkimiyet % + mastery bar + sonraki tekrar) → dokun: çalışma akışı (Ön Test → Aktif Çalışma/3R → Çözümlü Örnek → Karışık Pratik) + bitirince 3/7/14/21/28 takvimi |
| §4.4 Analiz | Tek seferde **tek grafik**: aralık çipleri (Tümü/Son 5/Bu Ay) + sekmeler (Trend/Hata Dağılımı/Korelasyon); **Korelasyon yalnız N≥5**, altında "Veri yetersiz" bilgi kartı |
| §5 Progressive disclosure | Özet→bağlam→detay; formlar Ana'da değil; "Tümünü Gör"/chevron sinyalleri; sık kullanılan FAB'de, seyrek olan modüller şeridinde |
| §6 Responsive | <1024: alt 4 sekme; ≥1024: sol **yan raf** (4 ana + 4 ikincil) + FAB; bento auto-fit grid |
| §7 Bileşenler | Alt sekme (48px), FAB (marka gradyanı), bottom sheet+stepper, segmented control, filtre çipleri, katlanır bölüm, KPI kartı (tabular-nums), boş durum kartları |

## Test: mobil 390×844 + masaüstü 1280 — 46 doğrulama ✅, 0 sayfa hatası
Açılış sayfası ve temalı açılır listeler aynen korundu; 4 adımlı akış uçtan uca (matematik OTO-boş, dd ile konu arama "üslü", net 27,5 özet, kayıt → listede ay grubu); filtreler; detay drill-down; konu akışı + Ebbinghaus 5 periyot; korelasyon kapısı N<5→N=5; JSON içe aktarma; her iki görünümde 8 sayfa yatay taşma sıfır.


---

# EK: 11. Tur — GELİŞMİŞ UI (Modül İçerik & Yerleşim Haritası)

Farklı versiyon silindi. Yeni PDF ("Bilge — Modül İçerik & Yerleşim Haritası", 7 sayfa) + referans görsel (1586×992)
uygulanarak **`/home/user/gelişmişuianalizmerkezi.html`** (281 KB) üretildi. Kaynaklar: `analiz-merkezi-gelismui/`.
Görselden çıkarılan palet: kenar çubuğu marka mavisi gradyan (#2575E9→#2D7CEC, beyaz metin) + açık içerik zemini + beyaz kartlar — mevcut tema korundu.

## Uygulanan yerleşim (PDF bölüm bölüm)
| Bölüm | Uygulama |
|---|---|
| §0 Ortak iskelet | **Marka mavisi sol kenar çubuğu** (profil avatar+ad, ÇALIŞMA/KAYNAKLAR gruplu 8 modül, alt: Panam Yayıncılık) + **üst çubuk**: "Analiz Merkezi ‹ {Başlık}" breadcrumb + "9. Sınıf" rozeti + [─][□][✕] pencere kontrolleri. Kenar çubuğu her masaüstü ekranında sabit |
| §1 Ana Sayfa | Selam+tarih → KPI 4'lü (SERİ · TOPLAM SORU · ORT. NET · OKUNAN SAYFA) → HIZLI ERİŞİM 5'li kart + 2'li (Bilgi/Soru Bankası) → SON DENEMEN kartı |
| §2 Günlük Görevler | İki sütun: solda Günlük Hedefler (Ders Çalışma+Soru Çöz / Kitap Oku; tamam/Eksik rozetleri + "modüle git"), sağda Seri İstatistikleri (Mevcut Seri, Bugün x/3, ilerleme çubuğu, dondurma bilgisi) + "Nasıl Çalışır?" rehberi |
| §3 Denemelerim | Başlık + sağ üst **[Yeni Deneme Ekle]** (form katlanır, kayıt sonrası kapanır) → KPI 4 → solda Son Denemeler, sağda Net Gelişimi grafiği → altta tam genişlik **Ders Detayları** tablosu (8 ders D/Y/B/Net) |
| §4 Konu Takibi | İki sütun: Acil Çalışılacaklar #1-#8 (öncelik) + Ders Başarı Oranları (%çubuklar) → altta **Hata Nedenleri** sayaç şeridi ("ANLAMADIM 12 · Konuyu Bilmiyordum 8 · …") |
| §5 Hafıza Gücü | Ebbinghaus eğri grafiği (tekrarsız bozulma vs 3/7/14/21/28 tekrarlı) + KPI (Tamamlanan Tekrar · Bekleyen · Ort. Hafıza · Kritik) + konu bazlı hafıza çubukları |
| §6 Kitaplık | Başlık + [Yeni Kitap Ekle] (katlanır) → solda İstatistikler (Toplam/Tamamlanan/Okunan Sayfa/Bugün/Disiplin/Hız + Kondisyon Eğilimi), sağda Okunan Kitaplar (giriş satırlı) + Tamamlanan Kitaplar |
| §7 Planlama | Başlık yanında **canlı mini geri sayım** (Gün/Saat/Dak/Sn) → solda Hedef Belirleme + Okuma grubu, sağda İvme Ölçer + Sirkadiyen Ritim → altta Rejim tablosu + Altın Saat/KRİTİK konular |
| §8-9 Bilgi Bankası | Müfredat Ağacı solda; sağda "Konu Seçin" istatistik paneli (Tamamlanan/Çalışılan/Toplam + Tekrar Bekleyen/Ort. Hafıza/Kritik); konu seçilince **3 Adımlı Yol Haritası** (Konu Çalışma → Örnek Çözme → Kendini Test Et) + Hafıza Gücü + Tekrar/Tamamlanma/Son Tekrar + [Sıfırla] |
| §10 Soru Bankası | Başlık + **[Soru Girişi Aç]** → KPI 4 (Toplam Çözülen · Doğru · Yanlış · Başarı %) → Son Çözümler + Günlük Çözüm grafiği |

Mobil (<1024): kenar çubuğu gizli, üst bar + 5'li alt navigasyon + "Daha" sayfası korunur; iki sütunlu düzenler tek kolona iner.

## Test: masaüstü 1920×1200 (26 doğrulama) + mobil 390 + yatay 740 — 0 sayfa hatası
İskelet (mavi kenar çubuğu, breadcrumb, sınıf rozeti, 3 pencere düğmesi), tüm modül yerleşimleri, mock içe aktarma,
deneme kayıt akışı (dd listeleriyle), Ebbinghaus grafiği, canlı geri sayım (48 gün), 3 adımlı harita, konu bitirme;
3 görünümde 8 sayfanın tamamında yatay taşma sıfır. Not: kenar çubuğu-content 22px bindirmesi (262 vs 240) düzeltildi.


---

# EK: 12. Tur — VERCEL TARZI KOYU TEMA + 4 Adımlı Çalışmanın Geri Yüklenmesi

Kapsam: `gelişmişuianalizmerkezi.html` (283 KB). Yerleşim PDF'sinden yalnızca GÖRÜNÜM korundu; hiçbir davranış/özellik değişmedi.

## 1) Koyu tema baştan tasarlandı — Vercel (Geist) estetiği
| Token | Eski (slate) | Yeni (Vercel) |
|---|---|---|
| Zemin | #0F172A (mavi-slate) | **#000000 saf siyah** |
| Kart | #1E293B | **#0A0A0A** yüzey |
| Kenarlık | #334155 | **#262626 hairline** |
| Metin | #F8FAFC / #94A3B8 | **#EDEDED / #A1A1A1** (Geist) |
| Başarı / Hata / Uyarı / Mor | koyu slate tonları | **#0CCA93 / #F04452 / #F5A623 / #8E4EC6** (Geist vurguları) |
| Gölge | koyu düşen gölge | **gölge yok** — yalnızca hairline kenarlık (Vercel kuralı) |
| Kenar çubuğu | mavi gradyan | **#0A0A0A + #1F1F1F kenar** (açık temada mavi gradyan korundu) |
| Açılış sayfası | açık zorlanmış | koyu temada **saf siyah** + #EDEDED başlık |
| İç içe kutular (KPI, mc-box, kb-kpi…) | — | **#111111** (Vercel iç yüzey) |

## 2) Özellik dokunulmazlığı — kaynak dosyalara tam uyum
- **4 Adımlı Çalışma Yol Haritası GERİ YÜKLENDİ** (PDF'nin 3 adımlı önerisi reddedildi): Ön Test (Bilişsel Kanca) → Aktif Çalışma → Çözümlü Örnek İnceleme → Karışık Pratik & Hata Girişi — kaynak `analiz-merkezi/src/js/ui/knowledge.js` ile birebir aynı metinler; konu bitirince 3/7/14/21/28 takvimi aynen kuruluyor (test: 5 periyot ✓)
- Tüm motorlar/mutabakat değişmedi: deneme kayıt akışı (konu+neden zorunlu, OTO boş, Net = D − Y×0,25), öncelik listesi, Ebbinghaus/Cepeda, kök eksik, SKYA/ANLAMADIM uyarıları, seri/dondurma, rozetler, JSON içe/dışa aktarma

## 3) Test: koyu 10/10 + özellik regresyonu 23/23 + mobil/yatay — 0 hata
Tokenlar computed olarak doğrulandı (#000/#0A0A0A/#262626/#EDEDED); kenar çubuğu koyuda gradyansız #0A0A0A, açık temada mavi gradyan yerinde; 4 adım koyu temada çiziliyor; açık tema hiç bozulmadı (#F3F7FE); 3 görünümde 8 sayfa taşması sıfır.

---

## EK-13 — Tur-13: Hata Nedeni Düzeltmesi + 10. Sınıf Müfredatı + Takvim (12 madde)

**Talep:** Kullanıcının 12 maddelik paketi (hata nedeni seçilemiyor, 10. sınıf konuları PDF'i, ayarlardan sınıf değişimi, mavi mobil navbar, ana sayfada özet+grafik, Ebbinghaus chart'ının silinmesi, rejim tablosunun kaldırılması, Google Takvim benzeri takvim, denemede ders seçimi, yeni bildirim türleri, koyu tema kontrastı, ayarlar/bildirim butonlarının yukarı solda olması).

### A) HATA NEDENİ BUG'I — kök neden ×2
1. **Müfredat anahtar uyumsuzluğu:** `CURRICULUM` içindeki ders anahtarı `"Edebiyat"`, formdaki ders adı `"Türk Dili ve Edebiyatı"`ydı → TDE'nin konu listesi hep BOŞtu. Düzeltme: her iki sınıfta anahtar `"Türk Dili ve Edebiyatı"` yapıldı.
2. **Mobil menü örtüşmesi:** `.err-fields` dikey yerleşimde KONU dd menüsü (absolute, 300px) altındaki NEDEN butonunu örtüyordu → kullanıcı neden listesini hiç açamıyordu ("listede sadece konu seç var"). Düzeltme: ≤1023px'de tüm dd menüleri **alt-sheet** (fixed, tam genişlik, karartma katmanı `#dd-backdrop`) olarak açılır.

### B) 10. Sınıf müfredatı (PDF birebir)
PDF'teki 7 ders PDF listeleriyle işlendi: Biyoloji (19 konu: Enerji + Ekoloji temaları), Fizik (21), Kimya (19), Coğrafya (17), Tarih (13), Matematik (21), TDE (12). `CURRICULUM["10"]` tamamen PDF listesiyle değiştirildi. Din Kültürü: PDF'te yok → mevcut liste korundu. **Felsefe:** PDF'te 9 ünite var fakat TYT 8-ders yapısında (LESSON_CONFIG) yer almıyor → eklenmedi; istenirse ayrı turda eklenebilir.

### C) Sınıf değiştirme (Ayarlar)
Ayarlar çekmecesine SINIF bölümü (9/10 butonları) eklendi. `setGrade()`: kayıtlar (deneme/soru/kitap/hafıza) **aynen korunur**, yalnızca konu listeleri ve Bilgi Bankası ağacı yeni sınıfın müfredatına göre okunur. Topbar/sidebar etiketi anında güncellenir.

### D-L) Arayüz
- **D:** Alt navbar (mobil+yatay) mavi gradyan (#2F6BEE→#1D4ED8), her iki temada.
- **E:** Ana sayfa: hızlı erişim 5'lisi ve 2'li kısayol KALDIRILDI → BUGÜNÜN ÖZETİ (Sınava Kalan / Tekrar Bekleyen / Acil Konu / Ort. Hafıza + günün görev şeridi + en acil 3 konu) + PERFORMANS GRAFİKLERİ (Net Gelişimi çizgi + Ders Başayı yatay bar, Chart.js) + SON DENEMEN.
- **F:** Ebbinghaus canvas'ı, render çağrısı ve fonksiyonu tracking.js'ten tamamen silindi (KPI + hafıza barları duruyor).
- **G:** Rejim tablosu (`EXAM_REGIMES` render'ı) planlamadan kaldırıldı.
- **H:** Çalışma Takvimi: aylık ızgara (Pzt başlangıçlı), bugün vurgusu, ‹ › ay gezinme; rozetler: konu tekrarları (3/7/14/21/28. gün, mor), sınava hazırlık (H-7/H-3/H-1, turuncu), sınav günü (kırmızı) + ay özeti.
- **I:** Deneme formunda "DENEMEDEKİ DERSLER" chipleri (8/8 ↔ n/8): istenmeyen ders kapatılır; kapatılan dersin girişleri/hata satırları temizlenir, toplam hesaba katılmaz; en az 1 ders zorunlu.
- **J)** Yeni bildirim türleri: sınav geri sayımı (30/7/1 gün; 1 gün = critical) + hazırlık tekrarı hatırlatmaları (H-7 genel tekrar, H-3 eksik kapatma, H-1 formül turu) + ikonlar (exam/prep).
- **K)** Koyu kontrast: kart #0A0A0A→**#111111**, kenar #262626→**#303030**, iç yüzeyler →**#181818**; zemin saf siyah kalıyor → kart/zemin ayrımı net.
- **L)** Mobil topbar: bildirim + ayarlar butonları baştan (yukarı solda), logo/isim sağa kaydı; yatay mod aynı düzeni kullanır.

### Testler (güncel)
- **g1.js 48/48** (masaüstü 1280): karşılama 10. sınıf, yeni ana sayfa (özet+grafik+qa yok), mock 4 deneme + 2 grafik, 8 chip + TDE kapat/aç, form kaydı (2 hata satırı, konu+neden dd ile, 5. deneme), ebbinghaus yok, takvim (bugün 21.gün rozeti, Ekim'de SINAV + 3 hazırlık), rejim yok, ayarlardan sınıf 10 + kayıt korunumu, Bilgi Bankası 10. sınıf PDF konuları (fotosentez, Koşuk), bildirim listesi, 8 sayfa taşma 0, konsol 0.
- **g2.js 22/22** (mobil 390 + yatay 740): alt navbar mavi (iki mod), topbar solda 2 buton, KONU sheet+backdrop aç/kapa, **NEDEN listesinde gerçek nedenler + konu yok + seçim yazılıyor**, takvim mobil, 16 sayfa-gezinme taşma 0, konsol 0.
- **dark.js 15/15**: kart rgb(17,17,17) + kenar rgb(48,48,48) + zemin rgb(0,0,0) ayrımı, iç yüzey rgb(24,24,24), sidebar rgb(10,10,10), 4 adım koyu render, dd koyu, açık tema #F3F7FE + mavi gradyan sidebar, alt navbar koyu+açıkta mavi.
- Playwright notu: dar viewport + fixed sheet'te PW koordinat tıklaması CDP hit-test anomalisiyle BODY'ye düşebiliyor (elementFromPoint doğru öğeyi döndürüyor); testlerde opt seçimi DOM click ile doğrulandı, dd-btn açılışı gerçek tıkla test edildi. Gerçek tarayıcıda dokunma akışı aynı delegasyon zincirini kullanır.

**Çıktı:** `/home/user/gelişmişuianalizmerkezi.html` — 309.694 bayt (tek dosya, CDN: lucide + chart.js).

---

## EK-14 — Tur-14: Kullanıcı düzeltmeleri (8 madde)

**Talep:** (1) Ders/konu seçimi denemede değil, Planlama'daki SINAV için olmalı; (2) sınıf değişimi ayrı hesap gibi olmalı + bilgiler revize promptlar merged'e işlenmeli; (3) başla ekranında sınıf seçilebilmeli; (4) giriş ekranı tüm ekranı kaplamalı; (5) ikon yanlış kırpılmış — yalnız amblem, yazısız; (6) ayarlar+bildirim sağ üstte streak yanında; (7) profil 👤 ikonu + DAHA'da ayarlar olmasın; (8) QB'de satır bazında ders+konu seçilemiyor + Ders Başarı Oranları izolesi (Konu Takibi'nden kaldır).

### Yapılanlar
- **Deneme formu chipleri GERİ ALINDI** (tur-13 yanlış anlaşılmıştı): 8 dersli TYT formu orijinal haline döndü.
- **Planlama → Sınav Kapsamı (yeni):** ders chipleri (çoklu) + ders başına konu onay kutuları; `plan.examLessons`/`plan.examTopics`. H-7/H-3/H-1 hazırlık tekrarları ve bildirimleri kapsama göre çalışır; takvim rozetleri "×N konu" gösterir.
- **Sınıf = AYRI HESAP:** `setGrade` eski sınıfı `analizmerkezi_v6_g9/_g10` anahtarlarına arşivler, yeni sınıfın hesabını yükler/boş açar; isim taşınır. Test: 9'da 5 deneme → 10'a geçince 0 → 9'a dönünce 5 geri.
- **Şartname eki:** `Revize Promptlar — Tur-14 Eki.md` (sınıf hesapları, splash, sınav kapsamı, QB satırı, arayüz kuralları — master belgeye işlenmek üzere).
- **Splash:** sınıf butonları (9/10) + tam ekran (100vw/100dvh); welcome modalı yalnız isim sorar (sınıf selecti kaldırıldı).
- **İkon:** kaynak ikon.webp yeniden kırpıldı — piksel/bileşen analiziyle amblem çekirdeği (x150-360, y142-345) izole edildi, 256×256 kare, yazı bölgeleri ve çerçeve çubukları dışarıda; b64 %48 küçüldü. Orijinal `ikon_full.webp` olarak yedekli.
- **Mobil topbar:** logo+isim solda; streak + bildirim + ayarlar SAĞ ÜSTTE. DAHA sayfasından ayarlar satırı kaldırıldı.
- **Avatar:** yan menü profil dairesi 👤 (lucide user) ikonu; harf avatarı ve `updateUserUI`'deki avatar satırı kaldırıldı.
- **Soru Bankası satırı:** DERS SEÇ → KONU SEÇ → NEDEN SEÇ (üç alan). Satır dersi değişince konu listesi `qbRowLessonChanged` ile o derse göre yeniden kurulur (dd rebuild); kayıt satırın dersini alır. Sayaç "Ders + Konu + Neden" arar.
- **Konu Takibi:** "Ders Başarı Oranları" kartı kaldırıldı (Acil listesi tam genişlik); ders başarı grafiği yalnızca Ana Sayfa'da.

### Testler (güncel)
- **g1 43/43**: splash 2 buton + tam ekran + kare ikon, welcome'da sınıf selecti yok, splash'ten 10. sınıf, mock 4 deneme + 2 grafik, denemede chip YOK + 8 kart görünür + dd ile konu/neden + kayıt, QB satır dersi Fizik→konu listesi Fizik + kayıtta ders, tracking'de başarı grafiği YOK + acil + hafıza, Sınav Kapsamı (2 konu seçimi, "H-7 ×2" rozeti), ayrı hesap (10'a geçince 0, arşiv g9 dolu, isim korundu, 9'a dönünce 5), 10. sınıf Biyoloji PDF konusu, 8 sayfa taşma 0, konsol 0.
- **g2 23/23** (mobil+yatay): splash tam ekran + sınıf butonu, navbar mavi, sağ üst streak→bildirim→ayarlar (iki mod), NEDEN alt-sheet + gerçek nedenler + seçim, QB mobil 3 alan + ders değişimi, DAHA'da ayar YOK, 16 sayfa geçişi taşma 0, konsol 0.
- **dark 11/11**: kart #111/kenar #303030/zemin siyah ayrım, iç yüzey #181818, sidebar #0A0A0A, 4 adım koyu, açık tema korunumu, navbar iki temada mavi.

**Çıktı:** `/home/user/gelişmişuianalizmerkezi.html` — 278.574 bayt (kırpılmış ikon + kaldırılan bölümlerle küçeldi).

---

## EK-15 — Tur-15: Dokunuş/gecikme düzeltmeleri + takvim gün detayı + kısaltmasız dil

**Talep:** (1) yanlış için konu seçme ekranı çok geç açılıyor ve seçilemiyor (gerçek cihaz); (2) takvimde güne tıklayınca bilgi vermeli (matematik sınavı → saat + konular; tekrar → neyin tekrarı); (3) "H-7/H-1" gibi kullanıcı dostu olmayan kod/kısaltma kullanma.

### 1) Gecikme — kök neden ve düzeltme
`updateExamErrorAreas` / `updateQBErrors` her tuş vuruşunda TÜM hata satırlarını yeniden kuruyordu (30 satır × 30 seçenek + ddify = mobilde ağır). **Düzeltme:** yanlış/boş sayısı VE dağılımı değişmedikçe yeniden çizim yok (erken çıkış koruması).

### 2) Seçilemiyor — kök neden ve düzeltme (asıl bug)
Mobilde alt-sheet menü form kartının İÇİNDE `position:fixed` duruyordu: ata öğelerdeki `transform`/animasyon/filtreler sabit konumlandırmayı bozar, iOS'ta "kaydırıcı içinde fixed" hatası dokunuşların menüye ulaşmasını engeller (Playwright'ta da click'in BODY'ye düşmesi olarak görülüyordu). **Düzeltme — PORTAL alt-sheet:** menü açılışta `document.body`'ye taşınır (z-index 300), kapanınca yerine döner; karartma 250; seçenek dokunma hedefi 44px; `dd-opt` işleyicisi `__wrap` üzerinden select'i bulur; arama filtresi menü kökünde çalışır; "dışına tıkla → kapat" kuralı portal menünün içini dış saymaz. **Testte GERÇEK dokunuşla (touchscreen) konu ve neden seçimi kanıtlandı.**

### 3) Takvim gün detayı (yeni)
Gün kutuları butona dönüştü; dokununca takvim altında detay paneli:
- **Sınav günü:** kırmızı kutu + Sınav Saati (Hedef Belirleme'ye `Sınav Saati` girişi eklendi, `plan.examTime`) + sınav kapsamındaki konuların listesi (ders: konu satırları).
- **Sınava hazırlık:** hangi tekrar olduğu + ne yapılacağı cümleyle + çalışılacak konu listesi.
- **Konu tekrarı:** "Ders: Konu — N. gün tekrarı" satırları.
- Boş gün: "Bu gün için kayıtlı sınav ya da tekrar yok." Panel Kapat ile kapanır; seçili gün mor çerçeveyle vurgulanır.

### 4) Kısaltmasız dil
Rozetler: "SINAV GÜNÜ", "Genel tekrar", "Eksik kapatma", "Formül turu". Açıklamalar: "Sınavdan 1 hafta önce / 3 gün önce / 1 gün önce". Bildirimler aynı dile çevrildi ("Genel tekrar haftası", "Eksik kapatma günü", "Formül turu günü"). Planlama sayfasında `H-\d` deseni testle doğrulandı (0 eşleşme).

### Testler (güncel)
- **g1 48/48**: + Sınav Saati kaydı, sınav günü detayı (başlık + 08:30 + 2 konu satırı), tekrar günü detayı ("N. gün tekrarı"), H-kodu yok, portal kapama; önceki 43 kontrol aynen geçti.
- **g2 26/26**: mobil GERÇEK DOKUNUŞLA konu seçimi ✓, GERÇEK DOKUNUŞLA neden seçimi ✓, menü body'de + fixed ✓, backdrop dokunuşuyla kapanma ✓, portal geri dönüşü ✓; yatayda aynı set; taşma 0; konsol 0.
- **dark 11/11**: değişiklik yok, geçti.

**Çıktı:** `/home/user/gelişmişuianalizmerkezi.html` — 286.634 bayt.

---

## EK-16 — Tur-16: Okul sınavları + AYT ağırlıkları + 9 düzeltme

**Talep:** (1) ders başarı grafiği renkleri değişsin; (2) denemelerde HER denemeye tıklayınca ders detayları; (3) acil liste 10 + "daha fazla göster"; (4) Hata Nedenleri kartı kalksın; (5) soru girişinde ders zaten seçiliyor — satırda tekrar olmasın; (6) 30 soruda 56 yanlış girilebiliyor; (7) planlamada DENEME ve OKUL SINAVLARI ayrı; sınav konusu seçimi yalnız okul sınavı için, okul sınavı tek ders + istenen konular; (8) Çalış'a basınca konu ağacı açılıyor; (9) takvimdeki her önemli gün "bugün şunlar var" bildirimi + sınavdan 1 gün önce mesaj; (10) AYT ağırlığı araştırılıp doğru şekilde eklensin.

### Yapılanlar
1. **Grafik renkleri:** trafik ışığı yerine ders başına sabit palet (LESSON_CHART_COLORS: mavi/mor/teal/amber/pembe/cyan/lime/gül).
2. **Deneme detayı:** Son Denemeler satırları tıklanabilir (vurgu + DETAY rozeti); Ders Detayları seçili denemeyi gösterir.
3. **Acil liste:** 10 satır + "Daha Fazla Göster (N konu daha)" → +10.
4. **Hata Nedenleri kartı** tracking'den kaldırıldı.
5. **QB satırları:** DERS alanı yok — etiket form dersini gösterir; KONU+NEDEN.
6. **SINIR:** D+Y+B ≤ Toplam Çözülen: canlı kırpma (10 soruda yanlış 5→2) + kayıt güvenliği; toplam elle girilmedikçe otomatik türetilir.
7. **Planlama iki bölüm:** "Deneme Hedefi" (TYT, tüm dersler) + "Okul Sınavları" (tek ders + tarih + saat + konu kutuları; liste + silme). Sınav Kapsamı kartı kaldırıldı. Takvim: deneme "DENEME / Deneme · Genel tekrar…"; okul sınavı ders adı + 3 gün/1 gün önce hazırlık; gün detayı "Okul Sınavı: Matematik" + saat + konular.
8. **Bilgi Bankası:** Çalış → ağaç otomatik AÇILMAZ, doğrudan konu paneli.
9. **Bildirimler:** "Bugünün Planı" günlük özeti + okul sınavı arifesi "Yarın X Sınavın!" (critical + tarayıcı) + "BUGÜN X Sınavı".
10. **AYT ağırlıkları (ÖSYM tabloları):** AYT_WEIGHTS — SAY: Mat 0.30, Fizik 0.105, Kimya 0.0975, Biyo 0.0975; EA: Mat 0.30, TDE 0.18, Tarih 0.07, Coğ 0.05; SÖZ: TDE 0.18, Tarih 0.15, Coğ 0.13, Din 0.05. Ayarlar'a ALAN seçimi; öncelik = hata ağırlığı × (1+Laplace) × (1 + alanın ders ağırlığı).

### Testte yakalanan ek hata
Uzun takvim rozetleri grid sütunlarını genişletip mobilde sayfayı 543px'e taşıyor, sabit alt navbar ekran dışına kayıyordu → `repeat(7, minmax(0,1fr))` + `.cal-day{min-width:0}` ile düzeltildi.

### Testler
- **g1 35/35**: palet, satır tıklama+vurgu, QB kırpma 5→2 + 2 alan + kayıt, acil 10→20, Hata Nedenleri yok, Çalış→ağaç kapalı, iki bölüm + kapsam yok, okul sınavı akışı (YARIN + 2 konu + gün detayı 10:00), Bugünün Planı + Yarın Matematik Sınav, AYT değerleri + alan seçimi, taşma 0, konsol 0.
- **g2 20/20** (mobil+yatay): portal gerçek dokunuş konu+neden, mobil kırpma, okul sınavı mobil, DAHA'da ayar yok, 16 geçiş taşma 0, konsol 0.
- **dark 7/7**: kontrast + açık tema + navbar mavi.

**Çıktı:** `/home/user/gelişmişuianalizmerkezi.html` — 296.506 bayt.

---

## EK-17 — Tur-17: Alan kaldırma + toggle kapanma + hafıza listesi + PWA/Firebase paketi

**Talep:** (1) alan seçme kaldır — 9-10. sınıf için alan yok, AYT ağırlığı doğrudan kullanılsın; (2) "Daha Fazla Göster" açılıyor ama kapanmıyor — toggle olsun; (3) aynı davranış Hafıza Gücü için de; (4) PWA + Firebase (mesajlaşma + veritabanı) + Google girişi için gerekli hazırlık + kullanıcıya düşenlerin listesi.

### Yapılanlar
1. **Alan (puan türü) kaldırıldı:** Ayarlar'daki ALAN bölümü, setAlan/AYT_WEIGHTS alan tabloları, user.alan tamamen silindi. Yerine ders başına TEK AYT ağırlığı (ÖSYM tablolarındaki en yüksek puan etkisi): Mat %30 · TDE %18 · Tarih %15 · Coğrafya %13 · Fizik %10.5 · Kimya %9.75 · Biyoloji %9.75 · Din %5. Öncelik formülü aynı: hata ağırlığı × (1+Laplace) × (1+AYT ağırlığı).
2. **Acil liste toggle:** tümü açılınca buton "Daha Az Göster" olur; basınca liste 10'a döner (10 → +10 … → 10).
3. **Hafıza Gücü aynı:** ilk 10 satır + "Daha Fazla (N)" / "Daha Az" toggle (memoryLimit).
4. **PWA + Firebase paketi** (`/home/user/analiz-merkezi-pwa/`): manifest.json (standalone, ikonlar), sw.js (offline önbellek), icons/ (192/512/maskable, amblem ikondan), firebase-config.js (şablon), app-pwa.js (Google popup girişi + Firestore otomatik bulut yedek [4 sn debounce] + girişte buluttan geri yükleme [onaylı] + FCM token + ön plan bildirimleri + yan menü/DAHA'ya giriş butonları), firebase-messaging-sw.js (arka plan bildirimi), build_pwa.py (kaynaktan PWA index.html üretir, config'i SW'ye işler), README-PWA.md (kullanıcı adımları). Config boşken uygulama tam işlevsel (offline-first), buton yol gösterir.
   - **Kullanıcıya düşenler:** Firebase projesi → Authentication'da Google'ı aç → Firestore oluştur (eur3) + güvenlik kuralları (yalnızca kendi uid) → web config'i firebase-config.js'e yapıştır → Cloud Messaging VAPID anahtarı → build_pwa.py → HTTPS yayınlama (Firebase Hosting/Netlify) → telefonda "Uygulamayı yükle". Ayrıntılar README-PWA.md'de.

### Testler (yeni kalıcı dizin: /home/user/pw-tests/)
- **g1 27/27**: tek AYT tablo değerleri + AYT_WEIGHTS yok + ayarlarda ALAN yok + öncelik üretimi; deneme kayıt + satır tıklama detayı; QB kırpma 5→2 + DERS alanı yok + kayıt; acil 10→20→(tümü)→"Daha Az"→10; hafıza 10→14→10; okul sınavı + gün detayı + bildirimler; taşma 0; konsol 0.
- **g2 13/13** (mobil+yatay): portal gerçek dokunuş konu+neden, kırpma, bölümler, 16 geçiş taşma 0.
- **dark 3/3** ve **pwa 10/10** (localhost http): manifest+modül bağlı, uygulama tam çalışıyor, sw.js kayıtlı, giriş butonu + config uyarısı, varlıklar 200, konsol 0.

**Çıktılar:** `/home/user/gelişmişuianalizmerkezi.html` (295.766 b) + `/home/user/analiz-merkezi-pwa/` (yayın paketi).

---

## EK-19 — Tur-19: Config tamamlandı + CANLI uçtan uca doğrulama

**Talep:** Kullanıcı Web API Key'i verdi (AIzaSyD7X9…); Firebase backend'in çalıştığı gerçek sunucuya karşı doğrulansın.

### Yapılanlar
1. **firebase-config.js tamamen dolduruldu** (apiKey dahil 6/6 değer); build_pwa.py düzeltildi — messaging SW'ye config her derlemede yeniden işlenir (placeholder sorunu giderildi).
2. **Canlı REST yoklama:** API key geçerli; Email/Password sağlayıcısı AÇIK (olmayan hesaba `INVALID_LOGIN_CREDENTIALS` = sağlayıcı aktif).
3. **Hata avı (dbg19):** bulut senkronu `window.state` üzerinde patlıyordu — uygulama `state`'i global `let` ile bildirdiği için `window.state` tanımsız. Düzeltme: `window.state` → doğrudan `state` (global sözcüksel bağlama, 4 yer).
4. **CANLI E2E test (pwa 13/13):** localhost üzerinde gerçek Firebase — UI'dan e-posta/şifre girişi (smoke-test hesabı), oturum açıldı (etiket "Çıkış (smoke-test)"), modal kapandı, saveState → 4 sn debounce → **Firestore users/{uid}/state/main belgesi güncellendi** (REST'ten dışarıdan doğrulandı, updatedAt=2026-08-30T15:37:08), SW kayıtlı, konsol hatası 0.

### Firebase tarafı durum (hepsi CANLI doğrulandı)
- API key ✓ · Email/Password ✓ · Firestore oluşturulmuş ✓ · Kurallar sahip yazmasına izin veriyor ✓
- Kalan: siteyi yayınlamak (Netlify Drop veya firebase deploy) + Netlify ise Authorized domains'e ekleme + isteğe bağlı FCM VAPID anahtarı.
- Not: projede smoke-test@analiz-merkezi.app test hesabı var (silinebilir: Console → Authentication → Users).

**Çıktılar:** analiz-merkezi-pwa/ (Firebase YAPILI) + site-yayin.zip + analiz-merkezi-pwa.zip · pwa 13/13.

---

## EK-20 — Tur-20: Uygulama kapalıyken bildirim — Cloud Functions motoru

**Talep:** Ana hedef: uygulama kapalıyken de mesaj gönderilsin; internet yokken de çalışsın.

### Yapılanlar
1. **functions/bildirim-logic.js** (saf mantık): uygulamadaki processDueNotifications'ın bulut kopyası — Bugünün Planı (tekrar sayısı + deneme + okul sınavı + hazırlık günleri), okul sınavı arifesi/günü, deneme kilometre taşları (7/3/1). Güne özel tekilleştirme anahtarları.
2. **functions/index.js**: 2 zamanlanmış fonksiyon (Europe/Istanbul): sabahBildirimleri 07:30 (tam set) + aksamBildirimleri 19:30 (kritikler). Firestore users/{uid}/state/main + meta/fcm okur, FCM gönderir, notifLog ile aynı gün tekrarını engeller, ölü token temizler. + firebase.json'a functions bloğu (hosting ignore'a functions/ eklendi).
3. **Bildirim tıklama:** firebase-messaging-sw.js'e notificationclick → uygulama aç/öne getir.
4. **İzin sonradan verilirse:** requestNotifPermission sarıldı — izin verilince FCM token'ı kaydedilir (daha önce kaçırılıyordu).
5. **İnternet yokken:** uygulama zaten offline-first; push, cihaz çevrimiçi olunca FCM kuyruğundan düşer (kayıp yok).

### Testler
- logic-test 6/6: arife (saat+konu sayısı), 3 gün önce hazırlık, YARIN SINAV, günlük özet (2 konu tekrarı + formül turu), tekilleştirme anahtarları.
- node --check tüm dosyalar ✓; build_pwa yeniden üretti.

### Kullanıcı adımları (README'ye işlendi)
VAPID anahtarı üret (hâlâ eksik) → Blaze planı (kart; kullanım ücretsiz sınırda) → firebase deploy → telefonda PWA yükle + bildirim izni.

**Çıktılar:** functions/ (3 dosya) + güncel zip'ler + README-PWA.md.

---

## EK-21 — Tur-21: TÜM bildirim türleri push'a + Blaze açıklaması

**Talep:** Uygulamadaki tüm bildirimler (tekrar, acil çalışılacaklar vb.) uygulama kapalıyken mesaj olarak gelsin; Blaze neden zorunlu?

### Yapılanlar
1. **bildirim-logic.js tamamen genişletildi** — uygulama motorlarından birebir kopyalanan formüllerle: memoryDecayRate/getMemoryStrength (Ebbinghaus, 0.16×0.9^n, floor 0.03, kritik <20), collectErrorStats/calculatePriority (deneme 1.5x/test 1.0x, REASON_WEIGHTS, Laplace, AYT çarpanı, öğrenilen-konu düşürme), topicSuccessRate, forgettingIndexList (>80% + 20 gün), dueReviewsList (3-7-14-21-28).
2. **Push seti (07:30 tam, 19:30 kritikler):** koç selamı (ritim+geri sayım), Tekrar Zamanı (konu+kaçıncı gün), ACİL Çalışılacaklar (top 5 + toplam), ACİL hafıza alarmı (%değerlerle), Unutma İndeksi, okul sınavı arifesi/günü, deneme 7/3/1, Bugünün Planı özeti. Uzun listeler "… ve N konu daha" ile kırpılır; anahtarlar günlük tekilleştirilir.
3. **index.js:** akşam kritik setine memcrit eklendi.
4. README-PWA.md: push listesi + Blaze gerekçesi (FCM ücretsiz; zamanlayıcı Cloud Functions 2020'den beri Blaze şart; kullanım ayda ~62 çalışma vs 2M ücretsiz kota → fiilen ₺0; 1₺ bütçe alarmı önerisi).

### Testler
- logic-test2 8/8: koç (Günaydın, Ahmet + 7 gün), tekrar (Üslü 3. gün), acil liste (Üslü+Oran), hafıza alarmı (Tarih %3), AYT çarpanlı skor sırası (4.4/4.4/0.9), arife saat 10:00, 1 hafta taşı, günlük özet. 7 push üretildi, çıktılar raporda.
- node --check ✓.

**Çıktılar:** functions/ (genişletilmiş) + zip'ler + README.

---

## EK-22 — Tur-22: Blaze'siz ücretsiz bildirim (GitHub Actions) + OneSignal değerlendirmesi + online senkron

**Talep:** (1) OneSignal ile tüm mesajlar ücretsiz olamaz mı? (2) Veriler hem localStorage hem veritabanında — doğru mu?

### Yapılanlar
1. **OneSignal analizi:** ücretsiz (10k abone) ama yalnız dağıtım servisi; hangi bildirimin gerektiğine karar verecek ZAMANLAYICI yine gerekir + uygulamaya ikinci SDK/worker gerektirir → tercih edilmedi. Bunun yerine zamanlayıcı GitHub Actions'a taşındı: **Blaze tamamen gereksizleşti** (FCM push zaten ücretsiz; Firestore Spark'ta yeterli).
2. **functions/bildirim-gonder.js:** bağımsız gönderici — Firestore'u okur, bildirim-logic ile mesajları üretir, admin SDK ile FCM gönderir; İstanbul saatine göre sabah/akşam seti otomatik seçer; DRY_RUN modu; eksik secret'ta yol gösteren hata; notifLog tekilleştirme + ölü token temizliği (index.js ile eşdeğer).
3. **.github/workflows/bildirim.yml:** cron 04:30/16:30 UTC = 07:30/19:30 İstanbul (TR sabit UTC+3) + workflow_dispatch ile elle test. YAML doğrulandı.
4. **app-pwa.js:** internet geri gelince bekleyen bulut senkronu otomatik yeniden deneniyor (online olayı → senkronizeEt).
5. README-PWA.md: "Ücretsiz yol GitHub Actions" bölümü (6 adımlık kurulum) + Alternatifler (Blaze/OneSignal).

### Veri depolama (soru 2 — teyit)
Her değişiklikte: localStorage (analizmerkezi_v6, her zaman) + girişliyse 4 sn sonra Firestore users/{uid}/state/main (tam state JSON'u). Canlı doğrulanmıştı (updatedAt). Offline değişiklikler internet gelince otomatik senkronize.

### Testler
node --check ✓, YAML parse ✓, boş secret'ta dostça hata ✓, build_pwa ✓ (logic testleri EK-21'deki gibi 8/8 geçerli).

**Çıktılar:** .github/workflows/bildirim.yml + functions/bildirim-gonder.js + zip'ler.

---

## EK-23 — Tur-23: VAPID anahtarı + CANLI push kayıt zinciri doğrulandı

**Talep:** Kullanıcı VAPID ortak anahtarını verdi; GitHub Actions yolu seçildi.

### Yapılanlar
1. **VAPID anahtarı doğrulandı ve işlendi:** 87 karakter, base64url → 65 bayt P-256 (0x04 ön ekli) ✓ → firebase-config.js FCM_VAPID_KEY + build_pwa.
2. **push.js CANLI test — zincirin tamamı gerçek sunucularla:**
   - Headless Chrome bildirim iznini reddettiği için xvfb + başlıklı mod + **kalıcı profil** gerekti (Chrome Push API'yi kalıcı olmayan bağlamda "gizli mod" sayıp engelliyor — crbug/401439).
   - Sonuç 6/6: izin granted → giriş → izin butonu → SW hazır → **getToken(VAPID) gerçek FCM sunucusundan token aldı** → **Firestore users/{uid}/meta/fcm'ye yazıldı** (REST'ten doğrulandı: fYWz380Sd8y…) → FCM uyarısı 0.
3. Zincir artık uçtan uca hazır: UYGULAMA → FCM token → Firestore → (GitHub Actions bildirim-gonder.js) → push telefona.

### Kalan (kullanıcı adımları — önceki mesajdaki ADIM 1-6)
Siteyi yayınla (firebase deploy / Netlify) → GitHub özel deposu + FIREBASE_SERVICE_ACCOUNT secret → Actions'tan Run workflow → telefonda PWA yükle + izin + kendi hesabıyla kayıt.

**Çıktılar:** zip'ler VAPID'li yenilendi (site-yayin.zip 9 dosya · analiz-merkezi-pwa.zip tam geliştirme paketi) · pw-tests/push.js.

---

## EK-24 — Tur-24: Okulizyon + okul sitesi entegrasyonu (deterministik çekim)

**Talep:** Okulizyon'dan yanlış/boş soruların ders+konu ayıklanması; Analiz Bekliyor → kullanıcı sadece neden seçer; okul sitesi duyuru/sınav tarihleri + ders programı görselinin Gemini ile JSON'a çevrilmesi; veriler localStorage + Firestore.

### Yapılanlar
1. **functions/okulizyon-parser.js:** Cheerio DOM tarama — başlık-isimli sütun eşleme (Ders/Konu/Doğru/Yanlış/Boş/Net/Soru/Durum), şablon değişimine dayanıklı; yapay zekâ YOK. FIXTURE testi **7/7** (ders toplamları 12/5/3 + 6/2/2, konu adı birebir, boş→e durumu, sınav listesi linkleri).
2. **functions/okulizyon-cek.js:** Actions koşucusu — Firestore'dan kullanıcı bilgileri (settings.okulizyon: ad+okul no+ilçe+okul), form girişi (çerez çantası + mobil UA), sonuç sayfaları → ayrıştırıcı → users/{uid}/okulizyon/queue. DRY_RUN + durum özeti. CFG okula özel doldurulacak.
3. **functions/okul-sitesi.js:** duyuru/sınav tarihi Cheerio taraması (tarih regex DD.MM.YYYY→ISO) + ders programı görsel/PDF → Gemini Vision REST (GEMINI_API_KEY, model configurable) → JSON; users/{uid}/okul/duyurular'a yazılır.
4. **.github/workflows/okul-cekim.yml:** cron 04:00 UTC = 07:00 İstanbul (bildirim turundan 30 dk önce) + dispatch. YAML ✓.
5. **app-pwa.js bölüm 8:** yan menü/DAHA'da "Okulizyon" butonu + modal: bağlantı formu (ad/okulNo/ilçe/okulAdı → settings.okulizyon, buluta senkron), **Analiz Bekliyor** listesi (soru no + konu + YANLIŞ/BOŞ + neden seçimi + "tümü: X" hızlı butonları), kaydet → state.exams'e tam şemalı deneme (lessons toplamları + errorLogs[qno,lesson,topic,type,date] + net), importedKeys ile tekilleştirme, okul duyuruları bölümü; kuyruk girişte/online'da çekilir, gelince bildirim + onay.

### Testler
- okz e2e **13/13**: buton → modal → bilgi kaydet → 3 bekleyen satır → duyuru listesi → 2 neden seç + 1 atla → deneme kaydı (ad+net+ders toplamları) → öncelik listesinde Üslü+Oran-Orantı → pending temizlendi → konsol 0.
- node --check tüm dosyalar ✓, build_pwa ✓.

### Bekleyen (kullanıcı)
Okulizyon giriş adresi + form alan adları (veya kaydedilmiş sonuç HTML'i), okul sitesi adresi, GEMINI_API_KEY → OKULIZYON_CFG/OKUL_SITESI doldurulacak.

**Çıktılar:** functions/{okulizyon-parser,okulizyon-cek,okul-sitesi}.js + okul-cekim.yml + app-pwa.js bölüm 8 + zip'ler.

---

## EK-25 — Tur-25: Tek iş akışı (bildirim + okul çekimi birleşti)

**Talep:** Ayrı iş akışı kurmaya gerek yok; mevcut bildirim.yml güncellensin.

### Yapılanlar
- `.github/workflows/bildirim.yml` güncellendi: 6 adım — bağımlılıklar → Okulizyon çek → okul sitesi → bildirimleri gönder. Çekim adımları `if: schedule == '30 4 * * *' || workflow_dispatch` koşuluyla yalnız sabah turunda ve elle çalıştırmada koşar (akşam 19:30'da gereksiz çekim yok). `okul-cekim.yml` kaldırıldı (gereksiz).
- Yapılandırma boşken script'ler kendini atlar → iş akışı config dolmadan da yeşil kalır.
- github-kurulum/ güncellendi: artık elle oluşturulacak TEK dosya (.github/workflows/bildirim.yml). YAML doğrulandı (2 cron, 6 adım, 2 koşullu).

**Çıktılar:** bildirim.yml (güncel) + KURULUM-ADIMLARI.md + zip'ler.

---

## EK-26 — Tur-26: Değişiklik gözcüsü — değişiklik ANINDA fark + anında push

**Talep:** Sadece her sabah değil; sitede değişiklik olduğunda anında anlasın.

### Yapılanlar
1. **functions/degisiklik-kontrol.js:** her 30 dk koşar — Okulizyon (kullanıcı başına giriş + sonuç sayfası) ve okul sitesi (herkese açık) için **anlamsal karma** (sha256, ayıklanmış içerikten — HTML'deki dönen tarih/sayaçlar sahte alarm üretmez; test 3/3). Değişiklik yoksa anında çıkar (kota dostu ~1 dk/koşu); değişiklik varsa: tam çekici (okulizyon-cek/okul-sitesi) execFileSync ile çalıştırır + **ANINDA FCM push** ("🎓 Okulizyon'da yeni sonuç!" / "🏫 Okulundan yeni duyuru") + karma güncellenir. require.main guard'ları ile çekiciler modül olarak içe alınabilir (mkClient/formEncode/OKULIZYON_CFG/parseDuyurular export).
2. **bildirim.yml güncellendi (7 adım, 3 cron):** `*/30 * * * *` gözcü (yalnız gözcü adımı koşar) · `30 4 * * *` çekim + tam set · `30 16 * * *` kritikler. Dakika bütçesi yorumda: 48 koşu/gün ≈ 1440 dk/ay < 2000 ücretsiz; */15 KISILMAZ; public depo = sınırsız.
3. README: gözcü bölümü eklendi.

### Gerçeklik notu
Okul sitesi değişimi "push" etmez (webhook yok) → gerçek anlık imkânsız; en yakın ücretsiz çözüm 30 dk gözcü + anında bildirim. Sonuç yayımlandıktan en geç ~30 dk sonra haberdarlık.

**Çıktılar:** degisiklik-kontrol.js + bildirim.yml (3 cron) + zip'ler · test: hash 3/3, YAML ✓.

---

## EK-28 — Tur-28: Şifresiz giriş + kazanım→konu + Tesseract OCR + Netlify arayüz notu

**Talep:** (1) Okulizyon'da şifre yok; (2) görsel için API yerine kod kütüphanesi; (3) Okulizyon sonuçlarında KAZANIM yazıyor — içindeki konu adı çekilmeli; (4) Netlify kurulumunda sağ altta gitmeyen paylaş/private çipi.

### Yapılanlar
1. **Şifre kaldırıldı:** uygulama formundan ve Playwright girişinden tamamen (alanlar: ad, okul no, sınıf, ilçe, okul).
2. **functions/konular.js (yeni):** uygulamanın konu ağacı (9. sınıf 158 + 10. sınıf 139 konu) + `kazanimToTopic` 3 geçişli deterministik eşleştirme: ① konu adı kazanım içinde tam geçiyorsa birebir ② anlamlı kelime örtüşmesi ≥%50 (≥2 kelime) ③ BENZERSİZ uzun anahtar kelime (tales/pisagor gibi tek konuda geçen); hiçbiri yoksa kazanım kodu temizlenip metin korunur. Birim test 6/6.
3. **Parser:** "Kazanım" başlığı Konu sütunu olarak eşlenir; konu değeri kazanimToTopic'ten geçer (grade bilgisi çekiciden taşınır). Kazanımlı fixture testi 5/5 (M.9.1.1 üslü → "1.1 Üslü ve Köklü Sayılarla İşlemler" vb.).
4. **Tesseract OCR:** okul-sitesi.js'de Gemini Vision TAMAMEN kaldırıldı → tesseract.js ("tur" dili) ile görsel okunur, metinden gün/saat/ders satırları ayrıştırılır; API anahtarı gereksiz. package.json + workflow temizlendi (GEMINI secret'ı artık hiç gerekmiyor).
5. **Netlify çipi (cevap):** Chrome, siteyi tam PWA yerine "kısayol" olarak kurduğunda açılır (minimal-ui: sağ altta paylaş/URL çipi). Çözüm: ikonu sil → gerçek site adresini Chrome ile aç (WhatsApp/Drive önizlemesinden değil) → menüde "Uygulamayı yükle / Install app" (sadece "Ana ekrana ekle" değil) → Chrome WebAPK oluşturunca çip kaybolur.

**Çıktılar:** konular.js + güncellenmiş parser/çekici/okul-sitesi/app-pwa.js/workflow/README + zip'ler. Testler: kazanım 6/6 + parser 5/5 + node --check ✓.

---

## EK-29 — Tur-29: Okulizyon butonu düzeltildi (f.split hatası) + kurulum tamamlandı

**Durum:** Actions yeşil ✓, Netlify yayın ✓, uygulama ana ekranda ✓, Google giriş ✓. Tek arıza: Okulizyon butonu hiçbir şey yapmıyordu.

### Kök neden
Tur-27'de form alanları dizi formatına çevrilmiş ama parçalama satırı (`const [k, label, ph] = f.split("|")`) güncellenmemişti → f artık dizi olduğundan `f.split` tanımsız → openOkzModal çöktü (modal boş ve gizli kaldı). Yerelde birebir replike edildi (PAGEERROR: f.split is not a function).

### Düzeltme
`const [k, label, ph] = f;` — derlendi, zip'ler yenilendi.

### Testler
- okzbtn repro: modal `display:flex`, içerik 2594 karakter, hata 0 ✓
- okz tam e2e yeniden: **13/13** ✓

### Kullanıcı aksiyonu
Netlify'daki siteyi güncelle: `site-yayin.zip` (güncel) → Netlify → Deploys → sürükle-bırak (veya yeni yükleme). Sonra telefonda uygulamayı kapatıp açma (veya siteyi yenileme) → Okulizyon butonu çalışır: Ad + Okul No + Sınıf gir → kaydet → sabah 07:30 çekiminde Analiz Bekliyor dolar.

---

## EK-30 — Tur-30: SW güncelleme kökten çözüldü + duyuru→takvim + oranlı hazırlık günleri

**Talep:** (1) Okulizyon yine açılmıyor; (2) okul sitesi sınav tarihleri takvime otomatik; (3) okul sınavı hazırlık günleri sınava kalan süreye oranla.

### Kök neden (1) ve çözüm
Service worker AĞ-ÖNCELİKLİ değil + cache adı sabitti → Netlify güncellense bile telefon ÖNBELLEKTEKİ ESKİ app-pwa.js'i sunuyordu (f.split düzeltmesi hiç ulaşmıyordu!). Çözüm: sw.js network-first'e çevrildi + cache adı her derlemede zaman damgalı (analiz-merkezi-v-<ts>) + build_pwa.py otomatik damgar. Artık güncelleme yayında ilk açılışta gelir.

### Oranlı hazırlık (3)
schoolPrepDaysFor(kalan): ≥8 gün → [%50, %25, 1] · ≥4 → [%50, 1] · kısa → [1] (örn. 10 gün → 5/3/1; 20 gün → 10/5/1). Etiketler: ilk gün "Genel tekrar", orta "Eksik kapatma", son "Formül turu". addSchoolExam prepDays yazar; takvim + bildirimler prepDays kullanır (eski kayıtlar [3,1] geri uyumlu).

### Duyuru→takvim (2)
okul-sitesi.js: duyuru başlığında yazılı/sınav + ders adı (11 eşleme: türkçe/edebiyat→TDE, geometri→Matematik…) + tarih varsa lesson etiketlenir. app-pwa okzDuyurularToSchoolExams: girişte/online'da duyurular çekilirken sınav duyuruları takvime okul sınavı olarak eklenir (auto, prepDays oranlı, dedupe okulsitesi@ders@tarih), bildirim + toast + modalda "📅 takvime eklendi" işareti. Arife bildirimi konu-0 uyumlu.

### Testler
tur30 **14/14**: SW sürümlü cache, formül (10→[5,3,1], 4→[2,1], 20→[10,5,1]), takvimde 3 hazırlık rozeti, otomatik ithal + dedupe, modal açılıyor + işaret, bildirimler, taşma 0, konsol 0.

### Kullanıcı aksiyonları
1. site-yayin.zip → Netlify'ye yeniden yükle → uygulamayı KAPATIP AÇ (SW yenilenir; ilk geçişte 2 açış gerekebilir) → Okulizyon açılır.
2. guncelleme.zip'teki functions/okul-sitesi.js (+diğerleri) → GitHub'a yükle (duyurular ders etiketli gelsin diye).

---

## EK-31 — Tur-31: Okulizyon formu sitenin giriş ekranının kopyası + sürüm damgası teşhisi

**Talep:** (1) Okulizyon hâlâ tıklanmıyor; (2) giriş formu sitedeki gibi OLSUN: Ad Soyad, İl, İlçe, Okul SEÇMELİ + Okul No, hepsi büyük harf.

### Yapılanlar
1. **Form yeniden kuruldu (sitenin düzeni):** AD SOYAD (input, BÜYÜK HARF stil + autocapitalize) · OKUL NO · SINIF (9-12 select) · İL (Gaziantep) · İLÇE (Şahinbey + 8 ilçe select) · OKUL (Akken Anadolu Lisesi select). Kayıtta ad tr-locale BÜYÜK harfe çevrilir; il alanı da kayda eklendi. Çekici (okulizyon-cek.js) adsoyad'ı BÜYÜK harfle doldurur.
2. **Sürüm damgası:** Okulizyon modal başlığında "v30.1" görünür → telefonundaki uygulamanın güncel olup olmadığı anında anlaşılır (v30.1 görmüyorsan eski önbellek/APK çalışıyor demektir).
3. Tur-30 form değişikliği bir script hatası yüzünden hiç yazılmamıştı (assert sonra write) — adım adım yeniden uygulandı, tur30b testi 10/10.

### Testler
tur30b 10/10: modal + v30.1, AD SOYAD uppercase stili, İL/İLÇE/OKUL/SINIF selectleri, "ahmet yılmaz" → "AHMET YILMAZ" kaydı, konsol 0.

### Telefon tarafı teşhis adımları (kullanıcı)
1. site-yayin.zip → Netlify yeniden yükle
2. Uygulamayı Chrome'dan aç (APK ikonundan DEĞİL) → Okulizyon → başlıkta **v30.1** yazmalı
3. v30.1 yoksa: uygulamayı iki kez kapat-aç; hâlâ yoksa Chrome → Site ayarları →Bildirim/İzin sıfırla + veri temizle → yeniden aç

---

## EK-32 — Tur-32: "Uygulamayı Yükle" butonu (beforeinstallprompt) + zincir doğrulandı

**Durum:** Okulizyon çalışıyor (v30.1) ✓ · 19:30 bildirimi GERÇEKTEN geldi → token→Actions→FCM→telefon zinciri Canlı doğrulandı ✓. Sorun: Netlify'da Chrome "yükle" banner göstermedi.

### Yapılanlar
app-pwa.js bölüm 9: beforeinstallprompt olayı yakalanır → yan menüde "Uygulamayı Yükle" butonu + DAHA sayfası + üstte kapatılabilir mavi banner (YÜKLE) belirir; tıklama Chrome'un NATİF yükleme diyaloğunu açar (WebAPK). appinstalled → tebrik toast. Prompt henüz yoksa tıklama, ⋮ menü/iOS Paylaş yolunu söyler. standalone modunda butonlar hiç görünmez. Banner ✕ kalıcı kapatılabilir (localStorage).

### Testler
tur31 9/9: buton var-gizli, olayla görünür, banner aç/kapa, prompt tetikleme, fallback yönlendirme, Okulizyon regresyonu yok, konsol 0.

**Kullanıcı:** site-yayin.zip → Netlify yeniden yükle → Chrome'da aç → üstteki mavi banner/yan menüden YÜKLE.

---

## EK-33 — Tur-32 (v31): Açılış tanıtımı + Profil Merkezi + anında test bildirimi + ilk çekimde TÜM denemeler

**Talepler:** (1) Run workflow bildirim göndermiyor; (2) ilk açılışta tam ekran logo + ANALİZ MERKEZİ → kaydırmalı tanıtım → giriş; (3) profil simgesi → ad soyad/şehir/ilçe/okul/okul no; (4) Giriş Yap profilde + DAHA bölümünde; (5) Okulizyon'dan İLK çekimde TÜM denemeler.

### Yapılanlar
1. **Açılış tanıtımı (onboarding):** 5 slayt — ANALİZ MERKEZİ logosu (1600 ms otomatik geçiş) → Öncelik Motoru → Hafıza Gücü → Otomasyon → Okul Sınavları + Bildirim/BAŞLA. Atla/Devam/noktalar; telefonda KAYDIRMA (touch ±40 px). Bir kez gösterilir (localStorage `am_onb_v1`) — sonraki açılışlarda gelirmez.
2. **Profil Merkezi (avatar → profil):** HESAP bölümü (giriş durumu + Giriş Yap/Çıkış butonu — yan menüden taşındı) + OKULIZYON bölümü (AD SOYAD/OKUL NO/SINIF/İL/İLÇE/OKUL + "Analiz Bekliyor (N soru) →" düğmesi). Okulizyon modalı artık form İÇERMEZ (yalnız bekleyen analiz + duyurular). DAHA sayfasında Giriş Yap + Okulizyon maddeleri. Yeni buton/banner EKLENMEDİ (kural: istenmeden UI eklenmez).
3. **Anında test bildirimi (bildirim-gonder.js TEST modu):** Actions → Run workflow → "test" ✓ → saat beklemeden TÜM tokenlı kullanıcılara push. Unregistered token otomatik SİLİNÜR + loglanır ("token YOK" satırları da logda). Normal mod aynen: 07:30 tam set / 19:30 kritikler (İstanbul).
4. **İlk çekimde TÜM denemeler (okulizyon-cek.js):** okulizyon/queue belgesi yoksa (İLK kez) 15 denemeye kadar çekilir; sonraki çekimler 5. Sınav adından ya da sayfadan dd.mm.yyyy tarihi çıkarılır.
5. **Sürüm:** PWA_SURUM **v31** (Okulizyon başlığında görünür).

### Testler (hepsi yeni derlemede yeniden koşuldu)
tur32 **18/18** (onboarding: görünürlük, logo, otomatik/elle geçiş, swipe geri, BAŞLA→kapanış, ikinci açılışta gelmez; profil: HESAP+OKULIZYON alanları, BÜYÜK HARF kayıt, Analiz Bekliyor, form YOK okz modalı, Giriş Yap modalı, DAHA etiketleri; konsol 0) · okz **14/14** (profil merkezli akış) · pwa **13/13** · push **6/6** (**TAZE token** Firestore'da — dQxem2EW…, headed modda; headless Chrome push servise bağlanmaz, ortam kısıtı) · g1 **27/27** · g2 **13/13** · dark **3/3**.

### Bildirim göndermeme teşhisi (kullanıcı yolu)
Eski domain (effortless-banoffee) öldü → **FCM token'ları o domaine bağlıydı, hepsi ölü.** Yeni sitede:
1. **analizmerkezii.netlify.app**'i Chrome'da aç → **avatar → Profil → Giriş Yap** → bildirim izni **Ver**
2. GitHub'da 3 dosyayı güncelle (functions/bildirim-gonder.js, functions/okulizyon-cek.js, .github/workflows/bildirim.yml — github-kurulum/ klasöründeki yenileri)
3. **Actions → Bildirim Motoru → Run workflow → "test" ✓** → bildirim ANINDA gelmeli
4. Gelmezse: koşunun logundaki son satırları bana yapıştır (token YOK / unregistered / gönderildi satırları teşhisi gösterir)

### Teslim
- **site-yayin.zip** (538 KB, 9 dosya, v31) → Netlify'a yeniden yükle (analizmerkezii)
- **guncelleme.zip** (app-pwa.js v31) → hızlı güncelleme yolu
- github-kurulum/: bildirim.yml + bildirim-gonder.js + okulizyon-cek.js + KURULUM-ADIMLARI.md (güncelleme bölümü eklendi)

---

## EK-34 — Tur-32b (v32): DAHA sadeleşti + mobil profil + gereksiz yazılar temizlendi + sınıf ekranı yalnız ilk açılışta

**Talepler:** (1) GitHub'a yüklenecekler net verilsin; (2) DAHA'dan Google girişi ve Okulizyon KALDIRILSIN (yalnız profil); (3) mobilde ismin yanındaki logo kalksın → isim profil olsun (yatayda sidebar avatarı var, dikeyde yoktu); (4) sistem nasıl çalışır anlatan gereksiz yazılar kaldırılsın; (5) uygulamaya her girişte sınıf seçme ekranı açılmasın.

### Yapılanlar
1. **DAHA sade:** "Giriş Yap / Bulut Yedek" ve "Okulizyon · Analiz Bekliyor" maddeleri DAHA sayfasından KALDIRILDI. Giriş ve Okulizyon yalnız PROFİL'den (avatar / mobil üst bar ismi).
2. **Mobil profil:** mobil üst bardaki logo KALDIRILDI; **isim tıklanınca profil açılır** (data-act="openProfile"). Masaüstü/yatay: sidebar avatarı aynen.
3. **Gereksiz yazılar kaldırıldı:** "Görevler elle işaretlenmez — ..." (Günlük Görevler) · "Her sınıf AYRI HESAPTIR: ..." (Ayarlar) · "Analiz bekleyen soru yok. Sınav sonuçların her sabah 07:00 otomatik çekilir." (Okulizyon boş durum) · "Okulizyon sonuçların her sabah otomatik çekilir; ..." (Profil) · "Giriş yapılmadı — verilerin yalnız bu cihazda." → "Giriş yapılmadı." · Kaydet toast'ı → "Kaydedildi ✓ (AD · OKUL)".
4. **Sınıf ekranı yalnız İLK kez:** kayıtlı kullanıcı uygulamayı açınca sınıf seçme ekranı ATLANIR, doğrudan uygulama gelir. Sınıf değiştirme: Ayarlar → SINIF (ayrı hesap sistemi aynen korundu).
5. **sw.js damga hatası düzeltildi:** build_pwa.py eski damgayı regex ile yeniler (cache her yayında tazelanır).
6. **Sürüm:** PWA_SURUM **v32**.

### Testler
tur32 **25/25** (yeni: sınıf ekranı 2. açılışta YOK, profil/okulizyon açıklama yazıları YOK, mobil logo YOK + isim→profil, DAHA'da giriş/okulizyon YOK) · okz 14/14 · pwa 13/13 · g1 27/27 · g2 13/13 · dark 3/3 · push 6/6 (**taze token** cwQLOQhey…, headed) · g1/g2/dark mock-reload akışları yeni davranışa uyarlandı.

### GitHub'a yüklenecekler (SADECE 3 dosya — Actions için)
1. `functions/bildirim-gonder.js` ← github-kurulum/bildirim-gonder.js
2. `functions/okulizyon-cek.js` ← github-kurulum/okulizyon-cek.js
3. `.github/workflows/bildirim.yml` ← github-kurulum/bildirim.yml
Site dosyaları GitHub'a GİTMEZ → Netlify (site-yayin.zip).

### Teslim
- **site-yayin.zip** (v32, 9 dosya) → Netlify yeniden yükle
- **guncelleme.zip** (app-pwa.js + index.html + sw.js) → hızlı yol

---

## EK-35 — Tur-33 (v33): sınıf ekranı kökten çözüldü + tanıtım yeniden tasarlandı + mobil profil simgesi

**Talepler:** (1) sınıf seçme ekranı hâlâ her yenilemede geliyor; (2) tanıtımdaki sistem dili metinler ("kazanımlar konuya çevrilir" vb.); (3) tanıtım profesyonel olmalı; (4) mobilde profil simgesi; (5) bildirim teşhisi; (6) GitHub erişimi?

### Yapılanlar
1. **Sınıf ekranı KÖK NEDENİ:** Profil → Giriş yapınca bulut geri yükleme YEREL ADI siliyordu → isim boşalınca splash geri geliyordu. Düzeltme: bulut yüklerken yerel ad korunur. Ek: tanıtımı görmüş kullanıcıda (`am_onb_v1` bayrağı) sınıf ekranı her durumda atlanır; isim girilmemişse karşılama otomatik açılır.
2. **Tanıtım metinleri temizlendi:** "kazanımlar konuya çevrilir", "her sabah otomatik çekilir", "Ebbinghaus 3-7-14-21-28", "AYT puan etkisiyle skor" YOK — kullanıcı faydasına odaklı 5 kısa metin.
3. **Tanıtım tasarımı:** lacivert-mavi ışıklı gradyan, cam efektli ikon çipleri, yukarı kayan slayt animasyonu, segment ilerleme, pill butonlar, çentik (safe-area) desteği; Atla/Devam/BAŞLA/kaydırma aynen.
4. **Mobil profil simgesi:** ismin yanında baş-harfler avatarı (mavi gradyan daire, "Aİ" gibi) — avatar VE isim tıklaması profili açar.
5. **Testin yakaladığı bug:** animasyonlu içerik katmanı Atla butonunu tıklanamaz kılıyordu → pointer-events:none + z-index düzeltildi; kapanış overlay'i anında serbest bırakır.
6. Sürüm **v33**.

### Testler
tur32 **28/28** · okz 14/14 · pwa 13/13 · g1 27/27 · g2 13/13 · dark 3/3 · push 6/6 (canlı token cY7LdXni…) — **104/104**.

### Bildirim teşhisi
- "test" checkbox AYRI ADIM EKLEMEZ — "Bildirimleri gönder" adımının içindeki betiği TEST moduna sokar (logda "=== TEST MODU ===" görünür).
- Gelmiyorsa: telefonda yeni sitede Profil → Giriş Yap + izin Ver → test koşusu → "Bildirimleri gönder" adımı logunu yapıştır ("token YOK"/"✓ gönderildi"/"unregistered" satırları teşhisi verir).
- GitHub'a bu ortamdan erişim yok.

### Teslim
- **site-yayin.zip** (v33, 9 dosya) → Netlify
- **guncelleme.zip** (app-pwa.js + index.html + sw.js)

---

## EK-36 — PR düzeltmesi: kapalı uygulamada FCM push handler eksikti (v33.1)

**Bulgu:** GitHub Actions tarafındaki aktif `bildirim.yml` başarılı koşuyor; test koşusunda Okulizyon adımları atlanıp `bildirim-gonder.js` çalışıyor. Asıl istemci tarafı risk: `app-pwa.js` token'ı `serviceWorkerRegistration: await navigator.serviceWorker.ready` ile `sw.js` üzerine alıyor. Ancak v33 `sw.js` içinde `push` handler yoktu; ayrı `firebase-messaging-sw.js` bu token için kullanılmıyordu. Bu nedenle FCM sunucuda `sent` görünse bile telefon kapalı/arka plandayken bildirim görünmeyebilirdi.

**Düzeltme:** `sw.js` arka plan Web Push payload'ını okuyup bildirim gösterir ve tıklamada `https://analizmerkezii.netlify.app/` adresini açar. Sunucu gönderimleri WebPush `fcmOptions.link`, mutlak icon/badge ve `data.url` ile güçlendirildi. Eski/disabled `.github/workflows/main.yml` kaldırıldı; tek aktif iş akışı `bildirim.yml`.

**Yayın:** `site-yayin.zip` / `guncelleme.zip` v33.1. Netlify'a bu zip yüklendikten sonra telefonda uygulama bir kez açılmalı; gerekirse Chrome site verisi/bildirim izni sıfırlanıp yeniden Profil → Giriş Yap + izin ver yapılmalı.
